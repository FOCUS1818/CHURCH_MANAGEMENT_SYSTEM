<?php
require_once 'config/config.php';

use App\Database;

$database = new Database();
$db = $database->getConnection();

// Get ministry ID from URL
$ministry_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get ministry details
$stmt = $db->prepare("SELECT m.*, CONCAT(mem.first_name, ' ', mem.last_name) as leader_name, mem.photo as leader_photo
                      FROM ministries m 
                      LEFT JOIN members mem ON m.leader_id = mem.id
                      WHERE m.id = :id AND m.is_active = 1");
$stmt->bindParam(':id', $ministry_id, PDO::PARAM_INT);
$stmt->execute();
$ministry = $stmt->fetch(PDO::FETCH_ASSOC);

// If ministry not found, redirect to ministries page
if (!$ministry) {
    header('Location: ministries.php');
    exit;
}

// Get ministry members
$stmt = $db->prepare("SELECT mem.*, mm.role as ministry_role 
                      FROM ministry_members mm 
                      JOIN members mem ON mm.member_id = mem.id 
                      WHERE mm.ministry_id = :id AND mm.is_active = 1 
                      ORDER BY mm.role, mem.first_name");
$stmt->bindParam(':id', $ministry_id, PDO::PARAM_INT);
$stmt->execute();
$ministry_members = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($ministry['name']); ?> - Olebu SDA Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                            <i class="fas fa-church text-white text-lg"></i>
                        </div>
                        <h1 class="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                            OLEBU SDA CHURCH
                        </h1>
                    </div>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Home</a>
                    <a href="sermons.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Sermons</a>
                    <a href="events.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Events</a>
                    <a href="live-streaming.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Live Stream</a>
                    <a href="ministries.php" class="text-indigo-600 font-medium">Ministries</a>
                    <a href="members.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Members</a>
                    <a href="giving.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Give</a>
                    <a href="contact.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Contact</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="bg-gradient-to-r from-teal-600 to-emerald-600 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4"><?php echo htmlspecialchars($ministry['name']); ?></h1>
            <p class="text-xl text-teal-100">Welcome to our <?php echo htmlspecialchars($ministry['name']); ?> Ministry</p>
        </div>
    </div>

    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <!-- Ministry Info -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            <!-- Main Content -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-lg shadow-lg p-8">
                    <h2 class="text-2xl font-bold text-gray-900 mb-4">About This Ministry</h2>
                    <?php if ($ministry['description']): ?>
                        <p class="text-gray-600 mb-6"><?php echo nl2br(htmlspecialchars($ministry['description'])); ?></p>
                    <?php else: ?>
                        <p class="text-gray-600 mb-6">Welcome to the <?php echo htmlspecialchars($ministry['name']); ?> at Olebu SDA Church. We are committed to serving our community and helping each member grow in their faith journey.</p>
                    <?php endif; ?>
                    
                    <h3 class="text-xl font-bold text-gray-900 mb-3">Our Mission</h3>
                    <p class="text-gray-600 mb-6">To glorify God through service, fellowship, and sharing the love of Christ with everyone we meet.</p>
                    
                    <h3 class="text-xl font-bold text-gray-900 mb-3">What We Do</h3>
                    <ul class="list-disc list-inside text-gray-600 space-y-2">
                        <li>Weekly fellowship and Bible study</li>
                        <li>Community outreach programs</li>
                        <li>Youth and family activities</li>
                        <li>Worship and praise services</li>
                        <li>Supporting church missions</li>
                    </ul>
                </div>
            </div>
            
            <!-- Sidebar -->
            <div class="space-y-6">
                <!-- Leader Info -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4">Ministry Leader</h3>
                    <?php if ($ministry['leader_name']): ?>
                        <div class="flex items-center">
                            <?php if ($ministry['leader_photo']): ?>
                                <img src="<?php echo htmlspecialchars($ministry['leader_photo']); ?>" 
                                     alt="<?php echo htmlspecialchars($ministry['leader_name']); ?>" 
                                     class="w-16 h-16 rounded-full object-cover mr-4">
                            <?php else: ?>
                                <div class="w-16 h-16 rounded-full bg-indigo-100 flex items-center justify-center mr-4">
                                    <span class="text-2xl font-bold text-indigo-600">
                                        <?php echo strtoupper(substr($ministry['leader_name'], 0, 1)); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            <div>
                                <p class="font-semibold text-gray-900"><?php echo htmlspecialchars($ministry['leader_name']); ?></p>
                                <p class="text-sm text-gray-500">Ministry Leader</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <p class="text-gray-500">No leader assigned yet.</p>
                    <?php endif; ?>
                </div>
                
                <!-- Meeting Schedule -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4">Meeting Times</h3>
                    <?php if ($ministry['meeting_schedule']): ?>
                        <p class="text-gray-600"><?php echo htmlspecialchars($ministry['meeting_schedule']); ?></p>
                    <?php else: ?>
                        <p class="text-gray-600">Contact us for meeting times.</p>
                    <?php endif; ?>
                </div>
                
                <!-- Contact -->
                <div class="bg-white rounded-lg shadow-lg p-6">
                    <h3 class="text-lg font-bold text-gray-900 mb-4">Contact</h3>
                    <?php if ($ministry['contact_email']): ?>
                        <p class="text-gray-600 mb-2">
                            <i class="fas fa-envelope mr-2"></i>
                            <a href="mailto:<?php echo htmlspecialchars($ministry['contact_email']); ?>" class="text-indigo-600 hover:text-indigo-500">
                                <?php echo htmlspecialchars($ministry['contact_email']); ?>
                            </a>
                        </p>
                    <?php endif; ?>
                    <a href="contact.php?ministry=<?php echo urlencode($ministry['name']); ?>" 
                       class="mt-4 w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 text-center block transition duration-300">
                        Get In Touch
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Ministry Members -->
        <?php if (!empty($ministry_members)): ?>
        <div class="bg-white rounded-lg shadow-lg p-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Our Team Members</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <?php foreach ($ministry_members as $member): ?>
                    <div class="text-center">
                        <?php if ($member['photo']): ?>
                            <img src="<?php echo htmlspecialchars($member['photo']); ?>" 
                                 alt="<?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>" 
                                 class="w-20 h-20 rounded-full mx-auto object-cover mb-3">
                        <?php else: ?>
                            <div class="w-20 h-20 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center mx-auto mb-3">
                                <span class="text-xl font-bold text-white">
                                    <?php echo strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1)); ?>
                                </span>
                            </div>
                        <?php endif; ?>
                        <h4 class="font-semibold text-gray-900"><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></h4>
                        <?php if ($member['ministry_role']): ?>
                            <p class="text-sm text-gray-500"><?php echo htmlspecialchars($member['ministry_role']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Back to Ministries -->
        <div class="mt-8 text-center">
            <a href="ministries.php" class="inline-flex items-center text-indigo-600 hover:text-indigo-500">
                <i class="fas fa-arrow-left mr-2"></i>
                Back to All Ministries
            </a>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>
