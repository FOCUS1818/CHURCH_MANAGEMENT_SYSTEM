<?php
require_once 'config/config.php';

use App\Database;

$database = new Database();
$db = $database->getConnection();

// Get events
$stmt = $db->prepare("SELECT * FROM events WHERE start_datetime > NOW() ORDER BY start_datetime ASC");
$stmt->execute();
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Group events by month
$eventsByMonth = [];
foreach ($events as $event) {
    $month = date('F Y', strtotime($event['start_datetime']));
    if (!isset($eventsByMonth[$month])) {
        $eventsByMonth[$month] = [];
    }
    $eventsByMonth[$month][] = $event;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events - Olebu SDA Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-indigo-600">Olebu SDA Church</a>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600">Home</a>
                    <a href="index.php#about" class="text-gray-700 hover:text-indigo-600">About</a>
                    <a href="sermons.php" class="text-gray-700 hover:text-indigo-600">Sermons</a>
                    <a href="events.php" class="text-indigo-600 font-medium">Events</a>
                    <a href="ministries.php" class="text-gray-700 hover:text-indigo-600">Ministries</a>
                    <a href="members.php" class="text-gray-700 hover:text-indigo-600">Members</a>
                    <a href="contact.php" class="text-gray-700 hover:text-indigo-600">Contact</a>
                    <a href="admin/login.php" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">Admin</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
    <!-- Hero Section -->
    <div class="bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">Upcoming Events</h1>
            <p class="text-xl text-blue-100">Join us for worship, fellowship, and community events</p>
        </div>
    </div>
        </div>

        <?php if (empty($eventsByMonth)): ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No upcoming events</h3>
                <p class="mt-1 text-sm text-gray-500">Check back later for new events.</p>
            </div>
        <?php else: ?>
            <?php foreach ($eventsByMonth as $month => $monthEvents): ?>
                <div class="mb-12">
                    <h2 class="text-2xl font-bold text-gray-900 mb-6"><?php echo $month; ?></h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php foreach ($monthEvents as $event): ?>
                            <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                                <?php if ($event['flyer_image']): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($event['flyer_image']); ?>" 
                                         alt="<?php echo htmlspecialchars($event['title']); ?>" 
                                         class="w-full h-48 object-cover">
                                <?php endif; ?>
                                
                                <div class="p-6">
                                    <div class="flex items-center justify-between mb-2">
                                        <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                            <?php 
                                            switch($event['event_type']) {
                                                case 'service': echo 'bg-blue-100 text-blue-800'; break;
                                                case 'meeting': echo 'bg-green-100 text-green-800'; break;
                                                case 'youth': echo 'bg-purple-100 text-purple-800'; break;
                                                case 'community': echo 'bg-orange-100 text-orange-800'; break;
                                                case 'special': echo 'bg-red-100 text-red-800'; break;
                                                default: echo 'bg-gray-100 text-gray-800';
                                            }
                                            ?>">
                                            <?php echo ucfirst($event['event_type']); ?>
                                        </span>
                                        
                                        <?php if ($event['requires_rsvp']): ?>
                                            <span class="px-2 py-1 text-xs font-semibold bg-yellow-100 text-yellow-800 rounded-full">
                                                RSVP Required
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($event['title']); ?></h3>
                                    
                                    <?php if ($event['description']): ?>
                                        <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($event['description']); ?></p>
                                    <?php endif; ?>
                                    
                                    <div class="space-y-2 mb-4">
                                        <div class="flex items-center text-sm text-gray-500">
                                            <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                                <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path>
                                            </svg>
                                            <?php echo formatDateTime($event['start_datetime'], 'M j, Y g:i A'); ?>
                                        </div>
                                        
                                        <?php if ($event['end_datetime']): ?>
                                            <div class="flex items-center text-sm text-gray-500">
                                                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path>
                                                </svg>
                                                Ends: <?php echo formatDateTime($event['end_datetime'], 'M j, Y g:i A'); ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($event['location']): ?>
                                            <div class="flex items-center text-sm text-gray-500">
                                                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"></path>
                                                </svg>
                                                <?php echo htmlspecialchars($event['location']); ?>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if ($event['max_capacity']): ?>
                                            <div class="flex items-center text-sm text-gray-500">
                                                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3z"></path>
                                                </svg>
                                                Capacity: <?php echo $event['max_capacity']; ?> people
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <?php if ($event['requires_rsvp'] && $event['rsvp_deadline']): ?>
                                        <div class="text-sm text-yellow-600 mb-4">
                                            <strong>RSVP Deadline:</strong> <?php echo formatDateTime($event['rsvp_deadline'], 'M j, Y g:i A'); ?>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="flex space-x-2">
                                        <?php if ($event['requires_rsvp']): ?>
                                            <button class="flex-1 bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 text-sm">
                                                RSVP Now
                                            </button>
                                        <?php endif; ?>
                                        
                                        <button class="flex-1 bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 text-sm">
                                            Add to Calendar
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

<?php include 'includes/footer.php'; ?>
