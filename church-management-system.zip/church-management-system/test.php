<?php 
require 'c:/wamp64/www/church-management-system/config/config.php'; 
$db = (new App\Database())->getConnection(); 
$stmt = $db->query('SELECT id, first_name, last_name, membership_status, household_id, small_group_id FROM members'); 
print_r($stmt->fetchAll(PDO::FETCH_ASSOC));
