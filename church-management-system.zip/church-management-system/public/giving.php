<?php
/**
 * OLEBU Church Management System
 * Public Website - Giving Page
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giving - OLEBU Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-indigo-700 text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="flex items-center space-x-2">
                        <i class="fas fa-church text-2xl"></i>
                        <span class="font-bold text-xl">OLEBU Church</span>
                    </a>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="index.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Home</a>
                    <a href="events.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Events</a>
                    <a href="ministries.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Ministries</a>
                    <a href="giving.php" class="bg-indigo-800 px-3 py-2 rounded">Giving</a>
                    <a href="contact.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Contact</a>
                </div>
                <div>
                    <a href="app/login.php" class="bg-white text-indigo-700 px-4 py-2 rounded-md hover:bg-gray-100">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <div class="bg-green-700 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 class="text-4xl font-bold">Give & Support</h1>
            <p class="mt-2 text-green-200">Partner with us in ministry through your giving</p>
        </div>
    </div>

    <!-- Giving Content -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <!-- Why Give -->
        <div class="mb-16">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900">Why We Give</h2>
                <p class="mt-2 text-gray-600">Giving is an act of worship and partnership in the mission of the church</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="bg-white rounded-lg shadow-md p-6 text-center">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-heart text-green-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Worship</h3>
                    <p class="text-gray-600">Giving is a way to honor God and express gratitude for His blessings.</p>
                </div>
                
                <div class="bg-white rounded-lg shadow-md p-6 text-center">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-hands-helping text-green-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Support</h3>
                    <p class="text-gray-600">Your giving helps us support those in need and reach our community.</p>
                </div>
                
                <div class="bg-white rounded-lg shadow-md p-6 text-center">
                    <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <i class="fas fa-church text-green-600 text-2xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold mb-2">Discipleship</h3>
                    <p class="text-gray-600">Your gifts fund programs that help people grow in their faith.</p>
                </div>
            </div>
        </div>

        <!-- Give In Person -->
        <div class="mb-16">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900">Give In Person</h2>
                <p class="mt-2 text-gray-600">Join us during our services to give your offering</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-church text-green-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold">Sunday Service</h3>
                    </div>
                    <p class="text-gray-600 mb-4">Give your tithe and offering during our Sunday worship service.</p>
                    <div class="bg-green-50 p-4 rounded-lg">
                        <p class="text-sm font-medium text-green-700"><i class="fas fa-clock mr-2"></i>Sunday: 8:00 AM - 12:00 PM</p>
                        <p class="text-sm text-green-700 mt-2"><i class="fas fa-map-marker-alt mr-2"></i>Main Sanctuary</p>
                    </div>
                </div>
                
                <div class="bg-white rounded-lg shadow-md p-6">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-users text-green-600 text-xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold">Midweek Service</h3>
                    </div>
                    <p class="text-gray-600 mb-4">You can also give during our Wednesday Bible study.</p>
                    <div class="bg-green-50 p-4 rounded-lg">
                        <p class="text-sm font-medium text-green-700"><i class="fas fa-clock mr-2"></i>Wednesday: 6:00 PM - 8:00 PM</p>
                        <p class="text-sm text-green-700 mt-2"><i class="fas fa-map-marker-alt mr-2"></i>Fellowship Hall</p>
                    </div>
                </div>
            </div>
            
            <!-- Church Office Info -->
            <div class="mt-8 bg-white rounded-lg shadow-md p-6">
                <div class="flex items-center mb-4">
                    <div class="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-building text-indigo-600 text-xl"></i>
                    </div>
                    <h3 class="text-xl font-semibold">Church Office</h3>
                </div>
                <p class="text-gray-600 mb-4">Visit our church office during office hours to give in person.</p>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <p class="text-sm font-medium text-gray-700"><i class="fas fa-map-marker-alt mr-2 text-gray-500"></i>Address</p>
                        <p class="text-sm text-gray-600 mt-1">Main Street, City Center</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <p class="text-sm font-medium text-gray-700"><i class="fas fa-clock mr-2 text-gray-500"></i>Office Hours</p>
                        <p class="text-sm text-gray-600 mt-1">Mon - Fri: 8am - 5pm</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <p class="text-sm font-medium text-gray-700"><i class="fas fa-phone mr-2 text-gray-500"></i>Phone</p>
                        <p class="text-sm text-gray-600 mt-1">+233 123 456 789</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Giving Categories -->
        <div>
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900">Giving Categories</h2>
                <p class="mt-2 text-gray-600">Choose where you want your gift to go (Amounts in Ghana Cedis ₵)</p>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-8">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <div class="text-center p-6 border-2 border-green-200 rounded-lg hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-coins text-4xl text-green-600 mb-3"></i>
                        <h3 class="text-lg font-semibold">Tithe</h3>
                        <p class="text-sm text-gray-500 mt-1">10% of income</p>
                        <p class="text-green-600 font-bold mt-2">₵</p>
                    </div>
                    <div class="text-center p-6 border-2 border-green-200 rounded-lg hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-gift text-4xl text-green-600 mb-3"></i>
                        <h3 class="text-lg font-semibold">Offering</h3>
                        <p class="text-sm text-gray-500 mt-1">Freewill gifts</p>
                        <p class="text-green-600 font-bold mt-2">₵</p>
                    </div>
                    <div class="text-center p-6 border-2 border-green-200 rounded-lg hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-building text-4xl text-green-600 mb-3"></i>
                        <h3 class="text-lg font-semibold">Building Fund</h3>
                        <p class="text-sm text-gray-500 mt-1">Facility expansion</p>
                        <p class="text-green-600 font-bold mt-2">₵</p>
                    </div>
                    <div class="text-center p-6 border-2 border-green-200 rounded-lg hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-globe text-4xl text-green-600 mb-3"></i>
                        <h3 class="text-lg font-semibold">Missions</h3>
                        <p class="text-sm text-gray-500 mt-1">Outreach programs</p>
                        <p class="text-green-600 font-bold mt-2">₵</p>
                    </div>
                    <div class="text-center p-6 border-2 border-green-200 rounded-lg hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-star text-4xl text-green-600 mb-3"></i>
                        <h3 class="text-lg font-semibold">Special</h3>
                        <p class="text-gray-500 text-sm mt-1">Emergency funds</p>
                        <p class="text-green-600 font-bold mt-2">₵</p>
                    </div>
                    <div class="text-center p-6 border-2 border-yellow-400 rounded-lg hover:bg-yellow-50 transition cursor-pointer bg-yellow-50">
                        <i class="fas fa-ellipsis-h text-4xl text-yellow-600 mb-3"></i>
                        <h3 class="text-lg font-semibold text-yellow-700">Other</h3>
                        <p class="text-gray-500 text-sm mt-1">Specify your giving below</p>
                        <p class="text-green-600 font-bold mt-2">₵</p>
                    </div>
                </div>
                
                <!-- Other Giving Form -->
                <div class="mt-8 pt-8 border-t">
                    <h3 class="text-xl font-semibold mb-4">Other Ways to Give</h3>
                    <p class="text-gray-600 mb-6">Contact us to discuss other giving options or to designate your gift to a specific purpose.</p>
                    <div class="flex justify-center">
                        <a href="contact.php?subject=Donation%20Inquiry" class="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition">
                            <i class="fas fa-envelope mr-2"></i>Contact Us About Giving
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../includes/footer.php'; ?>
