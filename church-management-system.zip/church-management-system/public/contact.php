<?php
/**
 * OLEBU Church Management System
 * Public Website - Contact Page
 */

require_once '../app/config/config.php';
require_once '../app/classes/Database.php';
require_once '../app/functions.php';

use App\Database;

$success = '';
$error = '';

// Handle form submission
if ($_POST) {
    $name = sanitizeInput($_POST['name'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    $phone = sanitizeInput($_POST['phone'] ?? '');
    $subject = sanitizeInput($_POST['subject'] ?? '');
    $message = sanitizeInput($_POST['message'] ?? '');
    
    if (empty($name) || empty($email) || empty($message)) {
        $error = 'Please fill in all required fields.';
    } elseif (!validateEmail($email)) {
        $error = 'Please enter a valid email address.';
    } else {
        // In production, you would save to database or send email
        $success = 'Thank you for contacting us! We will get back to you soon.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - OLEBU Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-indigo-700 text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="flex items-center space-x-2">
                        <i class="fas fa-church text-2xl"></i>
                        <span class="font-bold text-xl">OLEBU Church</span>
                    </a>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="index.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Home</a>
                    <a href="events.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Events</a>
                    <a href="ministries.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Ministries</a>
                    <a href="giving.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Giving</a>
                    <a href="contact.php" class="bg-indigo-800 px-3 py-2 rounded">Contact</a>
                </div>
                <div>
                    <a href="app/login.php" class="bg-white text-indigo-700 px-4 py-2 rounded-md hover:bg-gray-100">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <div class="bg-indigo-700 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 class="text-4xl font-bold">Contact Us</h1>
            <p class="mt-2 text-indigo-200">We'd love to hear from you</p>
        </div>
    </div>

    <!-- Contact Content -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Contact Form -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h2 class="text-2xl font-semibold mb-6">Send us a Message</h2>
                
                <?php if ($success): ?>
                    <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md mb-6">
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md mb-6">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST">
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Name *</label>
                        <input type="text" name="name" required class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                        <input type="email" name="email" required class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                        <input type="tel" name="phone" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Subject</label>
                        <input type="text" name="subject" class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Message *</label>
                        <textarea name="message" rows="5" required class="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>
                    
                    <button type="submit" class="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700">
                        Send Message
                    </button>
                </form>
            </div>
            
            <!-- Contact Info -->
            <div>
                <div class="bg-white rounded-lg shadow-md p-6 mb-6">
                    <h2 class="text-2xl font-semibold mb-6">Church Office</h2>
                    
                    <div class="space-y-4">
                        <div class="flex items-start">
                            <i class="fas fa-map-marker-alt text-indigo-600 mt-1 mr-4"></i>
                            <div>
                                <h3 class="font-medium">Address</h3>
                                <p class="text-gray-600">123 Church Street<br>City, State 12345</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <i class="fas fa-phone text-indigo-600 mt-1 mr-4"></i>
                            <div>
                                <h3 class="font-medium">Phone</h3>
                                <p class="text-gray-600">(555) 123-4567</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <i class="fas fa-envelope text-indigo-600 mt-1 mr-4"></i>
                            <div>
                                <h3 class="font-medium">Email</h3>
                                <p class="text-gray-600">info@olebu.com</p>
                            </div>
                        </div>
                        
                        <div class="flex items-start">
                            <i class="fas fa-clock text-indigo-600 mt-1 mr-4"></i>
                            <div>
                                <h3 class="font-medium">Office Hours</h3>
                                <p class="text-gray-600">Monday - Friday<br>9:00 AM - 5:00 PM</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Service Times -->
                <div class="bg-white rounded-lg shadow-md p-6">
                    <h2 class="text-2xl font-semibold mb-6">Service Times</h2>
                    
                    <div class="space-y-3">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Sunday Service</span>
                            <span class="font-medium">9:00 AM</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Wednesday Bible Study</span>
                            <span class="font-medium">7:00 PM</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Friday Prayer</span>
                            <span class="font-medium">6:00 PM</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php include '../includes/footer.php'; ?>
