<?php
/**
 * OLEBU Church Management System
 * Public Website - Ministries Page
 */

require_once '../app/config/config.php';
require_once '../app/classes/Database.php';
require_once '../app/classes/Ministry.php';
require_once '../app/functions.php';

use App\Ministry;

$database = new Database();
$db = $database->getConnection();
$ministry = new Ministry($db);

// Get active ministries
$ministries = $ministry->readAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ministries - OLEBU Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-indigo-700 text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="flex items-center space-x-2">
                        <i class="fas fa-church text-2xl"></i>
                        <span class="font-bold text-xl">OLEBU Church</span>
                    </a>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="index.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Home</a>
                    <a href="events.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Events</a>
                    <a href="ministries.php" class="bg-indigo-800 px-3 py-2 rounded">Ministries</a>
                    <a href="giving.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Giving</a>
                    <a href="contact.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Contact</a>
                </div>
                <div>
                    <a href="app/login.php" class="bg-white text-indigo-700 px-4 py-2 rounded-md hover:bg-gray-100">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <div class="bg-indigo-700 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 class="text-4xl font-bold">Our Ministries</h1>
            <p class="mt-2 text-indigo-200">Get connected and grow in your faith</p>
        </div>
    </div>

    <!-- Ministries Content -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <?php if ($ministries && $ministries->rowCount() > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <?php while ($ministryRow = $ministries->fetch(PDO::FETCH_ASSOC)): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                        <div class="p-6">
                            <div class="flex items-center justify-between mb-4">
                                <div class="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center">
                                    <i class="fas fa-church text-indigo-600 text-2xl"></i>
                                </div>
                                <span class="px-3 py-1 rounded-full text-sm font-medium <?php echo $ministryRow['is_active'] ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'; ?>">
                                    <?php echo $ministryRow['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                            </div>
                            <h3 class="text-2xl font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($ministryRow['dept_name']); ?></h3>
                            <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($ministryRow['description'] ?? 'Join our ministry and grow with us.'); ?></p>
                            
                            <div class="space-y-2 text-sm text-gray-500">
                                <?php if ($ministryRow['meeting_schedule']): ?>
                                    <p><i class="fas fa-clock mr-2"></i><?php echo htmlspecialchars($ministryRow['meeting_schedule']); ?></p>
                                <?php endif; ?>
                                <?php if ($ministryRow['contact_email']): ?>
                                    <p><i class="fas fa-envelope mr-2"></i><?php echo htmlspecialchars($ministryRow['contact_email']); ?></p>
                                <?php endif; ?>
                                <?php if ($ministryRow['budget']): ?>
                                    <p><i class="fas fa-dollar-sign mr-2"></i>Budget: <?php echo formatCurrency($ministryRow['budget']); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-16">
                <i class="fas fa-church text-6xl text-gray-300 mb-4"></i>
                <h2 class="text-2xl font-semibold text-gray-700 mb-2">No Ministries Available</h2>
                <p class="text-gray-500">Check back soon for our ministry programs.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Get Involved CTA -->
    <div class="bg-indigo-700 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 class="text-3xl font-bold mb-4">Want to Get Involved?</h2>
            <p class="text-indigo-200 mb-8 max-w-2xl mx-auto">We have many opportunities for you to serve and grow. Contact us to learn more about our ministries.</p>
            <a href="contact.php" class="bg-white text-indigo-700 px-8 py-3 rounded-md font-medium hover:bg-gray-100">
                Contact Us
            </a>
        </div>
    </div>

<?php include '../includes/footer.php'; ?>
