<?php
/**
 * OLEBU Church Management System
 * Public Website - Events Page
 */

require_once '../app/config/config.php';
require_once '../app/classes/Database.php';
require_once '../app/classes/Event.php';
require_once '../app/functions.php';

use App\Event;

$database = new Database();
$db = $database->getConnection();
$event = new Event($db);

// Get upcoming events
$upcomingEvents = $event->getUpcoming(90);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events - OLEBU Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-indigo-700 text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="flex items-center space-x-2">
                        <i class="fas fa-church text-2xl"></i>
                        <span class="font-bold text-xl">OLEBU Church</span>
                    </a>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="index.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Home</a>
                    <a href="events.php" class="bg-indigo-800 px-3 py-2 rounded">Events</a>
                    <a href="ministries.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Ministries</a>
                    <a href="giving.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Giving</a>
                    <a href="contact.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Contact</a>
                </div>
                <div>
                    <a href="app/login.php" class="bg-white text-indigo-700 px-4 py-2 rounded-md hover:bg-gray-100">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Header -->
    <div class="bg-indigo-700 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h1 class="text-4xl font-bold">Church Events</h1>
            <p class="mt-2 text-indigo-200">Join us for our upcoming services and activities</p>
        </div>
    </div>

    <!-- Events Content -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <?php if ($upcomingEvents && $upcomingEvents->rowCount() > 0): ?>
            <div class="space-y-8">
                <?php while ($eventRow = $upcomingEvents->fetch(PDO::FETCH_ASSOC)): ?>
                    <?php 
                        $eventDate = !empty($eventRow['start_datetime']) ? $eventRow['start_datetime'] : $eventRow['event_date'];
                        $eventTime = !empty($eventRow['start_datetime']) ? date('H:i', strtotime($eventRow['start_datetime'])) : ($eventRow['event_time'] ?? '');
                        $eventTitle = !empty($eventRow['title']) ? $eventRow['title'] : $eventRow['event_name'];
                    ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden">
                        <div class="md:flex">
                            <div class="md:w-48 bg-indigo-600 flex items-center justify-center p-6">
                                <div class="text-center text-white">
                                    <div class="text-3xl font-bold"><?php echo date('d', strtotime($eventDate)); ?></div>
                                    <div class="text-lg"><?php echo date('M', strtotime($eventDate)); ?></div>
                                    <div class="text-sm"><?php echo date('Y', strtotime($eventDate)); ?></div>
                                </div>
                            </div>
                            <div class="flex-1 p-6">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-medium">
                                        <?php echo ucfirst($eventRow['event_type']); ?>
                                    </span>
                                    <span class="text-gray-500">
                                        <i class="fas fa-clock mr-2"></i><?php echo htmlspecialchars($eventTime ?: 'Time TBA'); ?>
                                    </span>
                                </div>
                                <h3 class="text-2xl font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($eventTitle); ?></h3>
                                <?php if ($eventRow['location']): ?>
                                    <p class="text-gray-600 mb-3">
                                        <i class="fas fa-map-marker-alt mr-2"></i><?php echo htmlspecialchars($eventRow['location']); ?>
                                    </p>
                                <?php endif; ?>
                                <?php if ($eventRow['description']): ?>
                                    <p class="text-gray-600"><?php echo htmlspecialchars($eventRow['description']); ?></p>
                                <?php endif; ?>
                                <?php if ($eventRow['max_capacity']): ?>
                                    <p class="text-sm text-gray-500 mt-3">
                                        <i class="fas fa-users mr-2"></i>Capacity: <?php echo $eventRow['max_capacity']; ?> people
                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-16">
                <i class="fas fa-calendar-times text-6xl text-gray-300 mb-4"></i>
                <h2 class="text-2xl font-semibold text-gray-700 mb-2">No Upcoming Events</h2>
                <p class="text-gray-500">Check back soon for upcoming events at OLEBU Church.</p>
            </div>
        <?php endif; ?>
    </div>

<?php include '../includes/footer.php'; ?>
