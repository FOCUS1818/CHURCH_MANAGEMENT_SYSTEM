<?php
/**
 * OLEBU Church Management System
 * Public Website - Home Page
 */

require_once '../app/config/config.php';
require_once '../app/classes/Database.php';
require_once '../app/classes/Event.php';
require_once '../app/classes/Ministry.php';
require_once '../app/functions.php';

use App\Event;
use App\Ministry;

$database = new Database();
$db = $database->getConnection();
$event = new Event($db);
$ministry = new Ministry($db);

// Get upcoming events
$upcomingEvents = $event->getUpcoming(30);

// Get active ministries
$ministries = $ministry->readAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to OLEBU Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-indigo-700 text-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="flex items-center space-x-2">
                        <i class="fas fa-church text-2xl"></i>
                        <span class="font-bold text-xl">OLEBU Church</span>
                    </a>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="index.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Home</a>
                    <a href="events.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Events</a>
                    <a href="ministries.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Ministries</a>
                    <a href="giving.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Giving</a>
                    <a href="contact.php" class="hover:bg-indigo-600 px-3 py-2 rounded">Contact</a>
                </div>
                <div>
                    <a href="app/login.php" class="bg-white text-indigo-700 px-4 py-2 rounded-md hover:bg-gray-100">
                        <i class="fas fa-sign-in-alt mr-2"></i>Login
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="relative bg-indigo-800">
        <div class="absolute inset-0">
            <div class="absolute inset-0 bg-indigo-900 opacity-75"></div>
        </div>
        <div class="relative max-w-7xl mx-auto py-24 px-4 sm:py-32 sm:px-6 lg:px-8">
            <h1 class="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl text-center">
                Welcome to OLEBU Church
            </h1>
            <p class="mt-6 text-xl text-indigo-200 max-w-3xl text-center mx-auto">
                A place of worship, community, and spiritual growth. Join us as we journey together in faith.
            </p>
            <div class="mt-10 flex justify-center gap-4">
                <a href="events.php" class="bg-white text-indigo-700 px-8 py-3 rounded-md font-medium hover:bg-gray-100">
                    View Events
                </a>
                <a href="contact.php" class="border border-white text-white px-8 py-3 rounded-md font-medium hover:bg-indigo-600">
                    Contact Us
                </a>
            </div>
        </div>
    </div>

    <!-- Upcoming Events -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-900">Upcoming Events</h2>
            <p class="mt-2 text-gray-600">Join us for our upcoming services and activities</p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php if ($upcomingEvents && $upcomingEvents->rowCount() > 0): ?>
                <?php while ($eventRow = $upcomingEvents->fetch(PDO::FETCH_ASSOC)): ?>
                    <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                        <div class="bg-indigo-600 px-4 py-2">
                            <span class="text-white font-semibold"><?php echo ucfirst($eventRow['event_type']); ?></span>
                        </div>
                        <div class="p-6">
                            <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($eventRow['event_name']); ?></h3>
                            <div class="flex items-center text-gray-600 mb-2">
                                <i class="fas fa-calendar-alt mr-2"></i>
                                <span><?php echo formatDate($eventRow['event_date']); ?> at <?php echo htmlspecialchars($eventRow['event_time'] ?? ''); ?></span>
                            </div>
                            <?php if ($eventRow['location']): ?>
                                <div class="flex items-center text-gray-600 mb-2">
                                    <i class="fas fa-map-marker-alt mr-2"></i>
                                    <span><?php echo htmlspecialchars($eventRow['location']); ?></span>
                                </div>
                            <?php endif; ?>
                            <?php if ($eventRow['description']): ?>
                                <p class="text-gray-600 mt-3"><?php echo htmlspecialchars(substr($eventRow['description'], 0, 100)); ?>...</p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-span-full text-center text-gray-500 py-8">
                    <i class="fas fa-calendar-times text-4xl mb-4"></i>
                    <p>No upcoming events at this time. Check back soon!</p>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="text-center mt-8">
            <a href="events.php" class="text-indigo-600 hover:text-indigo-800 font-medium">View all events →</a>
        </div>
    </div>

    <!-- Ministries Section -->
    <div class="bg-gray-100 py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-12">
                <h2 class="text-3xl font-bold text-gray-900">Our Ministries</h2>
                <p class="mt-2 text-gray-600">Get involved in our church community</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php if ($ministries && $ministries->rowCount() > 0): ?>
                    <?php while ($ministryRow = $ministries->fetch(PDO::FETCH_ASSOC)): ?>
                        <div class="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
                            <div class="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                                <i class="fas fa-church text-indigo-600 text-xl"></i>
                            </div>
                            <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($ministryRow['dept_name']); ?></h3>
                            <p class="text-gray-600"><?php echo htmlspecialchars($ministryRow['description'] ?? 'Join our ministry'); ?></p>
                            <?php if ($ministryRow['meeting_schedule']): ?>
                                <div class="mt-4 text-sm text-gray-500">
                                    <i class="fas fa-clock mr-2"></i><?php echo htmlspecialchars($ministryRow['meeting_schedule']); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="col-span-full text-center text-gray-500 py-8">
                        <p>No ministries available at this time.</p>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="text-center mt-8">
                <a href="ministries.php" class="text-indigo-600 hover:text-indigo-800 font-medium">Learn more about our ministries →</a>
            </div>
        </div>
    </div>

    <!-- Service Times -->
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-900">Service Times</h2>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <div class="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-sun text-indigo-600 text-2xl"></i>
                </div>
                <h3 class="text-xl font-semibold mb-2">Sunday Service</h3>
                <p class="text-gray-600">9:00 AM - 11:00 AM</p>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <div class="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-bible text-indigo-600 text-2xl"></i>
                </div>
                <h3 class="text-xl font-semibold mb-2">Wednesday Bible Study</h3>
                <p class="text-gray-600">7:00 PM - 8:30 PM</p>
            </div>
            
            <div class="bg-white rounded-lg shadow-md p-6 text-center">
                <div class="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-pray text-indigo-600 text-2xl"></i>
                </div>
                <h3 class="text-xl font-semibold mb-2">Friday Prayer Meeting</h3>
                <p class="text-gray-600">6:00 PM - 7:30 PM</p>
            </div>
        </div>
    </div>

<?php include '../includes/footer.php'; ?>
</body>
</html>
