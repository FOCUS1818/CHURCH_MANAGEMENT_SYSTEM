<?php
/**
 * OLEBU Church Management System
 * Giving Category Details Page
 */

require_once 'config/config.php';

// Get category type from URL
$category_type = $_GET['type'] ?? 'tithe';

// Category information
$categories = [
    'tithe' => [
        'title' => 'Tithe',
        'icon' => 'fa-coins',
        'color' => 'green',
        'description' => 'Tithe is a foundational principle of Christian giving, representing the first and best portion of what God has given us.',
        'bible_verse' => '"Bring the whole tithe into the storehouse, that there may be food in my house. Test me in this," says the LORD Almighty, "and see if I will not throw open the floodgates of heaven and pour out so much blessing that there will not be room enough to store it." - Malachi 3:10',
        'purpose' => 'Tithes support the overall operations of the church, including ministry programs, staff salaries, facility maintenance, and outreach initiatives.',
        'how_to_give' => 'Place your tithe in the offering plate during Sabbath service, or visit the church office during office hours.',
    ],
    'offering' => [
        'title' => 'Offering',
        'icon' => 'fa-gift',
        'color' => 'green',
        'description' => 'An offering is a freewill gift given above and beyond your tithe, expressing gratitude and worship to God.',
        'bible_verse' => '"Each of you should give what you have decided in your heart to give, not reluctantly or under compulsion, for God loves a cheerful giver." - 2 Corinthians 9:7',
        'purpose' => 'Offerings fund special projects, emergency needs, church events, and additional ministry opportunities that arise throughout the year.',
        'how_to_give' => 'Give your offering during any church service or contact the church office to discuss other ways to give.',
    ],
    'building' => [
        'title' => 'Building Fund',
        'icon' => 'fa-building',
        'color' => 'blue',
        'description' => 'The Building Fund supports the expansion and maintenance of our church facilities to better serve our community.',
        'bible_verse' => '"For the temple of God, which is holy, which you are." - 1 Corinthians 3:17',
        'purpose' => 'Your gifts help us expand our sanctuary, add new classrooms, upgrade our fellowship hall, and create more spaces for ministry activities.',
        'how_to_give' => 'Designate your gift to the Building Fund during service or contact us about giving options.',
    ],
    'missions' => [
        'title' => 'Missions',
        'icon' => 'fa-globe',
        'color' => 'purple',
        'description' => 'Missions giving supports local and international evangelism efforts, spreading the Gospel to unreached communities.',
        'bible_verse' => '"Go therefore and make disciples of all nations, baptizing them in the name of the Father and of the Son and of the Holy Spirit." - Matthew 28:19',
        'purpose' => 'Missions funds support missionary partners, short-term mission trips, community outreach programs, and evangelism initiatives locally and abroad.',
        'how_to_give' => 'Give to the Missions fund during service or contact us to learn about our current mission projects.',
    ],
    'special' => [
        'title' => 'Special Offerings',
        'icon' => 'fa-star',
        'color' => 'orange',
        'description' => 'Special offerings are designated gifts for specific causes, emergencies, or seasonal campaigns throughout the year.',
        'bible_verse' => '"Freely you have received, freely give." - Matthew 10:8',
        'purpose' => 'Special offerings help address immediate needs such as disaster relief, church events, youth programs, and community outreach initiatives.',
        'how_to_give' => 'Give during special campaigns or contact the church office to designate your gift.',
    ],
    'other' => [
        'title' => 'Other Ways to Give',
        'icon' => 'fa-ellipsis-h',
        'color' => 'yellow',
        'description' => 'There are many ways to support the ministry of OLEBU Church beyond financial gifts.',
        'bible_verse' => '"Every man according as he purposeth in his heart, so let him give; not grudgingly, or of necessity: for God loveth a cheerful giver." - 2 Corinthians 9:7',
        'purpose' => 'We welcome gifts of time, talents, and resources. Contact us to explore how you can serve.',
        'how_to_give' => 'Contact our church office to discuss giving options that best suit your situation.',
    ],
];

// Get current category info
$category = isset($categories[$category_type]) ? $categories[$category_type] : $categories['tithe'];

$pageTitle = "Give - " . $category['title'];
include 'includes/header.php';
include 'includes/navigation.php';
?>

<!-- Hero Section -->
<section class="relative bg-gradient-to-br from-green-900 via-emerald-800 to-teal-900 text-white py-20">
    <div class="absolute inset-0 bg-black opacity-30"></div>
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div class="animate-fade-in">
            <div class="inline-block p-4 bg-white/10 rounded-full mb-6">
                <i class="fas <?php echo $category['icon']; ?> text-5xl"></i>
            </div>
            <h1 class="text-4xl md:text-6xl font-bold mb-6"><?php echo $category['title']; ?></h1>
            <p class="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto">
                <?php echo $category['description']; ?>
            </p>
        </div>
    </div>
</section>

<!-- Content Section -->
<section class="py-20 bg-gray-50">
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Bible Verse -->
        <div class="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                <i class="fas fa-book-bible text-green-600 mr-3"></i>
                Scripture
            </h2>
            <blockquote class="text-lg italic text-gray-700 border-l-4 border-green-500 pl-6 py-2">
                "<?php echo $category['bible_verse']; ?>"
            </blockquote>
        </div>
        
        <!-- Purpose -->
        <div class="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                <i class="fas fa-bullseye text-blue-600 mr-3"></i>
                Purpose
            </h2>
            <p class="text-lg text-gray-700 leading-relaxed">
                <?php echo $category['purpose']; ?>
            </p>
        </div>
        
        <!-- How to Give -->
        <div class="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                <i class="fas fa-hand-holding-heart text-green-600 mr-3"></i>
                How to Give
            </h2>
            <p class="text-lg text-gray-700 leading-relaxed">
                <?php echo $category['how_to_give']; ?>
            </p>
            
            <div class="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
                <div class="bg-green-50 p-4 rounded-xl">
                    <div class="flex items-center">
                        <i class="fas fa-church text-green-600 text-xl mr-3"></i>
                        <div>
                            <h3 class="font-semibold">Sunday Service</h3>
                            <p class="text-sm text-gray-600">8:00 AM - 12:00 PM</p>
                        </div>
                    </div>
                </div>
                <div class="bg-blue-50 p-4 rounded-xl">
                    <div class="flex items-center">
                        <i class="fas fa-building text-blue-600 text-xl mr-3"></i>
                        <div>
                            <h3 class="font-semibold">Church Office</h3>
                            <p class="text-sm text-gray-600">Mon-Fri: 8am-5pm</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Contact Option -->
        <div class="bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl shadow-lg p-8 text-white text-center">
            <h2 class="text-2xl font-bold mb-4">Questions About Giving?</h2>
            <p class="text-lg mb-6">Our team is here to help you with any questions about your gift.</p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="contact.php?subject=<?php echo urlencode('Question about ' . $category['title']); ?>" class="inline-block bg-white text-green-700 px-8 py-3 rounded-xl font-semibold hover:bg-gray-100 transition">
                    <i class="fas fa-envelope mr-2"></i>Contact Us
                </a>
                <a href="giving.php" class="inline-block bg-green-700 text-white px-8 py-3 rounded-xl font-semibold hover:bg-green-800 transition">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Giving
                </a>
            </div>
        </div>
        
    </div>
</section>

<?php include 'includes/footer.php'; ?>
