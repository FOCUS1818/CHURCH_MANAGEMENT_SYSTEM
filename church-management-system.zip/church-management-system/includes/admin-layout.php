<?php
/**
 * Admin Layout Wrapper Component
 * Church Management System
 */

// Include the admin header
include 'admin-header.php';
?>

<div class="flex h-screen bg-gray-50">
    <?php include 'admin-sidebar.php'; ?>
    
    <!-- Main content area -->
    <div class="flex-1 flex flex-col overflow-hidden lg:ml-64">
        <!-- Content wrapper with top padding for fixed header -->
        <main class="flex-1 overflow-x-hidden overflow-y-auto pt-16">
            <div class="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                <?php
                // Include page-specific content
                if (isset($contentFile) && file_exists($contentFile)) {
                    include $contentFile;
                } else {
                    // Default content area - this is where page content will go
                    echo $pageContent ?? '';
                }
                ?>
            </div>
        </main>
    </div>
</div>

<?php include 'footer.php'; ?>