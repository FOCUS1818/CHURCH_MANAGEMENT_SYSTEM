<?php
/**
 * Shared Footer Component
 * Church Management System
 */
$isAdmin = strpos($_SERVER['REQUEST_URI'], '/admin/') !== false;
?>

<?php if (!$isAdmin): ?>
<!-- Public Footer -->
<footer class="bg-gray-900 text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div class="space-y-4">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                        <i class="fas fa-church text-white text-lg"></i>
                    </div>
                    <h3 class="text-xl font-bold">Olebu SDA Church</h3>
                </div>
                <p class="text-gray-400 leading-relaxed">
                    Growing in faith, serving in love, building community together.
                </p>
                <div class="flex space-x-4">
                    <a href="https://www.bing.com/ck/a?!&&p=53c37860f6dad120f9c5b567601009e4d5c751528813e186749f1be9c963d706JmltdHM9MTc3NDU2OTYwMA&ptn=3&ver=2&hsh=4&fclid=02d5eda4-55d1-6196-130d-faa054cc603e&psq=olebu+sda+church+facebook&u=a1aHR0cHM6Ly93d3cuZmFjZWJvb2suY29tL29sZWJ1c2RhLmNodXJjaC8" class="text-gray-400 hover:text-white transition-colors duration-200">
                        <i class="fab fa-facebook-f text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors duration-200">
                        <i class="fab fa-twitter text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors duration-200">
                        <i class="fab fa-instagram text-xl"></i>
                    </a>
                    <a href="#" class="text-gray-400 hover:text-white transition-colors duration-200">
                        <i class="fab fa-youtube text-xl"></i>
                    </a>
                </div>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-4">Quick Links</h4>
                <ul class="space-y-3">
                    <li><a href="#about" class="text-gray-400 hover:text-white transition-colors duration-200">About Us</a></li>
                    <li><a href="sermons.php" class="text-gray-400 hover:text-white transition-colors duration-200">Sermons</a></li>
                    <li><a href="events.php" class="text-gray-400 hover:text-white transition-colors duration-200">Events</a></li>
                    <li><a href="ministries.php" class="text-gray-400 hover:text-white transition-colors duration-200">Ministries</a></li>
                    <li><a href="contact.php" class="text-gray-400 hover:text-white transition-colors duration-200">Contact</a></li>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-4">Contact Info</h4>
                <ul class="space-y-3 text-gray-400">
                    <li class="flex items-center space-x-3">
                        <i class="fas fa-map-marker-alt text-indigo-400"></i>
                        <span>Ablekuma-Olebu ,off Pokuase Highway</span>
                    </li>
                    <li class="flex items-center space-x-3">
                        <i class="fas fa-phone text-indigo-400"></i>
                        <span>(233) 257414910</span>
                    </li>
                    <li class="flex items-center space-x-3">
                        <i class="fas fa-envelope text-indigo-400"></i>
                        <span>info@olebusdachurch.com</span>
                    </li>
                </ul>
            </div>
            <div>
                <h4 class="text-lg font-semibold mb-4">Service Times</h4>
                <ul class="space-y-3 text-gray-400">
                    <li class="flex justify-between">
                        <span>Saturday</span>
                        <span class="text-white font-medium">7:00 PM</span>
                    </li>
                    <li class="flex justify-between">
                        <span>Sunday</span>
                        <span class="text-white font-medium">7:00 PM</span>
                    </li>
                    <li class="flex justify-between">
                        <span>Wednesday</span>
                        <span class="text-white font-medium">7:00 PM</span>
                    </li>
                </ul>
            </div>
        </div>
        <div class="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; <?php echo date('Y'); ?> Olebu SDA Church. All rights reserved.</p>
        </div>
    </div>
</footer>
<?php endif; ?>

<script>
// Dark Mode Toggle
const darkModeToggle = document.getElementById('darkModeToggle');
const html = document.documentElement;

// Check for saved dark mode preference or default to light mode
const darkMode = localStorage.getItem('darkMode') === 'true';

if (darkMode) {
    html.classList.add('dark');
}

darkModeToggle?.addEventListener('click', () => {
    html.classList.toggle('dark');
    const isDark = html.classList.contains('dark');
    localStorage.setItem('darkMode', isDark);
});

// Add smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Add loading states to forms
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function() {
        const submitBtn = this.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Processing...';
            submitBtn.disabled = true;
        }
    });
});

// Add fade-in animation to elements
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
        }
    });
}, observerOptions);

document.querySelectorAll('.fade-on-scroll').forEach(el => {
    observer.observe(el);
});

// Add hover effects to cards
document.querySelectorAll('.hover-lift').forEach(card => {
    card.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-4px)';
    });
    
    card.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
    });
});

// Weekly Verse Rotation (10 seconds) - Only on pages with weekly verses
const weeklyVerses = <?php echo isset($weeklyVerses) ? json_encode($weeklyVerses) : '[]'; ?>;
if (weeklyVerses.length > 1) {
    let currentVerseIndex = 0;
    const verseContainer = document.getElementById('verse-container');
    
    if (verseContainer) {
        function updateVerse() {
            const verse = weeklyVerses[currentVerseIndex];
            const blockquote = verseContainer.querySelector('blockquote');
            const cite = verseContainer.querySelector('cite');
            
            // Fade out
            blockquote.style.opacity = '0';
            cite.style.opacity = '0';
            
            setTimeout(() => {
                // Update content
                blockquote.textContent = '"' + verse.verse_text + '"';
                cite.textContent = '- ' + verse.reference;
                
                // Fade in
                blockquote.style.opacity = '1';
                cite.style.opacity = '1';
                
                // Move to next verse
                currentVerseIndex = (currentVerseIndex + 1) % weeklyVerses.length;
            }, 500);
        }
        
        // Change verse every 10 seconds
        setInterval(updateVerse, 10000);
        
        // Add transition styles
        verseContainer.querySelectorAll('blockquote, cite').forEach(el => {
            el.style.transition = 'opacity 0.5s ease-in-out';
        });
    }
}
</script></script>
</body>
</html>
