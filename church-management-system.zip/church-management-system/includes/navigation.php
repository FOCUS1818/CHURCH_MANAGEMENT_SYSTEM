<?php
/**
 * Shared Navigation Component
 * Church Management System
 */
$currentPage = basename($_SERVER['PHP_SELF']);
$isAdmin = strpos($_SERVER['REQUEST_URI'], '/admin/') !== false;
?>

<?php if ($isAdmin): ?>
<!-- Admin Navigation -->
<nav class="bg-white shadow-lg border-b border-gray-200 sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex items-center space-x-8">
                <div class="flex items-center space-x-3">
                    <div class="w-8 h-8 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                        <i class="fas fa-church text-white text-sm"></i>
                    </div>
                    <h1 class="text-xl font-bold text-gray-900"><?php echo APP_NAME; ?></h1>
                </div>
                <div class="hidden md:flex space-x-8">
                    <a href="dashboard.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'dashboard.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-tachometer-alt"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="members.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'members.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-users"></i>
                        <span>Members</span>
                    </a>
                    <a href="events.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'events.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-calendar-alt"></i>
                        <span>Events</span>
                    </a>
                    <a href="sermons.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'sermons.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-microphone"></i>
                        <span>Sermons</span>
                    </a>
                    <a href="ministries.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'ministries.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-hands-helping"></i>
                        <span>Ministries</span>
                    </a>
                    <a href="donations.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'donations.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-heart"></i>
                        <span>Donations</span>
                    </a>
                    <a href="live-streams.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'live-streams.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-video"></i>
                        <span>Live Streaming</span>
                    </a>
                    <a href="reports.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'reports.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-chart-bar"></i>
                        <span>Reports</span>
                    </a>
                    <a href="settings.php" class="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 <?php echo $currentPage === 'settings.php' ? 'text-indigo-600 bg-indigo-50' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'; ?>">
                        <i class="fas fa-cog"></i>
                        <span>Settings</span>
                    </a>
                </div>
            </div>
            <div class="flex items-center space-x-4">
                <!-- Dark Mode Toggle -->
                <button id="darkModeToggle" class="p-2 rounded-lg text-gray-500 hover:text-gray-700 hover:bg-gray-100 dark:text-gray-400 dark:hover:text-gray-300 dark:hover:bg-gray-700 transition-colors duration-200">
                    <i class="fas fa-moon dark:hidden"></i>
                    <i class="fas fa-sun hidden dark:block"></i>
                </button>
                
                <div class="relative">
                    <button class="flex items-center space-x-2 text-sm text-gray-700 hover:text-gray-900 dark:text-gray-300 dark:hover:text-white transition-colors duration-200">
                        <div class="w-8 h-8 bg-indigo-100 dark:bg-indigo-900 rounded-full flex items-center justify-center">
                            <i class="fas fa-user text-indigo-600 dark:text-indigo-400"></i>
                        </div>
                        <span class="hidden md:block"><?php echo htmlspecialchars($_SESSION['first_name'] ?? 'Admin'); ?></span>
                        <i class="fas fa-chevron-down text-xs"></i>
                    </button>
                </div>
                <a href="logout.php" class="flex items-center space-x-2 text-sm text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 transition-colors duration-200">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="hidden md:block">Logout</span>
                </a>
            </div>
        </div>
    </div>
</nav>

<?php else: ?>
<!-- Public Navigation -->
<nav class="bg-white shadow-lg sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between h-16">
            <div class="flex items-center">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                        <i class="fas fa-church text-white text-lg"></i>
                    </div>
                    <h1 class="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                        OLEBU SDA CHURCH
                    </h1>
                </div>
            </div>
            <div class="hidden md:flex items-center space-x-8">
                <a href="index.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Home</a>
                <a href="sermons.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Sermons</a>
                <a href="events.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Events</a>
                <a href="live-streaming.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Live Stream</a>
                <a href="ministries.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Ministries</a>
                <a href="members.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Members</a>
                <a href="giving.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Give</a>
                <a href="contact.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Contact</a>
                <a href="admin/login.php" class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium shadow-lg hover:shadow-xl">
                    Admin
                </a>
            </div>
            <div class="md:hidden">
                <button class="text-gray-700 hover:text-indigo-600">
                    <i class="fas fa-bars text-xl"></i>
                </button>
            </div>
        </div>
    </div>
</nav>
<?php endif; ?>
