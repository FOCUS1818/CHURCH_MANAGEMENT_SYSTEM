<?php
/**
 * Admin Sidebar Navigation Component
 * Church Management System
 */
$currentPage = basename($_SERVER['PHP_SELF']);
$currentPath = $_SERVER['REQUEST_URI'];

// Define navigation items
$navItems = [
    [
        'name' => 'Dashboard',
        'icon' => 'fas fa-tachometer-alt',
        'url' => 'dashboard.php',
        'active' => $currentPage === 'dashboard.php'
    ],
    [
        'name' => 'Members',
        'icon' => 'fas fa-users',
        'url' => 'members.php',
        'active' => in_array($currentPage, ['members.php', 'member-add.php', 'member-edit.php', 'member-view.php']),
        'submenu' => [
            ['name' => 'All Members', 'url' => 'members.php'],
            ['name' => 'Add Member', 'url' => 'member-add.php'],
        ]
    ],
    [
        'name' => 'Events',
        'icon' => 'fas fa-calendar-alt',
        'url' => 'events.php',
        'active' => in_array($currentPage, ['events.php', 'event-add.php', 'event-edit.php']),
        'submenu' => [
            ['name' => 'All Events', 'url' => 'events.php'],
            ['name' => 'Add Event', 'url' => 'event-add.php'],
        ]
    ],
    [
        'name' => 'Sermons',
        'icon' => 'fas fa-microphone',
        'url' => 'sermons.php',
        'active' => in_array($currentPage, ['sermons.php', 'sermon-add.php', 'sermon-edit.php']),
        'submenu' => [
            ['name' => 'All Sermons', 'url' => 'sermons.php'],
            ['name' => 'Add Sermon', 'url' => 'sermon-add.php'],
        ]
    ],
    [
        'name' => 'Ministries',
        'icon' => 'fas fa-hands-helping',
        'url' => 'ministries.php',
        'active' => in_array($currentPage, ['ministries.php', 'ministry-members.php']),
        'submenu' => [
            ['name' => 'All Ministries', 'url' => 'ministries.php'],
        ]
    ],
    [
        'name' => 'Donations & Finance',
        'icon' => 'fas fa-heart',
        'url' => 'donations.php',
        'active' => $currentPage === 'donations.php'
    ],
    [
        'name' => 'Small Groups',
        'icon' => 'fas fa-users-rectangle',
        'url' => 'small-groups.php',
        'active' => $currentPage === 'small-groups.php'
    ],
    [
        'name' => 'Households',
        'icon' => 'fas fa-house-user',
        'url' => 'households.php',
        'active' => $currentPage === 'households.php'
    ],
    [
        'name' => 'Attendance',
        'icon' => 'fas fa-clipboard-check',
        'url' => 'attendance.php',
        'active' => $currentPage === 'attendance.php'
    ],
    [
        'name' => 'User Management',
        'icon' => 'fas fa-user-cog',
        'url' => 'users.php',
        'active' => $currentPage === 'users.php'
    ],
    [
        'name' => 'Live Streaming',
        'icon' => 'fas fa-video',
        'url' => 'live-streams.php',
        'active' => in_array($currentPage, ['live-streams.php', 'live-stream-add.php', 'live-stream-edit.php']),
        'submenu' => [
            ['name' => 'All Streams', 'url' => 'live-streams.php'],
            ['name' => 'Add Stream', 'url' => 'live-stream-add.php'],
        ]
    ],
    [
        'name' => 'Reports',
        'icon' => 'fas fa-chart-bar',
        'url' => 'reports.php',
        'active' => $currentPage === 'reports.php'
    ],
    [
        'name' => 'Settings',
        'icon' => 'fas fa-cog',
        'url' => 'settings.php',
        'active' => $currentPage === 'settings.php'
    ]
];
?>

<!-- Sidebar -->
<div id="sidebar" class="fixed inset-y-0 left-0 z-50 w-64 bg-white shadow-xl transform -translate-x-full transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0">
    <div class="flex flex-col h-full">
        <!-- Logo -->
        <div class="flex items-center justify-center h-16 px-4 bg-gradient-to-r from-indigo-600 to-purple-600">
            <div class="flex items-center space-x-3">
                <div class="w-8 h-8 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                    <i class="fas fa-church text-white text-sm"></i>
                </div>
                <h1 class="text-lg font-bold text-white truncate">Church Admin</h1>
            </div>
        </div>

        <!-- Navigation -->
        <nav class="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
            <?php foreach ($navItems as $item): ?>
                <div class="nav-item">
                    <a href="<?php echo $item['url']; ?>" 
                       class="flex items-center justify-between w-full px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 group <?php echo $item['active'] ? 'bg-indigo-50 text-indigo-600 shadow-sm' : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'; ?>">
                        <div class="flex items-center space-x-3">
                            <i class="<?php echo $item['icon']; ?> w-5 h-5 <?php echo $item['active'] ? 'text-indigo-600' : 'text-gray-400 group-hover:text-gray-600'; ?>"></i>
                            <span><?php echo $item['name']; ?></span>
                        </div>
                        <?php if (isset($item['submenu'])): ?>
                            <i class="fas fa-chevron-down w-4 h-4 transition-transform duration-200 <?php echo $item['active'] ? 'rotate-180' : ''; ?>" id="chevron-<?php echo strtolower($item['name']); ?>"></i>
                        <?php endif; ?>
                    </a>
                    
                    <?php if (isset($item['submenu'])): ?>
                        <div class="submenu mt-2 ml-8 space-y-1 <?php echo $item['active'] ? 'block' : 'hidden'; ?>" id="submenu-<?php echo strtolower($item['name']); ?>">
                            <?php foreach ($item['submenu'] as $subitem): ?>
                                <a href="<?php echo $subitem['url']; ?>" 
                                   class="block px-4 py-2 text-sm text-gray-500 rounded-lg hover:bg-gray-50 hover:text-gray-700 transition-colors duration-200 <?php echo $currentPage === basename($subitem['url']) ? 'text-indigo-600 bg-indigo-50' : ''; ?>">
                                    <?php echo $subitem['name']; ?>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </nav>

        <!-- User Profile -->
        <div class="p-4 border-t border-gray-200">
            <div class="flex items-center space-x-3 p-3 rounded-xl bg-gray-50">
                <div class="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full flex items-center justify-center">
                    <span class="text-sm font-bold text-white">
                        <?php echo strtoupper(substr($_SESSION['first_name'] ?? 'A', 0, 1)); ?>
                    </span>
                </div>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-gray-900 truncate">
                        <?php echo htmlspecialchars($_SESSION['first_name'] ?? 'Admin'); ?>
                    </p>
                    <p class="text-xs text-gray-500 truncate">
                        <?php echo htmlspecialchars($_SESSION['user_role'] ?? 'Administrator'); ?>
                    </p>
                </div>
                <div class="relative">
                    <button class="text-gray-400 hover:text-gray-600 transition-colors duration-200" onclick="toggleUserMenu()">
                        <i class="fas fa-ellipsis-v"></i>
                    </button>
                    <div id="userMenu" class="hidden absolute bottom-full right-0 mb-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1">
                        <a href="settings.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50">
                            <i class="fas fa-cog mr-2"></i>Settings
                        </a>
                        <a href="logout.php" class="block px-4 py-2 text-sm text-red-600 hover:bg-red-50">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Mobile sidebar overlay -->
<div id="sidebarOverlay" class="fixed inset-0 z-40 bg-gray-600 bg-opacity-50 hidden lg:hidden" onclick="toggleSidebar()"></div>

<script>
// Sidebar toggle functionality
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
}

// User menu toggle
function toggleUserMenu() {
    const userMenu = document.getElementById('userMenu');
    userMenu.classList.toggle('hidden');
}

// Close user menu when clicking outside
document.addEventListener('click', function(event) {
    const userMenu = document.getElementById('userMenu');
    const userButton = event.target.closest('button');
    
    if (!userButton || !userButton.onclick || userButton.onclick.toString().indexOf('toggleUserMenu') === -1) {
        userMenu.classList.add('hidden');
    }
});

// Submenu toggle functionality
document.addEventListener('DOMContentLoaded', function() {
    const navItems = document.querySelectorAll('.nav-item > a');
    
    navItems.forEach(item => {
        const chevron = item.querySelector('[id^="chevron-"]');
        if (chevron) {
            item.addEventListener('click', function(e) {
                const itemName = chevron.id.replace('chevron-', '');
                const submenu = document.getElementById('submenu-' + itemName);
                
                if (submenu) {
                    e.preventDefault();
                    submenu.classList.toggle('hidden');
                    chevron.classList.toggle('rotate-180');
                }
            });
        }
    });
});
</script>