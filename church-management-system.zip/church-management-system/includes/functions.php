<?php
/**
 * Utility Functions
 * Church Management System
 */

/**
 * Generate CSRF token
 */
function generateCSRFToken() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

/**
 * Verify CSRF token
 */
function verifyCSRFToken($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

/**
 * Sanitize input data
 */
function sanitizeInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Validate email
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Validate name field (letters, spaces, hyphens, apostrophes only)
 */
function validateName($name) {
    // Only allow letters (including international), spaces, hyphens, apostrophes, and periods
    return preg_match('/^[a-zA-Z\s\-\'.\x{00C0}-\x{024F}]+$/u', $name);
}

/**
 * Validate phone number (numbers and common phone characters only)
 */
function validatePhone($phone) {
    // Only allow digits, spaces, dashes, parentheses, plus sign
    return preg_match('/^[0-9\s\-\(\)\+]+$/', $phone);
}

/**
 * Validate word count for notes field
 * Returns true if within limit
 */
function validateWordLimit($text, $limit = 50) {
    if (empty($text)) {
        return true; // Empty is valid (optional field)
    }
    $wordCount = str_word_count(strip_tags($text));
    return $wordCount <= $limit;
}

/**
 * Get word count for a text
 */
function getWordCount($text) {
    return str_word_count(strip_tags($text));
}

/**
 * Hash password
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate random string
 */
function generateRandomString($length = 10) {
    return substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);
}

/**
 * Format date for display
 */
function formatDate($date, $format = 'M j, Y') {
    return date($format, strtotime($date));
}

/**
 * Format datetime for display
 */
function formatDateTime($datetime, $format = 'M j, Y g:i A') {
    return date($format, strtotime($datetime));
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Check user role
 */
function hasRole($requiredRole) {
    if (!isLoggedIn()) return false;
    
    $roleHierarchy = [
        'volunteer' => 1,
        'staff' => 2,
        'pastor' => 3,
        'super_admin' => 4
    ];
    
    $userRole = $_SESSION['user_role'] ?? 'volunteer';
    $userLevel = $roleHierarchy[$userRole] ?? 0;
    $requiredLevel = $roleHierarchy[$requiredRole] ?? 0;
    
    return $userLevel >= $requiredLevel;
}

/**
 * Redirect to login if not authenticated
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'admin/login.php');
        exit();
    }
}

/**
 * Redirect if user doesn't have required role
 */
function requireRole($requiredRole) {
    requireLogin();
    if (!hasRole($requiredRole)) {
        header('Location: ' . BASE_URL . 'admin/dashboard.php?error=access_denied');
        exit();
    }
}

/**
 * Require admin login - redirects to login if not authenticated
 */
function requireAdminLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'admin/login.php');
        exit();
    }
}

/**
 * Upload file with validation
 */
function uploadFile($file, $targetDir = UPLOAD_PATH, $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']) {
    if (!isset($file['error']) || is_array($file['error'])) {
        return ['success' => false, 'message' => 'Invalid file upload'];
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'File upload error'];
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return ['success' => false, 'message' => 'File too large'];
    }
    
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($fileExtension, $allowedTypes)) {
        return ['success' => false, 'message' => 'Invalid file type'];
    }
    
    $fileName = uniqid() . '.' . $fileExtension;
    $targetPath = $targetDir . $fileName;
    
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }
    
    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => true, 'filename' => $fileName, 'path' => $targetPath];
    } else {
        return ['success' => false, 'message' => 'Failed to move uploaded file'];
    }
}

/**
 * Send email with SMTP support using SimpleMailer class
 */
function sendEmail($to, $subject, $message, $isHTML = true) {
    // Check if SMTP credentials are configured
    $smtpConfigured = (
        SMTP_HOST &&
        SMTP_USERNAME !== 'your-email@gmail.com' &&
        SMTP_PASSWORD !== 'your-app-password' &&
        SMTP_PASSWORD !== ''
    );
    
    if (!$smtpConfigured) {
        // Development mode - SMTP not properly configured
        error_log("=== EMAIL NOT SENT (Development Mode) ===");
        error_log("To: $to");
        error_log("Subject: $subject");
        error_log("From: " . FROM_NAME . " <" . FROM_EMAIL . ">");
        error_log("SMTP Host: " . SMTP_HOST);
        error_log("Message length: " . strlen($message) . " bytes");
        error_log("==========================================");
        return true;
    }
    
    // Use SimpleMailer for SMTP with authentication
    require_once __DIR__ . '/../classes/SimpleMailer.php';
    
    $mailer = new \App\SimpleMailer([
        'host' => SMTP_HOST,
        'port' => SMTP_PORT,
        'username' => SMTP_USERNAME,
        'password' => SMTP_PASSWORD,
        'from_email' => FROM_EMAIL,
        'from_name' => FROM_NAME
    ]);
    
    $result = $mailer->send($to, $subject, $message, $isHTML);
    
    if ($result) {
        error_log("Email sent successfully to: $to via " . SMTP_HOST);
    } else {
        error_log("Email sending failed for: $to - " . $mailer->getError());
    }
    
    return $result;
}

/**
 * Send email notification to all registered members
 * @param string $subject Email subject
 * @param string $message Email message (HTML)
 * @param string $activityType Type of activity (event, sermon, live_stream, etc.)
 * @return array Result with success count and failures
 */
function notifyAllMembers($subject, $message, $activityType = 'activity') {
    global $db;
    
    if (!$db) {
        return ['success' => false, 'sent' => 0, 'failed' => 0, 'error' => 'Database connection not available'];
    }
    
    try {
        // Get ALL members with valid emails (regardless of membership status)
        $stmt = $db->query("SELECT first_name, last_name, email FROM members WHERE email IS NOT NULL AND email != ''");
        $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (empty($members)) {
            return ['success' => false, 'sent' => 0, 'failed' => 0, 'error' => 'No members with valid emails found'];
        }
        
        $sent = 0;
        $failed = 0;
        $failed_emails = [];
        
        foreach ($members as $member) {
            $personalizedMessage = str_replace(
                ['{member_name}', '{member_first_name}'],
                [$member['first_name'] . ' ' . $member['last_name'], $member['first_name']],
                $message
            );
            
            if (sendEmail($member['email'], $subject, $personalizedMessage, true)) {
                $sent++;
            } else {
                $failed++;
                $failed_emails[] = $member['email'];
            }
        }
        
        // Log the notification
        error_log("Notification sent: $sent successful, $failed failed for activity type: $activityType");
        
        return [
            'success' => $sent > 0,
            'sent' => $sent,
            'failed' => $failed,
            'failed_emails' => $failed_emails
        ];
        
    } catch (Exception $e) {
        error_log("Notification error: " . $e->getMessage());
        return ['success' => false, 'sent' => 0, 'failed' => 0, 'error' => $e->getMessage()];
    }
}

/**
 * Build email HTML template
 * @param string $title Email title
 * @param string $content Email content
 * @param string $buttonText Button text
 * @param string $buttonUrl Button URL
 * @return string HTML email template
 */
function buildNotificationEmail($title, $content, $buttonText = 'View Details', $buttonUrl = '') {
    $churchName = 'Church Management System';
    $baseUrl = BASE_URL;
    
    $buttonHtml = '';
    if ($buttonUrl) {
        $buttonHtml = "<a href='" . $buttonUrl . "' class='button'>" . $buttonText . "</a>";
    }
    
    $html = "<!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1.0'>
        <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4; }
            .container { max-width: 600px; margin: 0 auto; background-color: #ffffff; }
            .header { background-color: #4F46E5; color: white; padding: 20px; text-align: center; }
            .content { padding: 30px; }
            .button { display: inline-block; padding: 12px 24px; background-color: #4F46E5; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
            .footer { background-color: #f9f9f9; padding: 20px; text-align: center; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>" . $churchName . "</h1>
            </div>
            <div class='content'>
                <h2>" . $title . "</h2>
                " . $content . "
                " . $buttonHtml . "
            </div>
            <div class='footer'>
                <p>This email was sent to you because you are a registered member of " . $churchName . ".</p>
                <p>If you no longer wish to receive these notifications, please contact the church administrator.</p>
            </div>
        </div>
    </body>
    </html>";
    
    return $html;
}

/**
 * Log activity
 */
function logActivity($action, $tableName = null, $recordId = null, $oldValues = null, $newValues = null) {
    global $db;
    
    if (!$db) return;
    
    try {
        $stmt = $db->prepare("
            INSERT INTO activity_logs (user_id, action, table_name, record_id, old_values, new_values, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $_SESSION['user_id'] ?? null,
            $action,
            $tableName,
            $recordId,
            $oldValues ? json_encode($oldValues) : null,
            $newValues ? json_encode($newValues) : null,
            $_SERVER['REMOTE_ADDR'] ?? null,
            $_SERVER['HTTP_USER_AGENT'] ?? null
        ]);
    } catch (Exception $e) {
        // Log error silently
        error_log("Activity log error: " . $e->getMessage());
    }
}

/**
 * Get pagination data
 */
function getPaginationData($currentPage, $totalRecords, $recordsPerPage = 10) {
    $totalPages = ceil($totalRecords / $recordsPerPage);
    $offset = ($currentPage - 1) * $recordsPerPage;
    
    return [
        'current_page' => $currentPage,
        'total_pages' => $totalPages,
        'total_records' => $totalRecords,
        'records_per_page' => $recordsPerPage,
        'offset' => $offset,
        'has_prev' => $currentPage > 1,
        'has_next' => $currentPage < $totalPages
    ];
}

/**
 * Generate pagination HTML
 */
function generatePagination($paginationData, $baseUrl) {
    if ($paginationData['total_pages'] <= 1) return '';
    
    $html = '<nav class="flex items-center justify-between border-t border-gray-200 bg-white px-4 py-3 sm:px-6">';
    $html .= '<div class="flex flex-1 justify-between sm:hidden">';
    
    // Previous button
    if ($paginationData['has_prev']) {
        $html .= '<a href="' . $baseUrl . '?page=' . ($paginationData['current_page'] - 1) . '" class="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">Previous</a>';
    }
    
    // Next button
    if ($paginationData['has_next']) {
        $html .= '<a href="' . $baseUrl . '?page=' . ($paginationData['current_page'] + 1) . '" class="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50">Next</a>';
    }
    
    $html .= '</div>';
    $html .= '<div class="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">';
    $html .= '<div><p class="text-sm text-gray-700">Showing <span class="font-medium">' . (($paginationData['current_page'] - 1) * $paginationData['records_per_page'] + 1) . '</span> to <span class="font-medium">' . min($paginationData['current_page'] * $paginationData['records_per_page'], $paginationData['total_records']) . '</span> of <span class="font-medium">' . $paginationData['total_records'] . '</span> results</p></div>';
    
    $html .= '<div><nav class="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">';
    
    // Previous button
    if ($paginationData['has_prev']) {
        $html .= '<a href="' . $baseUrl . '?page=' . ($paginationData['current_page'] - 1) . '" class="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0">Previous</a>';
    }
    
    // Page numbers
    $start = max(1, $paginationData['current_page'] - 2);
    $end = min($paginationData['total_pages'], $paginationData['current_page'] + 2);
    
    for ($i = $start; $i <= $end; $i++) {
        $activeClass = $i == $paginationData['current_page'] ? 'bg-indigo-600 text-white' : 'text-gray-900 ring-1 ring-inset ring-gray-300 hover:bg-gray-50';
        $html .= '<a href="' . $baseUrl . '?page=' . $i . '" class="relative inline-flex items-center px-4 py-2 text-sm font-semibold ' . $activeClass . ' focus:z-20 focus:outline-offset-0">' . $i . '</a>';
    }
    
    // Next button
    if ($paginationData['has_next']) {
        $html .= '<a href="' . $baseUrl . '?page=' . ($paginationData['current_page'] + 1) . '" class="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0">Next</a>';
    }
    
    $html .= '</nav></div></div></nav>';
    
    return $html;
}
?>
