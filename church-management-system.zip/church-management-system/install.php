<?php
/**
 * Installation Script
 * Church Management System
 */

// Check if already installed
if (file_exists('config/installed.lock')) {
    die('System is already installed. Delete config/installed.lock to reinstall.');
}

$step = $_GET['step'] ?? 1;
$error = '';
$success = '';

if ($_POST) {
    switch ($step) {
        case 1:
            // Database connection test
            $host = $_POST['db_host'] ?? 'localhost';
            $username = $_POST['db_username'] ?? 'root';
            $password = $_POST['db_password'] ?? '';
            $database = $_POST['db_name'] ?? 'church_management';
            
            try {
                $pdo = new PDO("mysql:host=$host", $username, $password);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                // Create database if it doesn't exist
                $pdo->exec("CREATE DATABASE IF NOT EXISTS `$database`");
                $pdo->exec("USE `$database`");
                
                // Store config for next step
                $_SESSION['db_config'] = compact('host', 'username', 'password', 'database');
                header('Location: install.php?step=2');
                exit();
            } catch (PDOException $e) {
                $error = 'Database connection failed: ' . $e->getMessage();
            }
            break;
            
        case 2:
            // Create tables
            $config = $_SESSION['db_config'];
            try {
                $pdo = new PDO("mysql:host={$config['host']};dbname={$config['database']}", 
                              $config['username'], $config['password']);
                $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                
                $sql = file_get_contents('database/schema.sql');
                $pdo->exec($sql);
                
                // Update config file
                $configContent = "<?php
/**
 * Database Configuration
 * Church Management System
 */

class Database {
    private \$host = '{$config['host']}';
    private \$db_name = '{$config['database']}';
    private \$username = '{$config['username']}';
    private \$password = '{$config['password']}';
    private \$charset = 'utf8mb4';
    public \$conn;

    public function getConnection() {
        \$this->conn = null;
        
        try {
            \$dsn = \"mysql:host=\" . \$this->host . \";dbname=\" . \$this->db_name . \";charset=\" . \$this->charset;
            \$this->conn = new PDO(\$dsn, \$this->username, \$this->password);
            \$this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            \$this->conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        } catch(PDOException \$exception) {
            echo \"Connection error: \" . \$exception->getMessage();
        }
        
        return \$this->conn;
    }
}
?>";
                
                file_put_contents('config/database.php', $configContent);
                
                // Create uploads directory
                if (!is_dir('uploads')) {
                    mkdir('uploads', 0755, true);
                }
                
                // Create installed lock file
                file_put_contents('config/installed.lock', date('Y-m-d H:i:s'));
                
                $success = 'Installation completed successfully!';
                $step = 3;
            } catch (PDOException $e) {
                $error = 'Database setup failed: ' . $e->getMessage();
            }
            break;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install - Church Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="max-w-md w-full space-y-8">
        <div>
            <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                Church Management System
            </h2>
            <p class="mt-2 text-center text-sm text-gray-600">
                Installation Wizard
            </p>
        </div>
        
        <?php if ($error): ?>
            <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md">
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($step == 1): ?>
            <form class="mt-8 space-y-6" method="POST">
                <div class="space-y-4">
                    <div>
                        <label for="db_host" class="block text-sm font-medium text-gray-700">Database Host</label>
                        <input id="db_host" name="db_host" type="text" required 
                               value="localhost"
                               class="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    
                    <div>
                        <label for="db_username" class="block text-sm font-medium text-gray-700">Database Username</label>
                        <input id="db_username" name="db_username" type="text" required 
                               value="root"
                               class="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    
                    <div>
                        <label for="db_password" class="block text-sm font-medium text-gray-700">Database Password</label>
                        <input id="db_password" name="db_password" type="password" 
                               class="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    
                    <div>
                        <label for="db_name" class="block text-sm font-medium text-gray-700">Database Name</label>
                        <input id="db_name" name="db_name" type="text" required 
                               value="church_management"
                               class="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                </div>

                <div>
                    <button type="submit" 
                            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Test Connection & Continue
                    </button>
                </div>
            </form>
        <?php elseif ($step == 2): ?>
            <div class="text-center">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Ready to Install</h3>
                <p class="text-gray-600 mb-6">Click the button below to create the database tables and complete the installation.</p>
                
                <form method="POST">
                    <button type="submit" 
                            class="bg-indigo-600 text-white px-6 py-3 rounded-md hover:bg-indigo-700">
                        Complete Installation
                    </button>
                </form>
            </div>
        <?php elseif ($step == 3): ?>
            <div class="text-center">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Installation Complete!</h3>
                <p class="text-gray-600 mb-6">Your Church Management System has been successfully installed.</p>
                
                <div class="space-y-4">
                    <a href="admin/login.php" 
                       class="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 block">
                        Go to Admin Panel
                    </a>
                    <a href="index.php" 
                       class="w-full bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 block">
                        View Website
                    </a>
                </div>
                
                <div class="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                    <p class="text-sm text-yellow-800">
                        <strong>Important:</strong> Delete this install.php file for security reasons.
                    </p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
