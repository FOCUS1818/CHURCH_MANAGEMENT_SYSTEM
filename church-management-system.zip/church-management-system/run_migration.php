<?php
/**
 * Database Migration Runner
 * Run this script to create the small_groups table and update members table
 */

$host = 'localhost';
$db_name = 'church_management';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create small_groups table
    $sql = "
    CREATE TABLE IF NOT EXISTS small_groups (
        id INT PRIMARY KEY AUTO_INCREMENT,
        group_name VARCHAR(100) NOT NULL,
        meeting_day VARCHAR(20),
        meeting_time TIME,
        location VARCHAR(200),
        description TEXT,
        is_active BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    ";
    $conn->exec($sql);
    echo "Table 'small_groups' created successfully!\n";
    
    // Add small_group_id column to members table if it doesn't exist
    try {
        $sql = "ALTER TABLE members ADD COLUMN small_group_id INT DEFAULT NULL";
        $conn->exec($sql);
        echo "Column 'small_group_id' added to members table!\n";
    } catch (PDOException $e) {
        // Column might already exist
        if (strpos($e->getMessage(), 'Duplicate column') === false) {
            echo "Note: " . $e->getMessage() . "\n";
        }
    }
    
    // Add household_id column to members table if it doesn't exist
    try {
        $sql = "ALTER TABLE members ADD COLUMN household_id INT DEFAULT NULL";
        $conn->exec($sql);
        echo "Column 'household_id' added to members table!\n";
    } catch (PDOException $e) {
        // Column might already exist
        if (strpos($e->getMessage(), 'Duplicate column') === false) {
            echo "Note: " . $e->getMessage() . "\n";
        }
    }
    
    // Insert sample data
    $sql = "
    INSERT INTO small_groups (group_name, meeting_day, meeting_time, location, description, is_active) VALUES
    ('Sunday School', 'Sunday', '09:00:00', 'Room 101', 'Bible study for all ages', TRUE),
    ('Youth Group', 'Friday', '18:00:00', 'Youth Center', 'Youth fellowship and Bible study', TRUE),
    ('Bible Study Group', 'Wednesday', '19:00:00', 'Main Hall', 'Mid-week Bible study', TRUE)
    ";
    $conn->exec($sql);
    echo "Sample data inserted successfully!\n";
    
    // Create households table if it doesn't exist
    $sql = "
    CREATE TABLE IF NOT EXISTS households (
        id INT PRIMARY KEY AUTO_INCREMENT,
        household_name VARCHAR(100) NOT NULL,
        address TEXT,
        phone VARCHAR(20),
        email VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );
    ";
    $conn->exec($sql);
    echo "Table 'households' created successfully!\n";
    
echo "\nMigration completed successfully!\n";
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
