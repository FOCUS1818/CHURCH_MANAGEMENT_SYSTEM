<?php
/**
 * Donations Table Migration Script
 * Run this script to create the donations table if it doesn't exist
 */

$host = 'localhost';
$db_name = 'church_management';
$username = 'root';
$password = '';

try {
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "Connected to database successfully.\n";
    
    // Check if donations table exists
    $check = $conn->query("SHOW TABLES LIKE 'donations'");
    if ($check->rowCount() > 0) {
        echo "Table 'donations' already exists.\n";
        
        // Check if it has all required columns
        $columns = ['donor_name', 'donor_email', 'donor_phone', 'amount', 'payment_method', 
                    'donation_type', 'donation_purpose', 'is_anonymous', 'payment_status', 
                    'transaction_id', 'payment_reference', 'notes', 'donation_date'];
        
        $missingColumns = [];
        foreach ($columns as $col) {
            $colCheck = $conn->query("SHOW COLUMNS FROM donations LIKE '$col'");
            if ($colCheck->rowCount() == 0) {
                $missingColumns[] = $col;
            }
        }
        
        if (empty($missingColumns)) {
            echo "All required columns exist. No migration needed.\n";
        } else {
            echo "Missing columns: " . implode(', ', $missingColumns) . "\n";
            echo "Please recreate the table or add missing columns manually.\n";
        }
    } else {
        // Create donations table
        $sql = "
        CREATE TABLE donations (
            id INT PRIMARY KEY AUTO_INCREMENT,
            donor_name VARCHAR(100) NOT NULL,
            donor_email VARCHAR(100) NOT NULL,
            donor_phone VARCHAR(20),
            amount DECIMAL(10,2) NOT NULL,
            payment_method ENUM('credit_card', 'debit_card', 'bank_transfer', 'cash', 'check') NOT NULL,
            donation_type ENUM('tithe', 'offering', 'special', 'building_fund', 'missions', 'other') DEFAULT 'offering',
            donation_purpose VARCHAR(200),
            is_anonymous BOOLEAN DEFAULT FALSE,
            payment_status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
            transaction_id VARCHAR(100),
            payment_reference VARCHAR(100),
            notes TEXT,
            donation_date DATE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        );
        ";
        $conn->exec($sql);
        echo "Table 'donations' created successfully!\n";
    }
    
    echo "\nMigration completed!\n";
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
