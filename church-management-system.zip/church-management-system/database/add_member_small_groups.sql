 -- Create pivot table for member small groups (many-to-many relationship)
-- This allows members to belong to multiple small groups

CREATE TABLE IF NOT EXISTS member_small_groups (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL,
    small_group_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (small_group_id) REFERENCES small_groups(id) ON DELETE CASCADE,
    UNIQUE KEY unique_member_group (member_id, small_group_id)
);

-- Drop the old single small_group_id column from members table if it exists
-- ALTER TABLE members DROP COLUMN small_group_id;
