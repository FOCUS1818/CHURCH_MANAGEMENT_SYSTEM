at-- Fix: Add small_group_id and household_id columns to members table
-- Run this in phpMyAdmin or MySQL workbench

-- Add small_group_id column if it doesn't exist
ALTER TABLE members ADD COLUMN small_group_id INT DEFAULT NULL;

-- Add foreign key constraint
ALTER TABLE members ADD FOREIGN KEY (small_group_id) REFERENCES small_groups(id) ON DELETE SET NULL;

-- Add household_id column if it doesn't exist
ALTER TABLE members ADD COLUMN household_id INT DEFAULT NULL;

-- Add foreign key constraint
ALTER TABLE members ADD FOREIGN KEY (household_id) REFERENCES households(id) ON DELETE SET NULL;

-- If households table doesn't exist, create it
CREATE TABLE IF NOT EXISTS households (
    id INT PRIMARY KEY AUTO_INCREMENT,
    household_name VARCHAR(100) NOT NULL,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- If small_groups table doesn't exist, create it
CREATE TABLE IF NOT EXISTS small_groups (
    id INT PRIMARY KEY AUTO_INCREMENT,
    group_name VARCHAR(100) NOT NULL,
    meeting_day VARCHAR(20),
    meeting_time TIME,
    location VARCHAR(200),
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert sample small groups if table is empty
INSERT INTO small_groups (group_name, meeting_day, meeting_time, location, description, is_active) 
SELECT 'Sunday School', 'Sunday', '09:00:00', 'Room 101', 'Bible study for all ages', TRUE
WHERE NOT EXISTS (SELECT 1 FROM small_groups LIMIT 1);

INSERT INTO small_groups (group_name, meeting_day, meeting_time, location, description, is_active) 
SELECT 'Youth Group', 'Friday', '18:00:00', 'Youth Center', 'Youth fellowship and Bible study', TRUE
WHERE NOT EXISTS (SELECT 1 FROM small_groups WHERE group_name = 'Youth Group');

INSERT INTO small_groups (group_name, meeting_day, meeting_time, location, description, is_active) 
SELECT 'Bible Study Group', 'Wednesday', '19:00:00', 'Main Hall', 'Mid-week Bible study', TRUE
WHERE NOT EXISTS (SELECT 1 FROM small_groups WHERE group_name = 'Bible Study Group');
