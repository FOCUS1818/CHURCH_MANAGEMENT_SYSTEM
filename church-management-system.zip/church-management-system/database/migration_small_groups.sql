-- Migration: Add Small Groups Table and small_group_id to Members
-- Run this SQL to create the small_groups table and update members table

-- Create small_groups table
CREATE TABLE IF NOT EXISTS small_groups (
    id INT PRIMARY KEY AUTO_INCREMENT,
    group_name VARCHAR(100) NOT NULL,
    meeting_day VARCHAR(20),
    meeting_time TIME,
    location VARCHAR(200),
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Add small_group_id column to members table if it doesn't exist
ALTER TABLE members ADD COLUMN small_group_id INT DEFAULT NULL;

-- Add foreign key constraint
ALTER TABLE members ADD FOREIGN KEY (small_group_id) REFERENCES small_groups(id) ON DELETE SET NULL;

-- Insert sample small groups
INSERT INTO small_groups (group_name, meeting_day, meeting_time, location, description, is_active) VALUES
('Sunday School', 'Sunday', '09:00:00', 'Room 101', 'Bible study for all ages', TRUE),
('Youth Group', 'Friday', '18:00:00', 'Youth Center', 'Youth fellowship and Bible study', TRUE),
('Bible Study Group', 'Wednesday', '19:00:00', 'Main Hall', 'Mid-week Bible study', TRUE);
