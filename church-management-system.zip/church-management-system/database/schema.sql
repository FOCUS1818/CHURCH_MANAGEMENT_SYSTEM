-- Church Management System Database Schema
-- MySQL Database Creation Script

CREATE DATABASE IF NOT EXISTS church_management;
USE church_management;

-- Admin/Staff Users Table
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role ENUM('super_admin', 'pastor', 'staff', 'volunteer') DEFAULT 'staff',
    is_active BOOLEAN DEFAULT TRUE,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Households Table
CREATE TABLE households (
    id INT PRIMARY KEY AUTO_INCREMENT,
    household_name VARCHAR(100) NOT NULL,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Members Table
CREATE TABLE members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    household_id INT,
    small_group_id INT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    middle_name VARCHAR(50),
    gender ENUM('male', 'female', 'other') NOT NULL,
    date_of_birth DATE,
    marital_status ENUM('single', 'married', 'divorced', 'widowed') DEFAULT 'single',
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    photo VARCHAR(255),
    family_role ENUM('father', 'mother', 'child', 'other') DEFAULT 'other',
    membership_status ENUM('active', 'inactive', 'visitor', 'deceased') DEFAULT 'visitor',
    membership_class_completed BOOLEAN DEFAULT FALSE,
    baptism_date DATE,
    spiritual_gifts TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (household_id) REFERENCES households(id) ON DELETE SET NULL,
    FOREIGN KEY (small_group_id) REFERENCES small_groups(id) ON DELETE SET NULL
);

-- Events Table
CREATE TABLE events (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    event_type ENUM('service', 'meeting', 'youth', 'community', 'special') DEFAULT 'service',
    start_datetime DATETIME NOT NULL,
    end_datetime DATETIME,
    location VARCHAR(200),
    max_capacity INT,
    requires_rsvp BOOLEAN DEFAULT FALSE,
    rsvp_deadline DATETIME,
    flyer_image VARCHAR(255),
    live_stream_url VARCHAR(500),
    is_live BOOLEAN DEFAULT FALSE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Attendance Table
CREATE TABLE attendance (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL,
    event_id INT NOT NULL,
    attended BOOLEAN DEFAULT TRUE,
    check_in_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    UNIQUE KEY unique_attendance (member_id, event_id)
);

-- Sermons Table
CREATE TABLE sermons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    speaker VARCHAR(100) NOT NULL,
    sermon_date DATE NOT NULL,
    video_url VARCHAR(500),
    audio_url VARCHAR(500),
    notes_pdf VARCHAR(255),
    live_stream_url VARCHAR(500),
    is_live BOOLEAN DEFAULT FALSE,
    description TEXT,
    scripture_reference VARCHAR(200),
    topic VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Ministries Table
CREATE TABLE ministries (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    leader_id INT,
    leader_photo VARCHAR(255),
    custom_link VARCHAR(500),
    contact_email VARCHAR(100),
    meeting_schedule TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (leader_id) REFERENCES members(id) ON DELETE SET NULL
);

-- Ministry Members Pivot Table
CREATE TABLE ministry_members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ministry_id INT NOT NULL,
    member_id INT NOT NULL,
    role VARCHAR(50),
    joined_date DATE DEFAULT (CURRENT_DATE),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (ministry_id) REFERENCES ministries(id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    UNIQUE KEY unique_ministry_member (ministry_id, member_id)
);

-- Contact Messages Table
CREATE TABLE contact_messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    subject VARCHAR(200),
    message TEXT NOT NULL,
    is_handled BOOLEAN DEFAULT FALSE,
    handled_by INT,
    handled_at DATETIME,
    response TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (handled_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Documents Table
CREATE TABLE documents (
    id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT,
    document_type ENUM('baptism_cert', 'training_cert', 'id_copy', 'other') NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT,
    uploaded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Activity Logs Table
CREATE TABLE activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Weekly Verses Table
CREATE TABLE weekly_verses (
    id INT PRIMARY KEY AUTO_INCREMENT,
    verse_text TEXT NOT NULL,
    reference VARCHAR(100) NOT NULL,
    week_start DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default admin user
INSERT INTO users (username, email, password_hash, first_name, last_name, role) 
VALUES ('admin', 'admin@church.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'User', 'super_admin');

-- Insert sample ministries
INSERT INTO ministries (name, description, is_active) VALUES
('Youth Ministry', 'Engaging young people in faith and community', TRUE),
('Women\'s Ministry', 'Supporting and empowering women in the church', TRUE),
('Men\'s Ministry', 'Building strong Christian men and leaders', TRUE),
('Worship Team', 'Leading the congregation in worship', TRUE),
('Outreach Ministry', 'Serving the community and spreading the gospel', TRUE),
('Children\'s Ministry', 'Nurturing children in their faith journey', TRUE);

-- Donations Table
CREATE TABLE donations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    donor_name VARCHAR(100) NOT NULL,
    donor_email VARCHAR(100) NOT NULL,
    donor_phone VARCHAR(20),
    amount DECIMAL(10,2) NOT NULL,
    payment_method ENUM('credit_card', 'debit_card', 'bank_transfer', 'cash', 'check') NOT NULL,
    donation_type ENUM('tithe', 'offering', 'special', 'building_fund', 'missions', 'other') DEFAULT 'offering',
    donation_purpose VARCHAR(200),
    is_anonymous BOOLEAN DEFAULT FALSE,
    payment_status ENUM('pending', 'completed', 'failed', 'cancelled') DEFAULT 'pending',
    transaction_id VARCHAR(100),
    payment_reference VARCHAR(100),
    notes TEXT,
    donation_date DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Live Streams Table
CREATE TABLE live_streams (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    stream_url VARCHAR(500) NOT NULL,
    stream_type ENUM('youtube', 'vimeo', 'hls', 'other') DEFAULT 'youtube',
    is_active BOOLEAN DEFAULT FALSE,
    event_id INT,
    sermon_id INT,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE SET NULL,
    FOREIGN KEY (sermon_id) REFERENCES sermons(id) ON DELETE SET NULL,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Small Groups Table
CREATE TABLE small_groups (
    id INT PRIMARY KEY AUTO_INCREMENT,
    group_name VARCHAR(100) NOT NULL,
    meeting_day VARCHAR(20),
    meeting_time TIME,
    location VARCHAR(200),
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Insert sample small groups
INSERT INTO small_groups (group_name, meeting_day, meeting_time, location, description, is_active) VALUES
('Sunday School', 'Sunday', '09:00:00', 'Room 101', 'Bible study for all ages', TRUE),
('Youth Group', 'Friday', '18:00:00', 'Youth Center', 'Youth fellowship and Bible study', TRUE),
('Bible Study Group', 'Wednesday', '19:00:00', 'Main Hall', 'Mid-week Bible study', TRUE);

-- Insert sample weekly verse
INSERT INTO weekly_verses (verse_text, reference, week_start, is_active)
VALUES ('For God so loved the world that he gave his one and only Son, that whoever believes in him shall not perish but have eternal life.', 'John 3:16', CURDATE(), TRUE);
