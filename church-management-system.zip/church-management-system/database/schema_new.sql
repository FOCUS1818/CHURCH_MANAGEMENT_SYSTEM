-- OLEBU Church Management System Database Schema
-- Three-Tier Architecture
-- MySQL Database Creation Script

-- Create database
CREATE DATABASE IF NOT EXISTS olebu_church;
USE olebu_church;

-- ============================================
-- USERS & AUTHENTICATION TABLES
-- ============================================

-- System Users Table (for admin access)
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role ENUM('admin', 'elder', 'financial_staff', 'member', 'non_member') DEFAULT 'member',
    is_active BOOLEAN DEFAULT TRUE,
    last_login DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_username (username),
    INDEX idx_email (email),
    INDEX idx_role (role)
) ENGINE=InnoDB;

-- ============================================
-- HOUSEHOLDS TABLE
-- ============================================

CREATE TABLE households (
    household_id INT PRIMARY KEY AUTO_INCREMENT,
    family_name VARCHAR(100) NOT NULL,
    mailing_address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_family_name (family_name)
) ENGINE=InnoDB;

-- ============================================
-- SMALL GROUPS TABLE
-- ============================================

CREATE TABLE small_groups (
    group_id INT PRIMARY KEY AUTO_INCREMENT,
    group_name VARCHAR(100) NOT NULL,
    meeting_day VARCHAR(20),
    meeting_time VARCHAR(20),
    location VARCHAR(200),
    leader_id INT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_group_name (group_name),
    INDEX idx_meeting_day (meeting_day)
) ENGINE=InnoDB;

-- ============================================
-- MEMBERS TABLE
-- ============================================

CREATE TABLE members (
    member_id INT PRIMARY KEY AUTO_INCREMENT,
    household_id INT,
    small_group_id INT,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    join_date DATE NOT NULL,
    gender ENUM('male', 'female', 'other'),
    date_of_birth DATE,
    marital_status ENUM('single', 'married', 'divorced', 'widowed') DEFAULT 'single',
    address TEXT,
    photo VARCHAR(255),
    membership_status ENUM('active', 'inactive', 'visitor') DEFAULT 'visitor',
    baptism_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (household_id) REFERENCES households(household_id) ON DELETE SET NULL,
    FOREIGN KEY (small_group_id) REFERENCES small_groups(group_id) ON DELETE SET NULL,
    INDEX idx_first_name (first_name),
    INDEX idx_last_name (last_name),
    INDEX idx_household (household_id),
    INDEX idx_small_group (small_group_id),
    INDEX idx_membership_status (membership_status)
) ENGINE=InnoDB;

-- ============================================
-- MEMBER GROUP MEMBERSHIP (Many-to-Many)
-- ============================================

CREATE TABLE member_group_membership (
    member_id INT NOT NULL,
    group_id INT NOT NULL,
    enrollment_date DATE DEFAULT (CURRENT_DATE),
    role VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (member_id, group_id),
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    FOREIGN KEY (group_id) REFERENCES small_groups(group_id) ON DELETE CASCADE,
    INDEX idx_group (group_id),
    INDEX idx_enrollment_date (enrollment_date)
) ENGINE=InnoDB;

-- ============================================
-- EVENTS TABLE
-- ============================================

CREATE TABLE events (
    event_id INT PRIMARY KEY AUTO_INCREMENT,
    event_name VARCHAR(200) NOT NULL,
    event_date DATE NOT NULL,
    event_time TIME,
    description TEXT,
    location VARCHAR(200),
    event_type ENUM('service', 'meeting', 'youth', 'community', 'special', 'worship') DEFAULT 'service',
    max_capacity INT,
    created_by INT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_event_date (event_date),
    INDEX idx_event_type (event_type)
) ENGINE=InnoDB;

-- ============================================
-- ATTENDANCE TABLE
-- ============================================

CREATE TABLE attendance (
    attendance_id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT NOT NULL,
    event_id INT,
    service_type VARCHAR(50),
    attendance_date DATE NOT NULL,
    exercise_type ENUM('present', 'absent', 'excused') DEFAULT 'present',
    notes TEXT,
    recorded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES events(event_id) ON DELETE SET NULL,
    FOREIGN KEY (recorded_by) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_member (member_id),
    INDEX idx_event (event_id),
    INDEX idx_attendance_date (attendance_date),
    INDEX idx_service_type (service_type)
) ENGINE=InnoDB;

-- ============================================
-- MINISTRIES TABLE
-- ============================================

CREATE TABLE ministries (
    dept_id INT PRIMARY KEY AUTO_INCREMENT,
    dept_name VARCHAR(100) NOT NULL,
    description TEXT,
    budget DECIMAL(10,2) DEFAULT 0.00,
    leader_id INT,
    contact_email VARCHAR(100),
    meeting_schedule TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (leader_id) REFERENCES members(member_id) ON DELETE SET NULL,
    INDEX idx_dept_name (dept_name),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB;

-- Ministry Members (Many-to-Many)
CREATE TABLE ministry_members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    dept_id INT NOT NULL,
    member_id INT NOT NULL,
    role VARCHAR(50),
    joined_date DATE DEFAULT (CURRENT_DATE),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES ministries(dept_id) ON DELETE CASCADE,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE CASCADE,
    UNIQUE KEY unique_ministry_member (dept_id, member_id)
) ENGINE=InnoDB;

-- ============================================
-- CONTRIBUTIONS TABLE
-- ============================================

CREATE TABLE contributions (
    gift_id INT PRIMARY KEY AUTO_INCREMENT,
    member_id INT,
    amount DECIMAL(10,2) NOT NULL,
    contribution_date DATE NOT NULL,
    fund_type ENUM('tithe', 'offering', 'special', 'building_fund', 'missions', 'other') DEFAULT 'offering',
    payment_method ENUM('cash', 'check', 'bank_transfer', 'card', 'other') DEFAULT 'cash',
    transaction_reference VARCHAR(100),
    notes TEXT,
    recorded_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(member_id) ON DELETE SET NULL,
    FOREIGN KEY (recorded_by) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_member (member_id),
    INDEX idx_contribution_date (contribution_date),
    INDEX idx_fund_type (fund_type)
) ENGINE=InnoDB;

-- ============================================
-- ACTIVITY LOGS TABLE
-- ============================================

CREATE TABLE activity_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(50),
    record_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    INDEX idx_user (user_id),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- ============================================
-- PASSWORD RESET TABLE
-- ============================================

CREATE TABLE password_resets (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) NOT NULL,
    token VARCHAR(255) NOT NULL,
    expires_at DATETIME NOT NULL,
    used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_token (token)
) ENGINE=InnoDB;

-- ============================================
-- DEFAULT DATA
-- ============================================

-- Insert default admin user (password: admin123)
INSERT INTO users (username, email, password_hash, first_name, last_name, role) 
VALUES ('admin', 'admin@olebu.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System', 'Admin', 'admin');

-- Insert sample small groups
INSERT INTO small_groups (group_name, meeting_day, meeting_time, location, is_active) VALUES
('Sunday School', 'Sunday', '09:00 AM', 'Room 101', TRUE),
('Bible Study Group A', 'Wednesday', '07:00 PM', 'Fellowship Hall', TRUE),
('Bible Study Group B', 'Thursday', '07:00 PM', 'Room 102', TRUE),
('Prayer Group', 'Friday', '06:00 PM', 'Sanctuary', TRUE),
('Youth Group', 'Saturday', '04:00 PM', 'Youth Center', TRUE);

-- Insert sample ministries
INSERT INTO ministries (dept_name, description, budget, is_active) VALUES
('Worship Department', 'Leads the congregation in worship and music', 5000.00, TRUE),
('Children Ministry', 'Nurtures children in faith', 3000.00, TRUE),
('Youth Ministry', 'Engages youth in church activities', 4000.00, TRUE),
('Men Ministry', 'Builds brotherhood among men', 2000.00, TRUE),
('Women Ministry', 'Empowers women in faith', 2000.00, TRUE),
('Outreach Ministry', 'Community service and evangelism', 5000.00, TRUE);

-- Insert sample household
INSERT INTO households (family_name, mailing_address, phone) VALUES
('Sample Family', '123 Church Street, City, State', '555-0100');

-- Insert sample member
INSERT INTO members (household_id, small_group_id, first_name, last_name, email, phone, join_date, membership_status) VALUES
(1, 1, 'John', 'Doe', 'john.doe@email.com', '555-0101', CURDATE(), 'active');

-- Insert sample event
INSERT INTO events (event_name, event_date, event_time, event_type, location, is_active) VALUES
('Sunday Service', CURDATE(), '10:00 AM', 'service', 'Main Sanctuary', TRUE),
('Wednesday Bible Study', DATE_ADD(CURDATE(), INTERVAL 2 DAY), '07:00 PM', 'meeting', 'Fellowship Hall', TRUE);

-- Insert sample attendance
INSERT INTO attendance (member_id, event_id, service_type, attendance_date, exercise_type) VALUES
(1, 1, 'Sunday Service', CURDATE(), 'present');

-- Insert sample contribution
INSERT INTO contributions (member_id, amount, contribution_date, fund_type, payment_method) VALUES
(1, 100.00, CURDATE(), 'tithe', 'cash');
