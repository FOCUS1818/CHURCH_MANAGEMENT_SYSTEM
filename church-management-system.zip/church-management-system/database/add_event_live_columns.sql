-- Add missing columns to events table for live streaming support
-- Run this migration to fix the column not found error

ALTER TABLE events 
ADD COLUMN IF NOT EXISTS live_stream_url VARCHAR(500) AFTER flyer_image,
ADD COLUMN IF NOT EXISTS is_live BOOLEAN DEFAULT FALSE AFTER live_stream_url,
ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT FALSE AFTER is_live;

-- If ADD COLUMN IF NOT EXISTS doesn't work in MySQL, use this alternative:
-- ALTER TABLE events ADD COLUMN live_stream_url VARCHAR(500);
-- ALTER TABLE events ADD COLUMN is_live BOOLEAN DEFAULT FALSE;
-- ALTER TABLE events ADD COLUMN is_featured BOOLEAN DEFAULT FALSE;
