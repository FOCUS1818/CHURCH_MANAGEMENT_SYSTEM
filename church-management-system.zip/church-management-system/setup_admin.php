<?php
/**
 * Admin Setup Utility
 * Church Management System
 */

require_once 'config/config.php';

use App\Database;

echo "<h2>Admin Setup Utility</h2>";

$database = new Database();
$db = $database->getConnection();

if (!$db) {
    echo "❌ Database connection failed. Please check your database configuration.<br>";
    exit;
}

echo "✅ Database connection successful<br>";

// Check if users table exists
try {
    $stmt = $db->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() == 0) {
        echo "❌ Users table does not exist. Please run the database schema first.<br>";
        echo "<p><a href='database/schema.sql' target='_blank'>View Database Schema</a></p>";
        exit;
    }
    echo "✅ Users table exists<br>";
} catch (Exception $e) {
    echo "❌ Error checking users table: " . $e->getMessage() . "<br>";
    exit;
}

// Check if admin user exists
$stmt = $db->query("SELECT COUNT(*) as count FROM users WHERE role = 'super_admin'");
$result = $stmt->fetch(\PDO::FETCH_ASSOC);

if ($result['count'] == 0) {
    echo "❌ No admin users found. Creating default admin user...<br>";
    
    if ($_POST && isset($_POST['create_admin'])) {
        $username = $_POST['username'] ?? 'admin';
        $email = $_POST['email'] ?? 'admin@church.com';
        $password = $_POST['password'] ?? 'admin123';
        $firstName = $_POST['first_name'] ?? 'Admin';
        $lastName = $_POST['last_name'] ?? 'User';
        
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        try {
            $stmt = $db->prepare("INSERT INTO users (username, email, password_hash, first_name, last_name, role, is_active) VALUES (?, ?, ?, ?, ?, 'super_admin', 1)");
            $stmt->execute([$username, $email, $hashedPassword, $firstName, $lastName]);
            
            echo "✅ Admin user created successfully!<br>";
            echo "Username: " . htmlspecialchars($username) . "<br>";
            echo "Email: " . htmlspecialchars($email) . "<br>";
            echo "Password: " . htmlspecialchars($password) . "<br>";
            echo "<p><a href='admin/login.php'>Go to Login</a></p>";
        } catch (Exception $e) {
            echo "❌ Error creating admin user: " . $e->getMessage() . "<br>";
        }
    } else {
        // Show form to create admin user
        ?>
        <form method="POST">
            <h3>Create Admin User:</h3>
            <div>
                <label>Username:</label><br>
                <input type="text" name="username" value="admin" required>
            </div>
            <div>
                <label>Email:</label><br>
                <input type="email" name="email" value="admin@church.com" required>
            </div>
            <div>
                <label>Password:</label><br>
                <input type="password" name="password" value="admin123" required>
            </div>
            <div>
                <label>First Name:</label><br>
                <input type="text" name="first_name" value="Admin" required>
            </div>
            <div>
                <label>Last Name:</label><br>
                <input type="text" name="last_name" value="User" required>
            </div>
            <div>
                <button type="submit" name="create_admin">Create Admin User</button>
            </div>
        </form>
        <?php
    }
} else {
    echo "✅ Admin users found: " . $result['count'] . "<br>";
    
    // Show existing admin users
    $stmt = $db->query("SELECT id, username, email, first_name, last_name, role, is_active FROM users WHERE role = 'super_admin'");
    $admins = $stmt->fetchAll(\PDO::FETCH_ASSOC);
    
    echo "<h3>Existing Admin Users:</h3>";
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Name</th><th>Role</th><th>Active</th></tr>";
    foreach ($admins as $admin) {
        echo "<tr>";
        echo "<td>" . $admin['id'] . "</td>";
        echo "<td>" . htmlspecialchars($admin['username']) . "</td>";
        echo "<td>" . htmlspecialchars($admin['email']) . "</td>";
        echo "<td>" . htmlspecialchars($admin['first_name'] . ' ' . $admin['last_name']) . "</td>";
        echo "<td>" . htmlspecialchars($admin['role']) . "</td>";
        echo "<td>" . ($admin['is_active'] ? 'Yes' : 'No') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<p><a href='admin/login.php'>Go to Login</a></p>";
    echo "<p><a href='debug_login.php'>Debug Login</a></p>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Setup - Church Management System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        form { margin: 20px 0; padding: 20px; border: 1px solid #ddd; }
        input[type="text"], input[type="email"], input[type="password"] { margin: 5px; padding: 5px; width: 200px; }
        button { margin: 5px; padding: 10px 20px; }
    </style>
</head>
<body>
    <p><a href="index.php">← Back to Home</a></p>
</body>
</html>
