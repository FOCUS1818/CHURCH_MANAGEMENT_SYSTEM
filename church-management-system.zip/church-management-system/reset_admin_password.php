<?php
/**
 * Reset Admin Password Utility
 * Church Management System
 */

require_once 'config/config.php';

use App\Database;

echo "<h2>Reset Admin Password</h2>";

$database = new Database();
$db = $database->getConnection();

if (!$db) {
    echo "❌ Database connection failed.<br>";
    exit;
}

echo "✅ Database connection successful<br>";

if ($_POST && isset($_POST['reset_password'])) {
    $username = $_POST['username'] ?? 'admin';
    $newPassword = $_POST['new_password'] ?? '';
    
    if (empty($newPassword)) {
        echo "❌ Please enter a new password.<br>";
    } else {
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
        
        try {
            // Update password for the admin user
            $stmt = $db->prepare("UPDATE users SET password_hash = ? WHERE username = ? OR email = ?");
            $result = $stmt->execute([$hashedPassword, $username, $username]);
            
            if ($result) {
                echo "✅ Password updated successfully!<br>";
                echo "Username/Email: " . htmlspecialchars($username) . "<br>";
                echo "New Password: " . htmlspecialchars($newPassword) . "<br>";
                echo "New Hash: " . htmlspecialchars($hashedPassword) . "<br>";
                echo "<p><a href='admin/login.php'>Go to Login</a></p>";
            } else {
                echo "❌ Failed to update password.<br>";
            }
        } catch (Exception $e) {
            echo "❌ Error updating password: " . $e->getMessage() . "<br>";
        }
    }
} else {
    // Show current admin users
    try {
        $stmt = $db->query("SELECT id, username, email, first_name, last_name, role, is_active FROM users WHERE role = 'super_admin'");
        $admins = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        if (count($admins) > 0) {
            echo "<h3>Current Admin Users:</h3>";
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Name</th><th>Role</th><th>Active</th></tr>";
            foreach ($admins as $admin) {
                echo "<tr>";
                echo "<td>" . $admin['id'] . "</td>";
                echo "<td>" . htmlspecialchars($admin['username']) . "</td>";
                echo "<td>" . htmlspecialchars($admin['email']) . "</td>";
                echo "<td>" . htmlspecialchars($admin['first_name'] . ' ' . $admin['last_name']) . "</td>";
                echo "<td>" . htmlspecialchars($admin['role']) . "</td>";
                echo "<td>" . ($admin['is_active'] ? 'Yes' : 'No') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "❌ No admin users found.<br>";
        }
    } catch (Exception $e) {
        echo "❌ Error fetching admin users: " . $e->getMessage() . "<br>";
    }
    
    // Show form to reset password
    ?>
    <form method="POST">
        <h3>Reset Admin Password:</h3>
        <div>
            <label>Username or Email:</label><br>
            <input type="text" name="username" value="admin" required>
        </div>
        <div>
            <label>New Password:</label><br>
            <input type="password" name="new_password" value="admin123" required>
        </div>
        <div>
            <button type="submit" name="reset_password">Reset Password</button>
        </div>
    </form>
    <?php
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Admin Password - Church Management System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        form { margin: 20px 0; padding: 20px; border: 1px solid #ddd; }
        input[type="text"], input[type="password"] { margin: 5px; padding: 5px; width: 200px; }
        button { margin: 5px; padding: 10px 20px; }
    </style>
</head>
<body>
    <p><a href="debug_login.php">← Back to Debug Login</a></p>
    <p><a href="admin/login.php">Go to Login</a></p>
</body>
</html>
