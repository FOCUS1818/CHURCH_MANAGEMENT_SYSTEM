<?php
require_once 'config/config.php';
require_once 'classes/LiveStream.php';

use App\Database;
use App\LiveStream;

$database = new Database();
$db = $database->getConnection();
$liveStream = new LiveStream($db);

// Get active live streams
$activeStreams = $liveStream->getActive();

$pageTitle = "Live Streaming";
?>
<?php include 'includes/header.php'; ?>

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <div class="bg-white shadow">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="py-6">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-900">Live Streaming</h1>
                        <p class="mt-1 text-gray-600">Watch our live services and events</p>
                    </div>
                    <div class="flex items-center space-x-4">
                        <div class="text-sm text-gray-500">
                            <i class="fas fa-circle text-red-500 mr-1"></i>
                            Live Now
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <?php if (empty($activeStreams)): ?>
            <div class="text-center py-12">
                <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <i class="fas fa-video text-gray-400 text-3xl"></i>
                </div>
                <h3 class="text-xl font-medium text-gray-900 mb-2">No Live Streams Currently</h3>
                <p class="text-gray-500 mb-6">There are no active live streams at the moment. Please check back later.</p>
                <a href="events.php" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                    View Upcoming Events
                </a>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <?php foreach ($activeStreams as $stream): ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                        <div class="aspect-w-16 aspect-h-9 bg-gray-900">
                            <?php if ($stream['stream_type'] === 'youtube'): ?>
                                <?php
                                // Extract YouTube video ID from URL
                                $youtubeUrl = $stream['stream_url'];
                                $videoId = '';
                                if (preg_match('/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/', $youtubeUrl, $matches)) {
                                    $videoId = $matches[1];
                                }
                                ?>
                                <?php if ($videoId): ?>
                                    <iframe src="https://www.youtube.com/embed/<?php echo $videoId; ?>?autoplay=1&mute=1"
                                            frameborder="0" allowfullscreen
                                            class="w-full h-full">
                                    </iframe>
                                <?php else: ?>
                                    <div class="flex items-center justify-center h-full text-white">
                                        <div class="text-center">
                                            <i class="fas fa-exclamation-triangle text-4xl mb-4"></i>
                                            <p>Invalid YouTube URL</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php elseif ($stream['stream_type'] === 'vimeo'): ?>
                                <?php
                                // Extract Vimeo video ID
                                $vimeoUrl = $stream['stream_url'];
                                $videoId = '';
                                if (preg_match('/vimeo\.com\/(\d+)/', $vimeoUrl, $matches)) {
                                    $videoId = $matches[1];
                                }
                                ?>
                                <?php if ($videoId): ?>
                                    <iframe src="https://player.vimeo.com/video/<?php echo $videoId; ?>?autoplay=1&muted=1"
                                            frameborder="0" allowfullscreen
                                            class="w-full h-full">
                                    </iframe>
                                <?php else: ?>
                                    <div class="flex items-center justify-center h-full text-white">
                                        <div class="text-center">
                                            <i class="fas fa-exclamation-triangle text-4xl mb-4"></i>
                                            <p>Invalid Vimeo URL</p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php elseif ($stream['stream_type'] === 'hls'): ?>
                                <video id="hls-video-<?php echo $stream['id']; ?>" controls autoplay muted class="w-full h-full">
                                    <source src="<?php echo htmlspecialchars($stream['stream_url']); ?>" type="application/x-mpegURL">
                                    Your browser does not support HLS video playback.
                                </video>
                            <?php else: ?>
                                <div class="flex items-center justify-center h-full text-white">
                                    <div class="text-center">
                                        <i class="fas fa-play-circle text-6xl mb-4"></i>
                                        <p>Click to watch live stream</p>
                                        <a href="<?php echo htmlspecialchars($stream['stream_url']); ?>"
                                           target="_blank"
                                           class="inline-flex items-center px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 mt-4">
                                            <i class="fas fa-external-link-alt mr-2"></i>
                                            Open Stream
                                        </a>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="p-6">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-xl font-bold text-gray-900"><?php echo htmlspecialchars($stream['title']); ?></h3>
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                                    <i class="fas fa-circle text-red-500 mr-1"></i>
                                    LIVE
                                </span>
                            </div>

                            <?php if ($stream['description']): ?>
                                <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($stream['description']); ?></p>
                            <?php endif; ?>

                            <?php if ($stream['event_title'] || $stream['sermon_title']): ?>
                                <div class="border-t pt-4">
                                    <p class="text-sm text-gray-500">
                                        <?php if ($stream['event_title']): ?>
                                            Related Event: <span class="font-medium"><?php echo htmlspecialchars($stream['event_title']); ?></span>
                                        <?php elseif ($stream['sermon_title']): ?>
                                            Related Sermon: <span class="font-medium"><?php echo htmlspecialchars($stream['sermon_title']); ?></span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Upcoming Events Section -->
        <div class="mt-12">
            <h2 class="text-2xl font-bold text-gray-900 mb-6">Upcoming Live Events</h2>
            <div class="bg-white shadow rounded-lg">
                <div class="p-6">
                    <p class="text-gray-600">Check our events page for upcoming services and events that will be streamed live.</p>
                    <a href="events.php" class="inline-flex items-center mt-4 px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                        View Events
                        <i class="fas fa-arrow-right ml-2"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// HLS video support (if needed)
<?php if (array_filter($activeStreams, fn($s) => $s['stream_type'] === 'hls')): ?>
document.addEventListener('DOMContentLoaded', function() {
    // Load HLS.js if available for better HLS support
    if (typeof Hls !== 'undefined') {
        document.querySelectorAll('video[source[type="application/x-mpegURL"]').forEach(function(video) {
            var videoSrc = video.querySelector('source').src;
            if (Hls.isSupported()) {
                var hls = new Hls();
                hls.loadSource(videoSrc);
                hls.attachMedia(video);
            }
        });
    }
});
<?php endif; ?>
</script>

<?php include 'includes/footer.php'; ?>