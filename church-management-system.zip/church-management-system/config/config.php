<?php
/**
 * Application Configuration
 * Church Management System
 */

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Application settings
define('APP_NAME', 'Church Management System');
define('APP_VERSION', '1.0.0');
define('BASE_URL', 'http://localhost/church-management-system/');
define('UPLOAD_PATH', 'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// Currency settings
define('CURRENCY_SYMBOL', 'GH₵');
define('CURRENCY_CODE', 'GHS');

// Security settings
define('SESSION_TIMEOUT', 120); // 2 minutes (120 seconds)
define('SESSION_TIMEOUT_ADMIN', 120); // Admin session timeout in seconds (2 minutes)
define('CSRF_TOKEN_NAME', 'csrf_token');
define('PASSWORD_MIN_LENGTH', 8);

// Email settings (configure with your SMTP details)
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'ebenezerbaah205@gmail.com');
define('SMTP_PASSWORD', 'ivnyibovbdjgnbzj');
define('FROM_EMAIL', 'ebenezerbaah205@gmail.com');
define('FROM_NAME', 'Church Management System');

// reCAPTCHA settings (get from Google reCAPTCHA)
define('RECAPTCHA_SITE_KEY', 'your-recaptcha-site-key');
define('RECAPTCHA_SECRET_KEY', 'your-recaptcha-secret-key');

// Timezone
date_default_timezone_set('America/New_York');

// Error reporting (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include autoloader
require_once __DIR__ . '/../vendor/autoload.php';

// Include utility functions
require_once __DIR__ . '/../includes/functions.php';

// Include database configuration for backward compatibility
require_once __DIR__ . '/database.php';
?>
