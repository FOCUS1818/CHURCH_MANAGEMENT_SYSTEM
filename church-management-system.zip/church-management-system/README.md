# Church Management System

A comprehensive Church Website and Membership Database System built with core PHP, MySQL, and TailwindCSS.

## 🌟 Features

### Public-Facing Website
- **Homepage**: Dynamic hero section with weekly verse, mission/vision, service times
- **Sermons Page**: Upload/embed weekly sermons with filtering by date, topic, speaker
- **Events Calendar**: Full calendar with upcoming services and community events
- **About Us**: Church history, pastor bios, interactive staff directory
- **Ministries**: List and detail pages for various church ministries
- **Contact Us**: Form with reCAPTCHA, map embed, message storage

### Admin Panel
- **Dashboard**: Member statistics, upcoming events, recent activity
- **Member Management**: CRUD operations for member data, photo uploads, document management
- **Family & Household Management**: Group members into households with roles
- **Attendance Tracking**: Mark attendance for events with filtering options
- **Event Management**: Create/edit/delete events with RSVP functionality
- **Volunteer & Ministry Teams**: Assign members to ministry teams
- **Contact/Message Center**: View and respond to contact form submissions
- **User Management**: Role-based access control for admin accounts

### Database Features
- **Relational Structure**: Properly normalized with foreign keys and constraints
- **Member Profiles**: Complete member information with spiritual gifts, family roles
- **Event Management**: Comprehensive event tracking with RSVP capabilities
- **Attendance Records**: Track member participation in events
- **Document Storage**: Upload and manage member documents
- **Activity Logging**: Track all admin actions for accountability

### Security Features
- **Session Management**: Secure login with token expiration
- **CSRF Protection**: All forms protected against cross-site request forgery
- **Password Security**: Bcrypt hashing for all passwords
- **Input Validation**: Comprehensive sanitization and validation
- **Prepared Statements**: PDO-based queries prevent SQL injection
- **Role-Based Access**: Granular permissions for different user types

## 🚀 Installation

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)
- Composer (for autoloader)

### Setup Instructions

1. **Clone or Download the Project**
   ```bash
   git clone <repository-url>
   cd church-management-system
   ```

2. **Database Setup**
   - Create a MySQL database named `church_management`
   - Import the database schema:
   ```bash
   mysql -u root -p church_management < database/schema.sql
   ```

3. **Configuration**
   - Update `config/config.php` with your database credentials
   - Configure email settings for contact form notifications
   - Set up reCAPTCHA keys (optional but recommended)
   - Update `BASE_URL` to match your domain

4. **File Permissions**
   ```bash
   chmod 755 uploads/
   chmod 644 config/*.php
   ```

5. **Web Server Configuration**
   - Point your web server document root to the project directory
   - Ensure mod_rewrite is enabled for clean URLs
   - Set up SSL certificate for production use

### Default Login Credentials
- **Username**: admin
- **Email**: admin@church.com
- **Password**: password (change immediately after first login)

## 📁 Project Structure

```
church-management-system/
├── admin/                  # Admin panel pages
│   ├── dashboard.php      # Main dashboard
│   ├── login.php         # Admin login
│   ├── members.php       # Member management
│   ├── member-add.php    # Add new member
│   ├── events.php        # Event management
│   └── ...
├── classes/              # PHP classes
│   ├── User.php         # User management
│   ├── Member.php       # Member management
│   ├── Event.php        # Event management
│   └── ...
├── config/              # Configuration files
│   ├── config.php       # Main configuration
│   └── database.php     # Database connection
├── database/            # Database files
│   └── schema.sql       # Database schema
├── includes/            # Utility files
│   └── functions.php    # Helper functions
├── uploads/             # File uploads directory
├── index.php           # Public homepage
├── contact.php         # Contact page
├── events.php          # Public events page
├── sermons.php         # Public sermons page
├── ministries.php      # Public ministries page
└── README.md          # This file
```

## 🗄️ Database Schema

### Core Tables
- **users**: Admin/staff accounts with role-based permissions
- **members**: Congregation member information
- **households**: Family grouping system
- **events**: Church events and services
- **attendance**: Member attendance tracking
- **sermons**: Weekly sermon management
- **ministries**: Church ministry programs
- **contact_messages**: Contact form submissions
- **documents**: Member file uploads
- **activity_logs**: Admin action tracking

## 🎨 UI/UX Features

- **Responsive Design**: Mobile-first approach with TailwindCSS
- **Modern Interface**: Clean, accessible forms and components
- **Interactive Elements**: Modals, toasts, pagination, filtering
- **Accessibility**: WCAG compliant design patterns
- **Cross-Browser**: Compatible with all modern browsers

## 🔧 Configuration Options

### Email Settings
Configure SMTP settings in `config/config.php`:
```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'your-email@gmail.com');
define('SMTP_PASSWORD', 'your-app-password');
```

### reCAPTCHA Integration
Add your reCAPTCHA keys:
```php
define('RECAPTCHA_SITE_KEY', 'your-site-key');
define('RECAPTCHA_SECRET_KEY', 'your-secret-key');
```

### File Upload Settings
Adjust upload limits and allowed file types:
```php
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
```

## 📊 Reporting & Analytics

- **Member Statistics**: Growth trends, demographics, status breakdowns
- **Attendance Reports**: Event participation and trends
- **Birthday Reminders**: Upcoming member birthdays
- **Event Analytics**: Participation rates and capacity tracking
- **Activity Logs**: Complete audit trail of admin actions

## 🔒 Security Best Practices

1. **Change Default Passwords**: Update all default credentials
2. **Use HTTPS**: Enable SSL/TLS encryption
3. **Regular Updates**: Keep PHP and MySQL updated
4. **Backup Database**: Regular automated backups
5. **File Permissions**: Restrict upload directory access
6. **Input Validation**: All user inputs are sanitized
7. **Session Security**: Proper session management and timeout

## 🚀 Future Enhancements

- **Mobile App**: REST API for mobile application
- **Member Portal**: Self-service member login
- **Online Giving**: Integration with payment processors
- **Push Notifications**: Event and birthday reminders
- **Email Marketing**: Newsletter integration
- **Multilingual Support**: Multiple language options
- **Theme Customization**: Light/dark mode toggle
- **QR Code Check-in**: Mobile attendance scanning

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check database credentials in `config/database.php`
   - Ensure MySQL service is running
   - Verify database exists and is accessible

2. **File Upload Issues**
   - Check `uploads/` directory permissions
   - Verify `MAX_FILE_SIZE` setting
   - Check PHP upload limits in php.ini

3. **Email Not Working**
   - Verify SMTP credentials
   - Check firewall settings
   - Test with different email providers

4. **Session Issues**
   - Check PHP session configuration
   - Verify session directory permissions
   - Clear browser cookies

### Support

For technical support or feature requests, please contact the development team or create an issue in the project repository.

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📞 Contact

- **Project**: Church Management System
- **Version**: 1.0.0
- **Last Updated**: 2024

---

**Note**: This is a production-ready church management system. Ensure you have proper backups and security measures in place before deploying to a live environment.
