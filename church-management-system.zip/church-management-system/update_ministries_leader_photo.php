 <?php
/**
 * Database Migration: Add leader_photo and custom_link columns to ministries table
 * Run this file once to add the columns to your database
 * 
 * Access this file in your browser: http://localhost/church-management-system/update_ministries_leader_photo.php
 */

require_once 'config/config.php';

use App\Database;

$database = new Database();
$db = $database->getConnection();

try {
    // Check if leader_photo column exists
    $stmt = $db->query("SHOW COLUMNS FROM ministries LIKE 'leader_photo'");
    $exists = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exists) {
        $db->exec("ALTER TABLE ministries ADD COLUMN leader_photo VARCHAR(255) AFTER leader_id");
        echo "Successfully added leader_photo column to ministries table!<br>";
    } else {
        echo "leader_photo column already exists.<br>";
    }
    
    // Check if custom_link column exists
    $stmt = $db->query("SHOW COLUMNS FROM ministries LIKE 'custom_link'");
    $exists = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$exists) {
        $db->exec("ALTER TABLE ministries ADD COLUMN custom_link VARCHAR(500) AFTER leader_photo");
        echo "Successfully added custom_link column to ministries table!<br>";
    } else {
        echo "custom_link column already exists.<br>";
    }
    
    echo "Migration complete!";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
