<?php
/**
 * Debug Login Utility
 * Church Management System
 */

require_once 'config/config.php';

use App\Database;
use App\User;

echo "<h2>Login Debug Information</h2>";

// Test database connection
echo "<h3>Database Connection Test:</h3>";
$database = new Database();
$db = $database->getConnection();

if ($db) {
    echo "✅ Database connection successful<br>";
} else {
    echo "❌ Database connection failed<br>";
    exit;
}

// Check if users table exists and has data
echo "<h3>Users Table Check:</h3>";
try {
    $stmt = $db->query("SELECT COUNT(*) as count FROM users");
    $result = $stmt->fetch(\PDO::FETCH_ASSOC);
    echo "Users in database: " . $result['count'] . "<br>";
    
    if ($result['count'] > 0) {
        $stmt = $db->query("SELECT id, username, email, role, is_active FROM users LIMIT 5");
        $users = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        echo "<h4>Sample Users:</h4>";
        echo "<table border='1' cellpadding='5'>";
        echo "<tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Active</th></tr>";
        foreach ($users as $user) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($user['id']) . "</td>";
            echo "<td>" . htmlspecialchars($user['username']) . "</td>";
            echo "<td>" . htmlspecialchars($user['email']) . "</td>";
            echo "<td>" . htmlspecialchars($user['role']) . "</td>";
            echo "<td>" . ($user['is_active'] ? 'Yes' : 'No') . "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "❌ No users found in database<br>";
    }
} catch (Exception $e) {
    echo "❌ Error checking users table: " . $e->getMessage() . "<br>";
}

// Test login functionality
echo "<h3>Login Test:</h3>";
if ($_POST) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    echo "Testing login with:<br>";
    echo "Username/Email: " . htmlspecialchars($username) . "<br>";
    echo "Password: " . str_repeat('*', strlen($password)) . "<br><br>";
    
    $user = new User($db);
    
    // Check if user exists
    $query = "SELECT id, username, email, password_hash, first_name, last_name, role, is_active 
              FROM users 
              WHERE (username = :username OR email = :username) AND is_active = 1";
    $stmt = $db->prepare($query);
    $stmt->bindParam(":username", $username);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        echo "✅ User found in database:<br>";
        echo "ID: " . $row['id'] . "<br>";
        echo "Username: " . htmlspecialchars($row['username']) . "<br>";
        echo "Email: " . htmlspecialchars($row['email']) . "<br>";
        echo "Role: " . htmlspecialchars($row['role']) . "<br>";
        echo "Active: " . ($row['is_active'] ? 'Yes' : 'No') . "<br>";
        echo "Password Hash: " . htmlspecialchars(substr($row['password_hash'], 0, 20)) . "...<br><br>";
        
        // Test password verification
        if (password_verify($password, $row['password_hash'])) {
            echo "✅ Password verification successful!<br>";
        } else {
            echo "❌ Password verification failed!<br>";
            echo "This means the password you entered doesn't match the stored hash.<br>";
        }
    } else {
        echo "❌ No user found with username/email: " . htmlspecialchars($username) . "<br>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Debug - Church Management System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        form { margin: 20px 0; padding: 20px; border: 1px solid #ddd; }
        input[type="text"], input[type="password"] { margin: 5px; padding: 5px; }
        button { margin: 5px; padding: 10px 20px; }
    </style>
</head>
<body>
    <form method="POST">
        <h3>Test Login:</h3>
        <div>
            <label>Username or Email:</label><br>
            <input type="text" name="username" value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>" required>
        </div>
        <div>
            <label>Password:</label><br>
            <input type="password" name="password" required>
        </div>
        <div>
            <button type="submit">Test Login</button>
        </div>
    </form>
    
    <p><a href="hashpass.php">Generate Password Hash</a></p>
    <p><a href="admin/login.php">Back to Login</a></p>
</body>
</html>
