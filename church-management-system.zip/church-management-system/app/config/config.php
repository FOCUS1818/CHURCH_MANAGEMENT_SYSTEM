<?php
/**
 * OLEBU Church Management System
 * Configuration File
 */

// Database Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'olebu_church');
define('DB_USER', 'root');
define('DB_PASS', '');

// Application Configuration
define('APP_NAME', 'OLEBU Church Management System');
define('APP_URL', 'http://localhost/church-management-system');
define('APP_ENV', 'development'); // development, production

// Security Configuration
define('SESSION_NAME', 'OLEBU_SESSION');
define('CSRF_TOKEN_NAME', 'csrf_token');
define('SESSION_TIMEOUT', 3600); // 1 hour
define('HASH_ALGO', 'bcrypt');

// Pagination
define('ITEMS_PER_PAGE', 20);

// File Upload
define('UPLOAD_PATH', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5242880); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'pdf', 'doc', 'docx']);

// Email Configuration
define('FROM_EMAIL', 'noreply@olebu.com');
define('FROM_NAME', 'OLEBU Church');

// Error Reporting
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// MTN Mobile Money Configuration
// Get your API credentials from MTN Developer Portal: https://momodeveloper.mtn.com/
define('MTN_API_KEY', '');       // Your MTN API Key
define('MTN_API_SECRET', '');    // Your MTN API Secret
define('MTN_SUBSCRIPTION_KEY', ''); // Your MTN Subscription Key
define('MTN_ENVIRONMENT', 'sandbox'); // 'sandbox' for testing, 'production' for live
define('MTN_CURRENCY', 'UGX');   // Currency: UGX, GHS, NGN, etc.
define('MTN_COLLECTION_ID', '');  // Your Collection ID (optional)

// Timezone
date_default_timezone_set('Africa/Lagos'); // Change to your timezone

// Auto-load classes
spl_autoload_register(function ($class) {
    $prefixes = [
        'App\\' => __DIR__ . '/../classes/',
    ];
    
    foreach ($prefixes as $prefix => $base_dir) {
        $len = strlen($prefix);
        if (strncmp($prefix, $class, $len) !== 0) {
            continue;
        }
        $relative_class = substr($class, $len);
        $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
        
        if (file_exists($file)) {
            require $file;
            return;
        }
    }
});

// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_start();
}

// Check session timeout
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_TIMEOUT)) {
    session_unset();
    session_destroy();
    session_start();
}
$_SESSION['last_activity'] = time();

// Generate CSRF token if not exists
if (empty($_SESSION[CSRF_TOKEN_NAME])) {
    $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
}
