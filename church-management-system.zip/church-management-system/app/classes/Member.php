<?php
namespace App;

use PDO;

/**
 * Member Model
 * Handles all member-related database operations
 */
class Member {
    private $conn;
    private $table = 'members';

    // Member properties
    public $member_id;
    public $household_id;
    public $small_group_id;
    public $small_group_ids = []; // Array for multiple small groups
    public $first_name;
    public $last_name;
    public $email;
    public $phone;
    public $join_date;
    public $gender;
    public $date_of_birth;
    public $marital_status;
    public $address;
    public $photo;
    public $membership_status;
    public $baptism_date;
    public $notes;
    public $created_at;
    public $updated_at;

    /**
     * Constructor
     */
    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Create new member
     */
    public function create() {
        $query = "INSERT INTO {$this->table} 
                  (household_id, small_group_id, first_name, last_name, email, phone, join_date, 
                   gender, date_of_birth, marital_status, address, photo, membership_status, baptism_date, notes) 
                  VALUES (:household_id, :small_group_id, :first_name, :last_name, :email, :phone, :join_date,
                          :gender, :date_of_birth, :marital_status, :address, :photo, :membership_status, :baptism_date, :notes)";

        $stmt = $this->conn->prepare($query);

        // Bind parameters
        $stmt->bindParam(':household_id', $this->household_id);
        $stmt->bindParam(':small_group_id', $this->small_group_id);
        $stmt->bindParam(':first_name', $this->first_name);
        $stmt->bindParam(':last_name', $this->last_name);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':join_date', $this->join_date);
        $stmt->bindParam(':gender', $this->gender);
        $stmt->bindParam(':date_of_birth', $this->date_of_birth);
        $stmt->bindParam(':marital_status', $this->marital_status);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':photo', $this->photo);
        $stmt->bindParam(':membership_status', $this->membership_status);
        $stmt->bindParam(':baptism_date', $this->baptism_date);
        $stmt->bindParam(':notes', $this->notes);

        if ($stmt->execute()) {
            $this->member_id = $this->conn->lastInsertId();
            return true;
        }

        return false;
    }

    /**
     * Read all members with pagination
     */
    public function readAll($search = '', $page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        
        $searchQuery = $search ? "WHERE first_name LIKE :search OR last_name LIKE :search OR email LIKE :search" : "";
        
        $query = "SELECT * FROM {$this->table} 
                  {$searchQuery}
                  ORDER BY last_name, first_name 
                  LIMIT :limit OFFSET :offset";

        $stmt = $this->conn->prepare($query);
        
        if ($search) {
            $searchTerm = "%{$search}%";
            $stmt->bindParam(':search', $searchTerm);
        }
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        
        $stmt->execute();
        return $stmt;
    }

    /**
     * Get total count
     */
    public function getTotalCount($search = '') {
        $searchQuery = $search ? "WHERE first_name LIKE :search OR last_name LIKE :search OR email LIKE :search" : "";
        
        $query = "SELECT COUNT(*) as total FROM {$this->table} {$searchQuery}";
        $stmt = $this->conn->prepare($query);
        
        if ($search) {
            $searchTerm = "%{$search}%";
            $stmt->bindParam(':search', $searchTerm);
        }
        
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }

    /**
     * Read single member
     */
    public function readOne($id) {
        $query = "SELECT * FROM {$this->table} WHERE member_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $this->member_id = $row['member_id'];
            $this->household_id = $row['household_id'];
            $this->small_group_id = $row['small_group_id'];
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->email = $row['email'];
            $this->phone = $row['phone'];
            $this->join_date = $row['join_date'];
            $this->gender = $row['gender'];
            $this->date_of_birth = $row['date_of_birth'];
            $this->marital_status = $row['marital_status'];
            $this->address = $row['address'];
            $this->photo = $row['photo'];
            $this->membership_status = $row['membership_status'];
            $this->baptism_date = $row['baptism_date'];
            $this->notes = $row['notes'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        return false;
    }

    /**
     * Update member
     */
    public function update() {
        $query = "UPDATE {$this->table} SET
                  household_id = :household_id,
                  small_group_id = :small_group_id,
                  first_name = :first_name,
                  last_name = :last_name,
                  email = :email,
                  phone = :phone,
                  join_date = :join_date,
                  gender = :gender,
                  date_of_birth = :date_of_birth,
                  marital_status = :marital_status,
                  address = :address,
                  photo = :photo,
                  membership_status = :membership_status,
                  baptism_date = :baptism_date,
                  notes = :notes
                  WHERE member_id = :member_id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':member_id', $this->member_id);
        $stmt->bindParam(':household_id', $this->household_id);
        $stmt->bindParam(':small_group_id', $this->small_group_id);
        $stmt->bindParam(':first_name', $this->first_name);
        $stmt->bindParam(':last_name', $this->last_name);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':join_date', $this->join_date);
        $stmt->bindParam(':gender', $this->gender);
        $stmt->bindParam(':date_of_birth', $this->date_of_birth);
        $stmt->bindParam(':marital_status', $this->marital_status);
        $stmt->bindParam(':address', $this->address);
        $stmt->bindParam(':photo', $this->photo);
        $stmt->bindParam(':membership_status', $this->membership_status);
        $stmt->bindParam(':baptism_date', $this->baptism_date);
        $stmt->bindParam(':notes', $this->notes);

        return $stmt->execute();
    }

    /**
     * Delete member
     */
    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE member_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Get members by household
     */
    public function getByHousehold($household_id) {
        $query = "SELECT * FROM {$this->table} WHERE household_id = :household_id ORDER BY last_name, first_name";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':household_id', $household_id);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Get members by small group
     */
    public function getBySmallGroup($group_id) {
        $query = "SELECT * FROM {$this->table} WHERE small_group_id = :group_id ORDER BY last_name, first_name";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':group_id', $group_id);
        $stmt->execute();
        return $stmt;
    }

    /**
     * Get member statistics
     */
    public function getStats() {
        $query = "SELECT 
                  COUNT(*) as total_members,
                  SUM(CASE WHEN membership_status = 'active' THEN 1 ELSE 0 END) as active_members,
                  SUM(CASE WHEN membership_status = 'visitor' THEN 1 ELSE 0 END) as visitors,
                  SUM(CASE WHEN membership_status = 'inactive' THEN 1 ELSE 0 END) as inactive_members
                  FROM {$this->table}";
        
        $stmt = $this->conn->query($query);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Save member small groups (multiple)
     */
    public function saveSmallGroups($member_id, $small_group_ids) {
        // Delete existing small group associations
        $this->deleteSmallGroups($member_id);
        
        // Insert new small group associations
        if (!empty($small_group_ids)) {
            $query = "INSERT INTO member_small_groups (member_id, small_group_id) VALUES (:member_id, :small_group_id)";
            $stmt = $this->conn->prepare($query);
            
            foreach ($small_group_ids as $small_group_id) {
                $stmt->bindParam(':member_id', $member_id);
                $stmt->bindParam(':small_group_id', $small_group_id);
                $stmt->execute();
            }
        }
        return true;
    }

    /**
     * Delete member small groups
     */
    public function deleteSmallGroups($member_id) {
        $query = "DELETE FROM member_small_groups WHERE member_id = :member_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $member_id);
        return $stmt->execute();
    }

    /**
     * Get member small groups
     */
    public function getSmallGroups($member_id) {
        $query = "SELECT sg.id, sg.group_name 
                  FROM small_groups sg 
                  INNER JOIN member_small_groups msg ON sg.id = msg.small_group_id 
                  WHERE msg.member_id = :member_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $member_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get member small group IDs
     */
    public function getSmallGroupIds($member_id) {
        $query = "SELECT small_group_id FROM member_small_groups WHERE member_id = :member_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $member_id);
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return array_column($results, 'small_group_id');
    }
}
