<?php
namespace App;

use PDO;

/**
 * SmallGroup Model
 * Handles all small group-related database operations
 */
class SmallGroup {
    private $conn;
    private $table = 'small_groups';

    public $group_id;
    public $group_name;
    public $meeting_day;
    public $meeting_time;
    public $location;
    public $leader_id;
    public $description;
    public $is_active;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO {$this->table} 
                  (group_name, meeting_day, meeting_time, location, leader_id, description) 
                  VALUES (:group_name, :meeting_day, :meeting_time, :location, :leader_id, :description)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':group_name', $this->group_name);
        $stmt->bindParam(':meeting_day', $this->meeting_day);
        $stmt->bindParam(':meeting_time', $this->meeting_time);
        $stmt->bindParam(':location', $this->location);
        $stmt->bindParam(':leader_id', $this->leader_id);
        $stmt->bindParam(':description', $this->description);

        if ($stmt->execute()) {
            $this->group_id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function readAll($search = '') {
        $searchQuery = $search ? "WHERE group_name LIKE :search OR description LIKE :search" : "";
        $query = "SELECT * FROM {$this->table} {$searchQuery} ORDER BY group_name";
        
        $stmt = $this->conn->prepare($query);
        if ($search) {
            $searchTerm = "%{$search}%";
            $stmt->bindParam(':search', $searchTerm);
        }
        $stmt->execute();
        return $stmt;
    }

    public function readOne($id) {
        $query = "SELECT * FROM {$this->table} WHERE group_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            foreach ($row as $key => $value) {
                $this->$key = $value;
            }
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE {$this->table} SET
                  group_name = :group_name,
                  meeting_day = :meeting_day,
                  meeting_time = :meeting_time,
                  location = :location,
                  leader_id = :leader_id,
                  description = :description,
                  is_active = :is_active
                  WHERE group_id = :group_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':group_id', $this->group_id);
        $stmt->bindParam(':group_name', $this->group_name);
        $stmt->bindParam(':meeting_day', $this->meeting_day);
        $stmt->bindParam(':meeting_time', $this->meeting_time);
        $stmt->bindParam(':location', $this->location);
        $stmt->bindParam(':leader_id', $this->leader_id);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':is_active', $this->is_active);

        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE group_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function getMembers($group_id) {
        $query = "SELECT m.*, mgm.role, mgm.enrollment_date
                  FROM {$this->table} sg
                  JOIN members m ON m.small_group_id = sg.group_id
                  LEFT JOIN member_group_membership mgm ON m.member_id = mgm.member_id AND sg.group_id = mgm.group_id
                  WHERE sg.group_id = :group_id
                  ORDER BY m.last_name, m.first_name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':group_id', $group_id);
        $stmt->execute();
        return $stmt;
    }

    public function getActiveGroups() {
        $query = "SELECT * FROM {$this->table} WHERE is_active = 1 ORDER BY group_name";
        $stmt = $this->conn->query($query);
        return $stmt;
    }
}
