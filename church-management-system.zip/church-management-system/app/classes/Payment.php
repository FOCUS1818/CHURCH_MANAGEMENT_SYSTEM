<?php
namespace App;

use PDO;

/**
 * MTN Mobile Money Payment Integration
 * Handles payments via MTN MoMo API
 */
class Payment {
    private $conn;
    private $table = 'donations';
    
    // MTN API Configuration (to be configured in config.php)
    private $mtn_api_key;
    private $mtn_api_secret;
    private $mtn_subscription_key;
    private $mtn_environment; // 'sandbox' or 'production'
    private $mtn_currency = 'UGX'; // or 'GHS', 'NGN', 'XAF'
    private $church_name = 'OLEBU Church';
    
    public $id;
    public $member_id;
    public $amount;
    public $currency;
    public $payment_method;
    public $payment_status;
    public $transaction_id;
    public $donation_type;
    public $donor_name;
    public $donor_email;
    public $donor_phone;
    public $note;
    public $created_at;

    public function __construct($db) {
        $this->conn = $db;
        
        // Load MTN configuration from config
        $this->mtn_api_key = defined('MTN_API_KEY') ? MTN_API_KEY : 'your-api-key';
        $this->mtn_api_secret = defined('MTN_API_SECRET') ? MTN_API_SECRET : 'your-api-secret';
        $this->mtn_subscription_key = defined('MTN_SUBSCRIPTION_KEY') ? MTN_SUBSCRIPTION_KEY : 'your-subscription-key';
        $this->mtn_environment = defined('MTN_ENVIRONMENT') ? MTN_ENVIRONMENT : 'sandbox';
        $this->mtn_currency = defined('MTN_CURRENCY') ? MTN_CURRENCY : 'UGX';
    }

    /**
     * Get MTN API Base URL
     */
    private function getApiBaseUrl() {
        return $this->mtn_environment === 'production' 
            ? 'https://api.momopayment.com' 
            : 'https://sandbox.momopayment.com';
    }

    /**
     * Get Access Token from MTN
     */
    public function getAccessToken() {
        $url = $this->getApiBaseUrl() . '/collection/token/';
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_USERPWD, $this->mtn_api_key . ':' . $this->mtn_api_secret);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Ocp-Apim-Subscription-Key: ' . $this->mtn_subscription_key
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            return $data['access_token'] ?? null;
        }
        
        return null;
    }

    /**
     * Request Payment from Customer (MTN MoMo)
     */
    public function requestPayment($phoneNumber, $amount, $donationType, $donorName, $donorEmail, $externalId = null) {
        $accessToken = $this->getAccessToken();
        
        if (!$accessToken) {
            return [
                'success' => false,
                'message' => 'Failed to authenticate with MTN. Please check your API credentials.'
            ];
        }
        
        $transactionId = $externalId ?: 'DON-' . time() . '-' . rand(1000, 9999);
        
        $url = $this->getApiBaseUrl() . '/collection/v1_0/requesttopay';
        
        $data = [
            'amount' => (string)$amount,
            'currency' => $this->mtn_currency,
            'externalId' => $transactionId,
            'payer' => [
                'partyIdType' => 'MSISDN',
                'partyId' => $this->formatPhoneNumber($phoneNumber)
            ],
            'payerMessage' => 'Donation to ' . $this->church_name . ' - ' . $donationType,
            'payeeNote' => 'Thank you for your donation!'
        ];
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Ocp-Apim-Subscription-Key: ' . $this->mtn_subscription_key,
            'Content-Type: application/json',
            'X-Reference-Id: ' . $transactionId
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 202 || $httpCode === 200) {
            // Save donation record
            $this->saveDonation([
                'transaction_id' => $transactionId,
                'amount' => $amount,
                'currency' => $this->mtn_currency,
                'payment_method' => 'mtn_mobile_money',
                'donation_type' => $donationType,
                'donor_name' => $donorName,
                'donor_email' => $donorEmail,
                'donor_phone' => $phoneNumber,
                'payment_status' => 'pending'
            ]);
            
            return [
                'success' => true,
                'message' => 'Payment request sent! Please check your phone and authorize the payment.',
                'transaction_id' => $transactionId
            ];
        }
        
        return [
            'success' => false,
            'message' => 'Failed to initiate payment. HTTP Code: ' . $httpCode,
            'response' => $response
        ];
    }

    /**
     * Check Payment Status
     */
    public function checkPaymentStatus($transactionId) {
        $accessToken = $this->getAccessToken();
        
        if (!$accessToken) {
            return ['status' => 'failed', 'message' => 'Authentication failed'];
        }
        
        $url = $this->getApiBaseUrl() . '/collection/v1_0/requesttopay/' . $transactionId;
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Authorization: Bearer ' . $accessToken,
            'Ocp-Apim-Subscription-Key: ' . $this->mtn_subscription_key
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            
            // Update donation status in database
            $status = $this->mapPaymentStatus($data['status'] ?? '');
            $this->updateDonationStatus($transactionId, $status);
            
            return [
                'status' => $status,
                'data' => $data
            ];
        }
        
        return ['status' => 'unknown', 'message' => 'Unable to check status'];
    }

    /**
     * Map MTN status to local status
     */
    private function mapPaymentStatus($mtnStatus) {
        $statusMap = [
            'SUCCESSFUL' => 'completed',
            'FAILED' => 'failed',
            'PENDING' => 'pending',
            'PROCESSING' => 'pending'
        ];
        
        return $statusMap[$mtnStatus] ?? 'pending';
    }

    /**
     * Format phone number for MTN (remove + and country code prefix)
     */
    private function formatPhoneNumber($phone) {
        // Remove any non-numeric characters
        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        // If starts with country code, remove it
        if (substr($phone, 0, 3) === '256') { // Uganda
            return '0' . substr($phone, 3);
        } elseif (substr($phone, 0, 3) === '233') { // Ghana
            return '0' . substr($phone, 3);
        } elseif (substr($phone, 0, 3) === '234') { // Nigeria
            return '0' . substr($phone, 3);
        }
        
        // If doesn't start with 0, add it
        return $phone[0] === '0' ? $phone : '0' . $phone;
    }

    /**
     * Save donation record
     */
    public function saveDonation($data) {
        $query = "INSERT INTO {$this->table} 
                  (transaction_id, amount, currency, payment_method, donation_type, donor_name, donor_email, donor_phone, note, payment_status, created_at) 
                  VALUES (:transaction_id, :amount, :currency, :payment_method, :donation_type, :donor_name, :donor_email, :donor_phone, :note, :payment_status, NOW())";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            ':transaction_id' => $data['transaction_id'],
            ':amount' => $data['amount'],
            ':currency' => $data['currency'],
            ':payment_method' => $data['payment_method'],
            ':donation_type' => $data['donation_type'],
            ':donor_name' => $data['donor_name'],
            ':donor_email' => $data['donor_email'],
            ':donor_phone' => $data['donor_phone'],
            ':note' => $data['note'] ?? '',
            ':payment_status' => $data['payment_status']
        ]);
    }

    /**
     * Update donation status
     */
    public function updateDonationStatus($transactionId, $status) {
        $query = "UPDATE {$this->table} SET payment_status = :status WHERE transaction_id = :transaction_id";
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([':status' => $status, ':transaction_id' => $transactionId]);
    }

    /**
     * Get donation by transaction ID
     */
    public function getByTransactionId($transactionId) {
        $query = "SELECT * FROM {$this->table} WHERE transaction_id = :transaction_id";
        $stmt = $this->conn->prepare($query);
        $stmt->execute([':transaction_id' => $transactionId]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Get all donations
     */
    public function getAll($limit = 50) {
        $query = "SELECT * FROM {$this->table} ORDER BY created_at DESC LIMIT :limit";
        $stmt = $this->conn->prepare($query);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Get donations by status
     */
    public function getByStatus($status, $limit = 50) {
        $query = "SELECT * FROM {$this->table} WHERE payment_status = :status ORDER BY created_at DESC LIMIT :limit";
        $stmt = $this->conn->prepare($query);
        $stmt->bindValue(':status', $status);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /**
     * Record offline donation (cash/check)
     */
    public function recordOfflineDonation($data) {
        $query = "INSERT INTO {$this->table} 
                  (amount, currency, payment_method, donation_type, donor_name, donor_email, donor_phone, note, payment_status, created_at) 
                  VALUES (:amount, :currency, :payment_method, :donation_type, :donor_name, :donor_email, :donor_phone, :note, 'completed', NOW())";
        
        $stmt = $this->conn->prepare($query);
        return $stmt->execute([
            ':amount' => $data['amount'],
            ':currency' => $data['currency'] ?? 'UGX',
            ':payment_method' => $data['payment_method'],
            ':donation_type' => $data['donation_type'],
            ':donor_name' => $data['donor_name'],
            ':donor_email' => $data['donor_email'] ?? '',
            ':donor_phone' => $data['donor_phone'] ?? '',
            ':note' => $data['note'] ?? ''
        ]);
    }
}
