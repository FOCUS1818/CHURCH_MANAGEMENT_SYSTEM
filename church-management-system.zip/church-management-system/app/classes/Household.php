<?php
namespace App;

use PDO;

/**
 * Household Model
 * Handles all household-related database operations
 */
class Household {
    private $conn;
    private $table = 'households';

    public $household_id;
    public $family_name;
    public $mailing_address;
    public $phone;
    public $email;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO {$this->table} 
                  (family_name, mailing_address, phone, email) 
                  VALUES (:family_name, :mailing_address, :phone, :email)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':family_name', $this->family_name);
        $stmt->bindParam(':mailing_address', $this->mailing_address);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':email', $this->email);

        if ($stmt->execute()) {
            $this->household_id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function readAll($search = '') {
        $searchQuery = $search ? "WHERE family_name LIKE :search OR email LIKE :search OR phone LIKE :search" : "";
        $query = "SELECT * FROM {$this->table} {$searchQuery} ORDER BY family_name";
        
        $stmt = $this->conn->prepare($query);
        if ($search) {
            $searchTerm = "%{$search}%";
            $stmt->bindParam(':search', $searchTerm);
        }
        $stmt->execute();
        return $stmt;
    }

    public function readOne($id) {
        $query = "SELECT * FROM {$this->table} WHERE household_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            foreach ($row as $key => $value) {
                $this->$key = $value;
            }
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE {$this->table} SET
                  family_name = :family_name,
                  mailing_address = :mailing_address,
                  phone = :phone,
                  email = :email
                  WHERE household_id = :household_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':household_id', $this->household_id);
        $stmt->bindParam(':family_name', $this->family_name);
        $stmt->bindParam(':mailing_address', $this->mailing_address);
        $stmt->bindParam(':phone', $this->phone);
        $stmt->bindParam(':email', $this->email);

        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE household_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function getMembers($household_id) {
        $query = "SELECT * FROM members WHERE household_id = :household_id ORDER BY last_name, first_name";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':household_id', $household_id);
        $stmt->execute();
        return $stmt;
    }

    public function getTotalCount() {
        $query = "SELECT COUNT(*) as total FROM {$this->table}";
        $stmt = $this->conn->query($query);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'];
    }
}
