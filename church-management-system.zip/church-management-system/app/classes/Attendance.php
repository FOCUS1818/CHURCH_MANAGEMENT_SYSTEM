<?php
namespace App;

use PDO;

/**
 * Attendance Model
 * Handles all attendance-related database operations
 */
class Attendance {
    private $conn;
    private $table = 'attendance';

    public $attendance_id;
    public $member_id;
    public $event_id;
    public $service_type;
    public $attendance_date;
    public $exercise_type;
    public $notes;
    public $recorded_by;
    public $created_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO {$this->table} 
                  (member_id, event_id, service_type, attendance_date, exercise_type, notes, recorded_by) 
                  VALUES (:member_id, :event_id, :service_type, :attendance_date, :exercise_type, :notes, :recorded_by)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $this->member_id);
        $stmt->bindParam(':event_id', $this->event_id);
        $stmt->bindParam(':service_type', $this->service_type);
        $stmt->bindParam(':attendance_date', $this->attendance_date);
        $stmt->bindParam(':exercise_type', $this->exercise_type);
        $stmt->bindParam(':notes', $this->notes);
        $stmt->bindParam(':recorded_by', $this->recorded_by);

        if ($stmt->execute()) {
            $this->attendance_id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function readAll($search = '', $page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        
        $query = "SELECT a.*, m.first_name, m.last_name, e.event_name 
                  FROM {$this->table} a
                  LEFT JOIN members m ON a.member_id = m.member_id
                  LEFT JOIN events e ON a.event_id = e.event_id
                  ORDER BY a.attendance_date DESC, a.attendance_id DESC
                  LIMIT :limit OFFSET :offset";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt;
    }

    public function readOne($id) {
        $query = "SELECT * FROM {$this->table} WHERE attendance_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            foreach ($row as $key => $value) {
                $this->$key = $value;
            }
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE {$this->table} SET
                  member_id = :member_id,
                  event_id = :event_id,
                  service_type = :service_type,
                  attendance_date = :attendance_date,
                  exercise_type = :exercise_type,
                  notes = :notes
                  WHERE attendance_id = :attendance_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':attendance_id', $this->attendance_id);
        $stmt->bindParam(':member_id', $this->member_id);
        $stmt->bindParam(':event_id', $this->event_id);
        $stmt->bindParam(':service_type', $this->service_type);
        $stmt->bindParam(':attendance_date', $this->attendance_date);
        $stmt->bindParam(':exercise_type', $this->exercise_type);
        $stmt->bindParam(':notes', $this->notes);

        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE attendance_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function getByDate($date) {
        $query = "SELECT a.*, m.first_name, m.last_name 
                  FROM {$this->table} a
                  LEFT JOIN members m ON a.member_id = m.member_id
                  WHERE a.attendance_date = :date
                  ORDER BY m.last_name, m.first_name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':date', $date);
        $stmt->execute();
        return $stmt;
    }

    public function getStats($start_date, $end_date) {
        $query = "SELECT 
                  COUNT(*) as total_records,
                  SUM(CASE WHEN exercise_type = 'present' THEN 1 ELSE 0 END) as present,
                  SUM(CASE WHEN exercise_type = 'absent' THEN 1 ELSE 0 END) as absent,
                  SUM(CASE WHEN exercise_type = 'excused' THEN 1 ELSE 0 END) as excused
                  FROM {$this->table}
                  WHERE attendance_date BETWEEN :start_date AND :end_date";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':start_date', $start_date);
        $stmt->bindParam(':end_date', $end_date);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}
