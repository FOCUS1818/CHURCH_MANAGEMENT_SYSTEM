<?php
namespace App;

use PDO;

/**
 * Ministry Model
 * Handles all ministry-related database operations
 */
class Ministry {
    private $conn;
    private $table = 'ministries';

    public $dept_id;
    public $dept_name;
    public $description;
    public $budget;
    public $leader_id;
    public $contact_email;
    public $meeting_schedule;
    public $is_active;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO {$this->table} 
                  (dept_name, description, budget, leader_id, contact_email, meeting_schedule) 
                  VALUES (:dept_name, :description, :budget, :leader_id, :contact_email, :meeting_schedule)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':dept_name', $this->dept_name);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':budget', $this->budget);
        $stmt->bindParam(':leader_id', $this->leader_id);
        $stmt->bindParam(':contact_email', $this->contact_email);
        $stmt->bindParam(':meeting_schedule', $this->meeting_schedule);

        if ($stmt->execute()) {
            $this->dept_id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function readAll($search = '') {
        $searchQuery = $search ? "WHERE dept_name LIKE :search OR description LIKE :search" : "";
        $query = "SELECT * FROM {$this->table} {$searchQuery} ORDER BY dept_name";
        
        $stmt = $this->conn->prepare($query);
        if ($search) {
            $searchTerm = "%{$search}%";
            $stmt->bindParam(':search', $searchTerm);
        }
        $stmt->execute();
        return $stmt;
    }

    public function readOne($id) {
        $query = "SELECT * FROM {$this->table} WHERE dept_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            foreach ($row as $key => $value) {
                $this->$key = $value;
            }
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE {$this->table} SET
                  dept_name = :dept_name,
                  description = :description,
                  budget = :budget,
                  leader_id = :leader_id,
                  contact_email = :contact_email,
                  meeting_schedule = :meeting_schedule,
                  is_active = :is_active
                  WHERE dept_id = :dept_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':dept_id', $this->dept_id);
        $stmt->bindParam(':dept_name', $this->dept_name);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':budget', $this->budget);
        $stmt->bindParam(':leader_id', $this->leader_id);
        $stmt->bindParam(':contact_email', $this->contact_email);
        $stmt->bindParam(':meeting_schedule', $this->meeting_schedule);
        $stmt->bindParam(':is_active', $this->is_active);

        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE dept_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function getMembers($dept_id) {
        $query = "SELECT m.*, mm.role as ministry_role, mm.joined_date
                  FROM ministry_members mm
                  JOIN members m ON mm.member_id = m.member_id
                  WHERE mm.dept_id = :dept_id AND mm.is_active = 1
                  ORDER BY m.last_name, m.first_name";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':dept_id', $dept_id);
        $stmt->execute();
        return $stmt;
    }

    public function addMember($dept_id, $member_id, $role = 'member') {
        $query = "INSERT INTO ministry_members (dept_id, member_id, role) VALUES (:dept_id, :member_id, :role)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':dept_id', $dept_id);
        $stmt->bindParam(':member_id', $member_id);
        $stmt->bindParam(':role', $role);
        return $stmt->execute();
    }

    public function removeMember($dept_id, $member_id) {
        $query = "UPDATE ministry_members SET is_active = 0 WHERE dept_id = :dept_id AND member_id = :member_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':dept_id', $dept_id);
        $stmt->bindParam(':member_id', $member_id);
        return $stmt->execute();
    }

    public function getTotalBudget() {
        $query = "SELECT SUM(budget) as total_budget FROM {$this->table} WHERE is_active = 1";
        $stmt = $this->conn->query($query);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total_budget'] ?? 0;
    }
}
