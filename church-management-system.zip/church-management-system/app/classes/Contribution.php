<?php
namespace App;

use PDO;

/**
 * Contribution Model
 * Handles all contribution-related database operations
 */
class Contribution {
    private $conn;
    private $table = 'contributions';

    public $gift_id;
    public $member_id;
    public $amount;
    public $contribution_date;
    public $fund_type;
    public $payment_method;
    public $transaction_reference;
    public $notes;
    public $recorded_by;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO {$this->table} 
                  (member_id, amount, contribution_date, fund_type, payment_method, transaction_reference, notes, recorded_by) 
                  VALUES (:member_id, :amount, :contribution_date, :fund_type, :payment_method, :transaction_reference, :notes, :recorded_by)";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $this->member_id);
        $stmt->bindParam(':amount', $this->amount);
        $stmt->bindParam(':contribution_date', $this->contribution_date);
        $stmt->bindParam(':fund_type', $this->fund_type);
        $stmt->bindParam(':payment_method', $this->payment_method);
        $stmt->bindParam(':transaction_reference', $this->transaction_reference);
        $stmt->bindParam(':notes', $this->notes);
        $stmt->bindParam(':recorded_by', $this->recorded_by);

        if ($stmt->execute()) {
            $this->gift_id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function readAll($search = '', $page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        
        $query = "SELECT c.*, m.first_name, m.last_name, u.first_name as recorded_by_name, u.last_name as recorded_by_last
                  FROM {$this->table} c
                  LEFT JOIN members m ON c.member_id = m.member_id
                  LEFT JOIN users u ON c.recorded_by = u.user_id
                  ORDER BY c.contribution_date DESC, c.gift_id DESC
                  LIMIT :limit OFFSET :offset";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt;
    }

    public function readOne($id) {
        $query = "SELECT c.*, m.first_name, m.last_name
                  FROM {$this->table} c
                  LEFT JOIN members m ON c.member_id = m.member_id
                  WHERE c.gift_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            foreach ($row as $key => $value) {
                $this->$key = $value;
            }
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE {$this->table} SET
                  member_id = :member_id,
                  amount = :amount,
                  contribution_date = :contribution_date,
                  fund_type = :fund_type,
                  payment_method = :payment_method,
                  transaction_reference = :transaction_reference,
                  notes = :notes
                  WHERE gift_id = :gift_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':gift_id', $this->gift_id);
        $stmt->bindParam(':member_id', $this->member_id);
        $stmt->bindParam(':amount', $this->amount);
        $stmt->bindParam(':contribution_date', $this->contribution_date);
        $stmt->bindParam(':fund_type', $this->fund_type);
        $stmt->bindParam(':payment_method', $this->payment_method);
        $stmt->bindParam(':transaction_reference', $this->transaction_reference);
        $stmt->bindParam(':notes', $this->notes);

        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE gift_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function getTotalByDateRange($start_date, $end_date) {
        $query = "SELECT 
                  SUM(amount) as total_amount,
                  fund_type,
                  COUNT(*) as count
                  FROM {$this->table}
                  WHERE contribution_date BETWEEN :start_date AND :end_date
                  GROUP BY fund_type
                  ORDER BY total_amount DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':start_date', $start_date);
        $stmt->bindParam(':end_date', $end_date);
        $stmt->execute();
        return $stmt;
    }

    public function getTotalAmount($start_date = null, $end_date = null) {
        $query = "SELECT SUM(amount) as total FROM {$this->table}";
        $params = [];
        
        if ($start_date && $end_date) {
            $query .= " WHERE contribution_date BETWEEN :start_date AND :end_date";
            $params[':start_date'] = $start_date;
            $params[':end_date'] = $end_date;
        }
        
        $stmt = $this->conn->prepare($query);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ?? 0;
    }

    public function getByMember($member_id) {
        $query = "SELECT * FROM {$this->table} WHERE member_id = :member_id ORDER BY contribution_date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $member_id);
        $stmt->execute();
        return $stmt;
    }

    public function getStats($year = null) {
        if (!$year) {
            $year = date('Y');
        }
        
        $query = "SELECT 
                  fund_type,
                  SUM(amount) as total,
                  COUNT(*) as count
                  FROM {$this->table}
                  WHERE YEAR(contribution_date) = :year
                  GROUP BY fund_type";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':year', $year);
        $stmt->execute();
        return $stmt;
    }
}
