<?php
namespace App;

use PDO;

/**
 * Event Model
 * Handles all event-related database operations
 */
class Event {
    private $conn;
    private $table = 'events';

    // Properties for legacy schema
    public $event_id;
    public $event_name;
    public $event_date;
    public $event_time;
    public $description;
    public $location;
    public $event_type;
    public $max_capacity;
    public $created_by;
    public $is_active;
    public $created_at;
    public $updated_at;

    // Properties for new schema (events table)
    public $id;
    public $title;
    public $start_datetime;
    public $end_datetime;
    public $requires_rsvp;
    public $rsvp_deadline;
    public $live_stream_url;
    public $is_live;
    public $flyer_image;
    public $is_featured;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Check if a column exists on events table
     */
    private function hasColumn($columnName) {
        $query = "SHOW COLUMNS FROM {$this->table} LIKE :column_name";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':column_name', $columnName);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }

    public function create() {
        $columns = [
            'title', 'description', 'event_type', 'start_datetime', 'end_datetime', 'location',
            'max_capacity', 'requires_rsvp', 'rsvp_deadline', 'flyer_image', 'created_by'
        ];

        if ($this->hasColumn('live_stream_url')) {
            $columns[] = 'live_stream_url';
        }

        if ($this->hasColumn('is_live')) {
            $columns[] = 'is_live';
        }

        if ($this->hasColumn('is_featured')) {
            $columns[] = 'is_featured';
        }

        $placeholders = array_map(function($column) {
            return ':' . $column;
        }, $columns);

        $query = "INSERT INTO {$this->table} (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':title', $this->title);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':event_type', $this->event_type);
        $stmt->bindParam(':start_datetime', $this->start_datetime);
        $stmt->bindParam(':end_datetime', $this->end_datetime);
        $stmt->bindParam(':location', $this->location);
        $stmt->bindParam(':max_capacity', $this->max_capacity);
        $stmt->bindParam(':requires_rsvp', $this->requires_rsvp);
        $stmt->bindParam(':rsvp_deadline', $this->rsvp_deadline);
        $stmt->bindParam(':flyer_image', $this->flyer_image);
        $stmt->bindParam(':created_by', $this->created_by);

        if ($this->hasColumn('live_stream_url')) {
            $stmt->bindParam(':live_stream_url', $this->live_stream_url);
        }

        if ($this->hasColumn('is_live')) {
            $stmt->bindParam(':is_live', $this->is_live);
        }

        if ($this->hasColumn('is_featured')) {
            $stmt->bindParam(':is_featured', $this->is_featured);
        }

        if ($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    public function readAll($search = '', $page = 1, $limit = 20) {
        $offset = ($page - 1) * $limit;
        $searchQuery = $search ? "WHERE title LIKE :search OR description LIKE :search" : "";
        
        $query = "SELECT * FROM {$this->table} {$searchQuery} ORDER BY start_datetime DESC LIMIT :limit OFFSET :offset";
        $stmt = $this->conn->prepare($query);
        
        if ($search) {
            $searchTerm = "%{$search}%";
            $stmt->bindParam(':search', $searchTerm);
        }
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
        
        $stmt->execute();
        return $stmt;
    }

    public function readOne($id) {
        $query = "SELECT * FROM {$this->table} WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            foreach ($row as $key => $value) {
                $this->$key = $value;
            }
            return true;
        }
        return false;
    }

    public function update() {
        $query = "UPDATE {$this->table} SET
                  event_name = :event_name,
                  event_date = :event_date,
                  event_time = :event_time,
                  description = :description,
                  location = :location,
                  event_type = :event_type,
                  max_capacity = :max_capacity,
                  is_active = :is_active
                  WHERE event_id = :event_id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':event_id', $this->event_id);
        $stmt->bindParam(':event_name', $this->event_name);
        $stmt->bindParam(':event_date', $this->event_date);
        $stmt->bindParam(':event_time', $this->event_time);
        $stmt->bindParam(':description', $this->description);
        $stmt->bindParam(':location', $this->location);
        $stmt->bindParam(':event_type', $this->event_type);
        $stmt->bindParam(':max_capacity', $this->max_capacity);
        $stmt->bindParam(':is_active', $this->is_active);

        return $stmt->execute();
    }

    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE event_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    public function getUpcoming($days = 30) {
        $query = "SELECT * FROM {$this->table} 
                  WHERE start_datetime >= CURDATE() AND start_datetime <= DATE_ADD(CURDATE(), INTERVAL :days DAY)
                  ORDER BY start_datetime ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':days', $days, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt;
    }
}
