<?php
namespace App;

use PDO;
use PDOException;

/**
 * Database Connection Class
 * Handles all database connections using PDO
 */
class Database {
    private $host = DB_HOST;
    private $dbname = DB_NAME;
    private $username = DB_USER;
    private $password = DB_PASS;
    private $conn;
    private $error;

    /**
     * Constructor - Establish database connection
     */
    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->dbname};charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_PERSISTENT => false,
        ];

        try {
            $this->conn = new PDO($dsn, $this->username, $this->password, $options);
        } catch (PDOException $e) {
            $this->error = $e->getMessage();
            error_log("Database Connection Error: " . $this->error);
            
            if (APP_ENV === 'development') {
                die("Database connection failed: " . $this->error);
            } else {
                die("System error. Please try again later.");
            }
        }
    }

    /**
     * Get database connection
     */
    public function getConnection() {
        return $this->conn;
    }

    /**
     * Prepare SQL statement
     */
    public function prepare($sql) {
        return $this->conn->prepare($sql);
    }

    /**
     * Execute query
     */
    public function query($sql) {
        return $this->conn->query($sql);
    }

    /**
     * Get last inserted ID
     */
    public function lastInsertId() {
        return $this->conn->lastInsertId();
    }

    /**
     * Begin transaction
     */
    public function beginTransaction() {
        return $this->conn->beginTransaction();
    }

    /**
     * Commit transaction
     */
    public function commit() {
        return $this->conn->commit();
    }

    /**
     * Rollback transaction
     */
    public function rollBack() {
        return $this->conn->rollBack();
    }

    /**
     * Get error
     */
    public function getError() {
        return $this->error;
    }
}
