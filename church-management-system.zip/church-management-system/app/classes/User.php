<?php
namespace App;

use PDO;

/**
 * User Model
 * Handles all user-related database operations
 */
class User {
    private $conn;
    private $table = 'users';

    // User properties
    public $user_id;
    public $username;
    public $email;
    public $password_hash;
    public $first_name;
    public $last_name;
    public $role;
    public $is_active;
    public $last_login;
    public $created_at;
    public $updated_at;

    /**
     * Constructor
     */
    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Create new user
     */
    public function create() {
        $query = "INSERT INTO {$this->table} 
                  (username, email, password_hash, first_name, last_name, role) 
                  VALUES (:username, :email, :password_hash, :first_name, :last_name, :role)";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':password_hash', $this->password_hash);
        $stmt->bindParam(':first_name', $this->first_name);
        $stmt->bindParam(':last_name', $this->last_name);
        $stmt->bindParam(':role', $this->role);

        if ($stmt->execute()) {
            $this->user_id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    /**
     * Login user
     */
    public function login($username, $password) {
        $query = "SELECT * FROM {$this->table} WHERE username = :username AND is_active = 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row && password_verify($password, $row['password_hash'])) {
            $this->user_id = $row['user_id'];
            $this->username = $row['username'];
            $this->email = $row['email'];
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->role = $row['role'];
            
            // Update last login
            $this->updateLastLogin($row['user_id']);
            
            return true;
        }
        return false;
    }

    /**
     * Update last login time
     */
    private function updateLastLogin($user_id) {
        $query = "UPDATE {$this->table} SET last_login = NOW() WHERE user_id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->execute();
    }

    /**
     * Read all users
     */
    public function readAll() {
        $query = "SELECT user_id, username, email, first_name, last_name, role, is_active, last_login, created_at 
                  FROM {$this->table} ORDER BY last_name, first_name";
        $stmt = $this->conn->query($query);
        return $stmt;
    }

    /**
     * Read single user
     */
    public function readOne($id) {
        $query = "SELECT * FROM {$this->table} WHERE user_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $this->user_id = $row['user_id'];
            $this->username = $row['username'];
            $this->email = $row['email'];
            $this->password_hash = $row['password_hash'];
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->role = $row['role'];
            $this->is_active = $row['is_active'];
            $this->last_login = $row['last_login'];
            return true;
        }
        return false;
    }

    /**
     * Update user
     */
    public function update() {
        $query = "UPDATE {$this->table} SET
                  username = :username,
                  email = :email,
                  first_name = :first_name,
                  last_name = :last_name,
                  role = :role,
                  is_active = :is_active
                  WHERE user_id = :user_id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':user_id', $this->user_id);
        $stmt->bindParam(':username', $this->username);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':first_name', $this->first_name);
        $stmt->bindParam(':last_name', $this->last_name);
        $stmt->bindParam(':role', $this->role);
        $stmt->bindParam(':is_active', $this->is_active);

        return $stmt->execute();
    }

    /**
     * Update password
     */
    public function updatePassword($user_id, $new_password) {
        $query = "UPDATE {$this->table} SET password_hash = :password WHERE user_id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':user_id', $user_id);
        $stmt->bindParam(':password', $new_password);
        return $stmt->execute();
    }

    /**
     * Delete user
     */
    public function delete($id) {
        $query = "DELETE FROM {$this->table} WHERE user_id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }

    /**
     * Check if username exists
     */
    public function usernameExists($username, $exclude_id = null) {
        $query = "SELECT COUNT(*) FROM {$this->table} WHERE username = :username";
        if ($exclude_id) {
            $query .= " AND user_id != :exclude_id";
        }
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':username', $username);
        if ($exclude_id) {
            $stmt->bindParam(':exclude_id', $exclude_id);
        }
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Check if email exists
     */
    public function emailExists($email, $exclude_id = null) {
        $query = "SELECT COUNT(*) FROM {$this->table} WHERE email = :email";
        if ($exclude_id) {
            $query .= " AND user_id != :exclude_id";
        }
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        if ($exclude_id) {
            $stmt->bindParam(':exclude_id', $exclude_id);
        }
        $stmt->execute();
        return $stmt->fetchColumn() > 0;
    }

    /**
     * Create password reset token
     */
    public function createPasswordReset($email) {
        $token = bin2hex(random_bytes(32));
        $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
        
        $query = "INSERT INTO password_resets (email, token, expires_at) VALUES (:email, :token, :expires)";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':token', $token);
        $stmt->bindParam(':expires', $expires);
        
        if ($stmt->execute()) {
            return $token;
        }
        return false;
    }

    /**
     * Verify password reset token
     */
    public function verifyPasswordReset($token) {
        $query = "SELECT * FROM password_resets WHERE token = :token AND used = 0 AND expires_at > NOW()";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':token', $token);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    /**
     * Mark password reset as used
     */
    public function markPasswordResetUsed($token) {
        $query = "UPDATE password_resets SET used = 1 WHERE token = :token";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':token', $token);
        return $stmt->execute();
    }

    /**
     * Get user by email
     */
    public function getByEmail($email) {
        $query = "SELECT * FROM {$this->table} WHERE email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $this->user_id = $row['user_id'];
            $this->username = $row['username'];
            $this->email = $row['email'];
            $this->password_hash = $row['password_hash'];
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->role = $row['role'];
            return true;
        }
        return false;
    }
}
