<?php
/**
 * OLEBU Church Management System
 * Admin Dashboard
 */

require_once '../config/config.php';
require_once '../classes/Database.php';
require_once '../classes/Member.php';
require_once '../classes/Event.php';
require_once '../classes/Contribution.php';
require_once '../functions.php';

requireLogin();

$database = new Database();
$db = $database->getConnection();
$member = new Member($db);
$event = new Event($db);
$contribution = new Contribution($db);

// Get statistics
$memberStats = $member->getStats();
$upcomingEvents = $event->getUpcoming(7);
$totalContributions = $contribution->getTotalAmount(date('Y-01-01'), date('Y-12-31'));

// Get recent members
$recentMembers = $member->readAll('', 1, 5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <!-- Navigation -->
        <nav class="bg-indigo-600 text-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center">
                        <a href="dashboard.php" class="flex items-center space-x-2">
                            <i class="fas fa-church text-2xl"></i>
                            <span class="font-bold text-xl">OLEBU Church</span>
                        </a>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Welcome, <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
                        <a href="logout.php" class="bg-indigo-700 px-3 py-2 rounded-md hover:bg-indigo-800">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Sidebar and Main Content -->
        <div class="flex">
            <!-- Sidebar -->
            <aside class="w-64 bg-white shadow-md min-h-screen">
                <div class="p-4">
                    <nav class="space-y-2">
                        <a href="dashboard.php" class="flex items-center space-x-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-md">
                            <i class="fas fa-home w-5"></i>
                            <span>Dashboard</span>
                        </a>
                        <a href="members.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users w-5"></i>
                            <span>Members</span>
                        </a>
                        <a href="households.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-house-user w-5"></i>
                            <span>Households</span>
                        </a>
                        <a href="small-groups.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users-rectangle w-5"></i>
                            <span>Small Groups</span>
                        </a>
                        <a href="events.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-calendar-alt w-5"></i>
                            <span>Events</span>
                        </a>
                        <a href="attendance.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-clipboard-check w-5"></i>
                            <span>Attendance</span>
                        </a>
                        <a href="ministries.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-church w-5"></i>
                            <span>Ministries</span>
                        </a>
                        <a href="contributions.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-hand-holding-heart w-5"></i>
                            <span>Contributions</span>
                        </a>
                        <a href="users.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-user-cog w-5"></i>
                            <span>Users</span>
                        </a>
                    </nav>
                </div>
            </aside>

            <!-- Main Content -->
            <main class="flex-1 p-8">
                <h1 class="text-2xl font-bold text-gray-900 mb-8">Dashboard</h1>

                <!-- Stats Cards -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center">
                            <div class="p-3 bg-indigo-100 rounded-full">
                                <i class="fas fa-users text-indigo-600 text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm text-gray-500">Total Members</p>
                                <p class="text-2xl font-bold"><?php echo $memberStats['total_members'] ?? 0; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center">
                            <div class="p-3 bg-green-100 rounded-full">
                                <i class="fas fa-user-check text-green-600 text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm text-gray-500">Active Members</p>
                                <p class="text-2xl font-bold"><?php echo $memberStats['active_members'] ?? 0; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center">
                            <div class="p-3 bg-blue-100 rounded-full">
                                <i class="fas fa-calendar-check text-blue-600 text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm text-gray-500">Visitors</p>
                                <p class="text-2xl font-bold"><?php echo $memberStats['visitors'] ?? 0; ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center">
                            <div class="p-3 bg-yellow-100 rounded-full">
                                <i class="fas fa-dollar-sign text-yellow-600 text-xl"></i>
                            </div>
                            <div class="ml-4">
                                <p class="text-sm text-gray-500">This Year</p>
                                <p class="text-2xl font-bold"><?php echo formatCurrency($totalContributions); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <!-- Upcoming Events -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-semibold text-gray-900 mb-4">Upcoming Events</h2>
                        <div class="space-y-4">
                            <?php if ($upcomingEvents->rowCount() > 0): ?>
                                <?php while ($eventRow = $upcomingEvents->fetch(PDO::FETCH_ASSOC)): ?>
                                    <div class="flex items-center justify-between border-b pb-3">
                                        <div>
                                            <p class="font-medium text-gray-900"><?php echo htmlspecialchars($eventRow['event_name']); ?></p>
                                            <p class="text-sm text-gray-500">
                                                <?php echo formatDate($eventRow['event_date']); ?> at <?php echo htmlspecialchars($eventRow['event_time']); ?>
                                            </p>
                                        </div>
                                        <span class="px-2 py-1 text-xs rounded-full bg-indigo-100 text-indigo-600">
                                            <?php echo htmlspecialchars($eventRow['event_type']); ?>
                                        </span>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-gray-500">No upcoming events</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Recent Members -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h2 class="text-lg font-semibold text-gray-900 mb-4">Recent Members</h2>
                        <div class="space-y-4">
                            <?php if ($recentMembers->rowCount() > 0): ?>
                                <?php while ($memberRow = $recentMembers->fetch(PDO::FETCH_ASSOC)): ?>
                                    <div class="flex items-center justify-between border-b pb-3">
                                        <div class="flex items-center">
                                            <div class="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                                                <span class="text-indigo-600 font-medium">
                                                    <?php echo strtoupper(substr($memberRow['first_name'], 0, 1) . substr($memberRow['last_name'], 0, 1)); ?>
                                                </span>
                                            </div>
                                            <div class="ml-3">
                                                <p class="font-medium text-gray-900">
                                                    <?php echo htmlspecialchars($memberRow['first_name'] . ' ' . $memberRow['last_name']); ?>
                                                </p>
                                                <p class="text-sm text-gray-500"><?php echo htmlspecialchars($memberRow['email'] ?? 'No email'); ?></p>
                                            </div>
                                        </div>
                                        <span class="px-2 py-1 text-xs rounded-full 
                                            <?php echo $memberRow['membership_status'] === 'active' ? 'bg-green-100 text-green-600' : ($memberRow['membership_status'] === 'visitor' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'); ?>">
                                            <?php echo htmlspecialchars($memberRow['membership_status']); ?>
                                        </span>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="text-gray-500">No members yet</p>
                            <?php endif; ?>
                        </div>
                        <div class="mt-4">
                            <a href="members.php" class="text-indigo-600 hover:text-indigo-800 text-sm font-medium">View all members →</a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
</body>
</html>
