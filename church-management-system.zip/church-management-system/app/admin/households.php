<?php
/**
 * OLEBU Church Management System
 * Households Management Page
 */

require_once '../config/config.php';
require_once '../classes/Database.php';
require_once '../classes/Household.php';
require_once '../functions.php';

requireLogin();

$database = new Database();
$db = $database->getConnection();
$household = new Household($db);

$error = '';

// Handle form submission
if ($_POST && isset($_POST['add_household'])) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $household->family_name = sanitizeInput($_POST['family_name'] ?? '');
        $household->mailing_address = sanitizeInput($_POST['mailing_address'] ?? '');
        $household->phone = sanitizeInput($_POST['phone'] ?? '');
        $household->email = sanitizeInput($_POST['email'] ?? '');
        
        if (empty($household->family_name)) {
            $error = 'Family name is required.';
        } else {
            $household->create();
            logActivity('create', 'households', $household->household_id);
            header('Location: households.php?success=added');
            exit;
        }
    }
}

$households = $household->readAll();

// Handle delete
if (isset($_POST['delete_id']) && verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $household->delete($_POST['delete_id']);
    logActivity('delete', 'households', $_POST['delete_id']);
    header('Location: households.php?success=deleted');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Households - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <nav class="bg-indigo-600 text-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center">
                        <a href="dashboard.php" class="flex items-center space-x-2">
                            <i class="fas fa-church text-2xl"></i>
                            <span class="font-bold text-xl">OLEBU Church</span>
                        </a>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Welcome, <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
                        <a href="logout.php" class="bg-indigo-700 px-3 py-2 rounded-md hover:bg-indigo-800">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <div class="flex">
            <aside class="w-64 bg-white shadow-md min-h-screen">
                <div class="p-4">
                    <nav class="space-y-2">
                        <a href="dashboard.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-home w-5"></i><span>Dashboard</span>
                        </a>
                        <a href="members.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users w-5"></i><span>Members</span>
                        </a>
                        <a href="households.php" class="flex items-center space-x-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-md">
                            <i class="fas fa-house-user w-5"></i><span>Households</span>
                        </a>
                        <a href="small-groups.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users-rectangle w-5"></i><span>Small Groups</span>
                        </a>
                        <a href="events.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-calendar-alt w-5"></i><span>Events</span>
                        </a>
                        <a href="attendance.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-clipboard-check w-5"></i><span>Attendance</span>
                        </a>
                        <a href="ministries.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-church w-5"></i><span>Ministries</span>
                        </a>
                        <a href="contributions.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-hand-holding-heart w-5"></i><span>Contributions</span>
                        </a>
                    </nav>
                </div>
            </aside>

            <main class="flex-1 p-8">
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-2xl font-bold text-gray-900">Households</h1>
                    <button onclick="document.getElementById('householdModal').classList.remove('hidden')" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                        <i class="fas fa-plus mr-2"></i>Add Household
                    </button>
                </div>

                <?php if (isset($_GET['success'])): ?>
                    <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md mb-6">
                        Operation completed successfully.
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md mb-6">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Family Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Address</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Phone</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if ($households->rowCount() > 0): ?>
                                <?php while ($row = $households->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                                            <?php echo htmlspecialchars($row['family_name']); ?>
                                        </td>
                                        <td class="px-6 py-4 text-gray-500">
                                            <?php echo htmlspecialchars($row['mailing_address'] ?? '-'); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-gray-500">
                                            <?php echo htmlspecialchars($row['phone'] ?? '-'); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-gray-500">
                                            <?php echo htmlspecialchars($row['email'] ?? '-'); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <form method="POST" class="inline" onsubmit="return confirm('Delete this household?');">
                                                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                                <input type="hidden" name="delete_id" value="<?php echo $row['household_id']; ?>">
                                                <button type="submit" class="text-red-600 hover:text-red-900">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="px-6 py-4 text-center text-gray-500">No households found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <!-- Add Household Modal -->
    <div id="householdModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-4">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Add Household</h3>
                <button onclick="document.getElementById('householdModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="add_household" value="1">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Family Name *</label>
                    <input type="text" name="family_name" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Mailing Address</label>
                    <textarea name="mailing_address" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500"></textarea>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                    <input type="tel" name="phone" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                    <input type="email" name="email" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="document.getElementById('householdModal').classList.add('hidden')" class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400">Cancel</button>
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">Add Household</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
