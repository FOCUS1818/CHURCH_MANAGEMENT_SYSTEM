<?php
/**
 * OLEBU Church Management System
 * Add Member Page
 */

require_once '../config/config.php';
require_once '../classes/Database.php';
require_once '../classes/Member.php';
require_once '../classes/Household.php';
require_once '../classes/SmallGroup.php';
require_once '../functions.php';

requireLogin();

$database = new Database();
$db = $database->getConnection();
$member = new Member($db);
$household = new Household($db);
$smallGroup = new SmallGroup($db);

$error = '';
$success = '';

// Get households and small groups for dropdown
$households = $household->readAll();
$smallGroups = $smallGroup->getActiveGroups();

if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $member->household_id = !empty($_POST['household_id']) ? (int)$_POST['household_id'] : null;
        $member->small_group_id = !empty($_POST['small_group_id']) ? (int)$_POST['small_group_id'] : null;
        $member->first_name = sanitizeInput($_POST['first_name'] ?? '');
        $member->last_name = sanitizeInput($_POST['last_name'] ?? '');
        $member->email = sanitizeInput($_POST['email'] ?? '');
        $member->phone = sanitizeInput($_POST['phone'] ?? '');
        $member->join_date = $_POST['join_date'] ?: date('Y-m-d');
        $member->gender = $_POST['gender'] ?? '';
        $member->date_of_birth = $_POST['date_of_birth'] ?: null;
        $member->marital_status = $_POST['marital_status'] ?? 'single';
        $member->address = sanitizeInput($_POST['address'] ?? '');
        $member->membership_status = $_POST['membership_status'] ?? 'visitor';
        $member->baptism_date = $_POST['baptism_date'] ?: null;
        $member->notes = sanitizeInput($_POST['notes'] ?? '');
        
        // Validation
        if (empty($member->first_name) || empty($member->last_name)) {
            $error = 'First name and last name are required.';
        }
        // Validate first name - letters only
        elseif (!validateName($member->first_name)) {
            $error = 'First name should only contain letters (a-z, A-Z). Numbers are not allowed.';
        }
        // Validate last name - letters only
        elseif (!validateName($member->last_name)) {
            $error = 'Last name should only contain letters (a-z, A-Z). Numbers are not allowed.';
        }
        // Validate phone - numbers only
        elseif (!empty($member->phone) && !validatePhone($member->phone)) {
            $error = 'Phone number should only contain numbers. Letters are not allowed.';
        }
        // Validate notes - max 50 words
        elseif (!validateWordLimit($member->notes, 50)) {
            $error = 'Notes should not exceed 50 words. Please shorten your notes.';
        }
        // Validate date of birth is not in the future
        elseif (!empty($member->date_of_birth) && strtotime($member->date_of_birth) > strtotime('today')) {
            $error = 'Date of birth cannot be in the future.';
        }
        // Validate baptism date is not in the future
        elseif (!empty($member->baptism_date) && strtotime($member->baptism_date) > strtotime('today')) {
            $error = 'Baptism date cannot be in the future.';
        }
        else {
            if ($member->create()) {
                logActivity('create', 'members', $member->member_id);
                header('Location: members.php?success=added');
                exit;
            } else {
                $error = 'Failed to add member. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Member - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <!-- Navigation -->
        <nav class="bg-indigo-600 text-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center">
                        <a href="dashboard.php" class="flex items-center space-x-2">
                            <i class="fas fa-church text-2xl"></i>
                            <span class="font-bold text-xl">OLEBU Church</span>
                        </a>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Welcome, <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
                        <a href="logout.php" class="bg-indigo-700 px-3 py-2 rounded-md hover:bg-indigo-800">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <div class="flex">
            <!-- Sidebar -->
            <aside class="w-64 bg-white shadow-md min-h-screen">
                <div class="p-4">
                    <nav class="space-y-2">
                        <a href="dashboard.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-home w-5"></i>
                            <span>Dashboard</span>
                        </a>
                        <a href="members.php" class="flex items-center space-x-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-md">
                            <i class="fas fa-users w-5"></i>
                            <span>Members</span>
                        </a>
                        <a href="households.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-house-user w-5"></i>
                            <span>Households</span>
                        </a>
                        <a href="small-groups.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users-rectangle w-5"></i>
                            <span>Small Groups</span>
                        </a>
                        <a href="events.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-calendar-alt w-5"></i>
                            <span>Events</span>
                        </a>
                        <a href="attendance.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-clipboard-check w-5"></i>
                            <span>Attendance</span>
                        </a>
                        <a href="ministries.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-church w-5"></i>
                            <span>Ministries</span>
                        </a>
                        <a href="contributions.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-hand-holding-heart w-5"></i>
                            <span>Contributions</span>
                        </a>
                        <a href="users.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-user-cog w-5"></i>
                            <span>Users</span>
                        </a>
                    </nav>
                </div>
            </aside>

            <!-- Main Content -->
            <main class="flex-1 p-8">
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-2xl font-bold text-gray-900">Add New Member</h1>
                    <a href="members.php" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700">
                        <i class="fas fa-arrow-left mr-2"></i>Back
                    </a>
                </div>

                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md mb-6">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" id="memberForm" class="bg-white shadow rounded-lg p-6">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <!-- Personal Information -->
                        <div class="space-y-6">
                            <h3 class="text-lg font-medium text-gray-900 border-b pb-2">Personal Information</h3>
                            
                            <div>
                                <label for="first_name" class="block text-sm font-medium text-gray-700 mb-2">First Name *</label>
                                <input type="text" id="first_name" name="first_name" required 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                            
                            <div>
                                <label for="last_name" class="block text-sm font-medium text-gray-700 mb-2">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" required 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                            
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label for="gender" class="block text-sm font-medium text-gray-700 mb-2">Gender</label>
                                    <select id="gender" name="gender" 
                                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                        <option value="">Select</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                                <div>
                                    <label for="date_of_birth" class="block text-sm font-medium text-gray-700 mb-2">Date of Birth</label>
                                    <input type="date" id="date_of_birth" name="date_of_birth" 
                                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                </div>
                            </div>
                            
                            <div>
                                <label for="marital_status" class="block text-sm font-medium text-gray-700 mb-2">Marital Status</label>
                                <select id="marital_status" name="marital_status" 
                                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                    <option value="single">Single</option>
                                    <option value="married">Married</option>
                                    <option value="divorced">Divorced</option>
                                    <option value="widowed">Widowed</option>
                                </select>
                            </div>
                        </div>
                        
                        <!-- Contact Information -->
                        <div class="space-y-6">
                            <h3 class="text-lg font-medium text-gray-900 border-b pb-2">Contact Information</h3>
                            
                            <div>
                                <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                                <input type="email" id="email" name="email" 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                            
                            <div>
                                <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                                <input type="tel" id="phone" name="phone" 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                            
                            <div>
                                <label for="address" class="block text-sm font-medium text-gray-700 mb-2">Address</label>
                                <textarea id="address" name="address" rows="3" 
                                          class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"></textarea>
                            </div>
                            
                            <div>
                                <label for="household_id" class="block text-sm font-medium text-gray-700 mb-2">Household</label>
                                <select id="household_id" name="household_id" 
                                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                    <option value="">Select Household (Optional)</option>
                                    <?php while ($hh = $households->fetch(PDO::FETCH_ASSOC)): ?>
                                        <option value="<?php echo $hh['household_id']; ?>">
                                            <?php echo htmlspecialchars($hh['family_name']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Membership Information -->
                    <div class="mt-8 space-y-6">
                        <h3 class="text-lg font-medium text-gray-900 border-b pb-2">Membership Information</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="small_group_id" class="block text-sm font-medium text-gray-700 mb-2">Small Group</label>
                                <select id="small_group_id" name="small_group_id" 
                                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                    <option value="">Select Small Group (Optional)</option>
                                    <?php while ($sg = $smallGroups->fetch(PDO::FETCH_ASSOC)): ?>
                                        <option value="<?php echo $sg['group_id']; ?>">
                                            <?php echo htmlspecialchars($sg['group_name']); ?> (<?php echo htmlspecialchars($sg['meeting_day']); ?>)
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <div>
                                <label for="join_date" class="block text-sm font-medium text-gray-700 mb-2">Join Date</label>
                                <input type="date" id="join_date" name="join_date" value="<?php echo date('Y-m-d'); ?>" 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                            
                            <div>
                                <label for="membership_status" class="block text-sm font-medium text-gray-700 mb-2">Membership Status</label>
                                <select id="membership_status" name="membership_status" 
                                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                    <option value="visitor">Visitor</option>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                            
                            <div>
                                <label for="baptism_date" class="block text-sm font-medium text-gray-700 mb-2">Baptism Date</label>
                                <input type="date" id="baptism_date" name="baptism_date" 
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                        </div>
                        
                        <div>
                            <label for="notes" class="block text-sm font-medium text-gray-700 mb-2">Notes <span class="text-gray-500">(max 50 words)</span></label>
                            <textarea id="notes" name="notes" rows="4" 
                                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                      oninput="updateWordCount(this, 'notesCount', 50)"></textarea>
                            <p class="text-sm text-gray-500 mt-1">Words: <span id="notesCount">0</span>/50</p>
                        </div>
                    </div>
                    
                    <div class="mt-8 flex justify-end space-x-4">
                        <a href="members.php" class="bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700">
                            Cancel
                        </a>
                        <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700">
                            Add Member
                        </button>
                    </div>
                </form>
            </main>
        </div>
    </div>

    <script>
    // Word count function
    function updateWordCount(textarea, displayId, limit) {
        const text = textarea.value.trim();
        const words = text === '' ? 0 : text.split(/\s+/).filter(word => word.length > 0).length;
        const display = document.getElementById(displayId);
        display.textContent = words;
        
        if (words > limit) {
            display.classList.add('text-red-600');
            display.classList.remove('text-gray-500');
        } else {
            display.classList.remove('text-red-600');
            display.classList.add('text-gray-500');
        }
    }
    
    // Form validation
    document.getElementById('memberForm').addEventListener('submit', function(e) {
        const firstName = document.getElementById('first_name').value;
        const lastName = document.getElementById('last_name').value;
        const phone = document.getElementById('phone').value;
        const notes = document.getElementById('notes').value;
        
        // Name validation - letters only
        const namePattern = /^[a-zA-Z\s\-\'\.]+$/;
        
        if (firstName && !namePattern.test(firstName)) {
            alert('First name should only contain letters (a-z, A-Z). Numbers are not allowed.');
            e.preventDefault();
            return false;
        }
        
        if (lastName && !namePattern.test(lastName)) {
            alert('Last name should only contain letters (a-z, A-Z). Numbers are not allowed.');
            e.preventDefault();
            return false;
        }
        
        // Phone validation - numbers only
        if (phone && !/^[0-9\s\-\(\)\+]+$/.test(phone)) {
            alert('Phone number should only contain numbers. Letters are not allowed.');
            e.preventDefault();
            return false;
        }
        
        // Notes word limit
        const wordCount = notes.trim() === '' ? 0 : notes.trim().split(/\s+/).filter(word => word.length > 0).length;
        if (wordCount > 50) {
            alert('Notes should not exceed 50 words. Please shorten your notes.');
            e.preventDefault();
            return false;
        }
        
        return true;
    });
    
    // Add input restrictions for name fields - prevent numbers
    document.getElementById('first_name').addEventListener('input', function(e) {
        this.value = this.value.replace(/[0-9]/g, '');
    });
    
    document.getElementById('last_name').addEventListener('input', function(e) {
        this.value = this.value.replace(/[0-9]/g, '');
    });
    
    // Add input restrictions for phone field - prevent letters
    document.getElementById('phone').addEventListener('input', function(e) {
        this.value = this.value.replace(/[a-zA-Z]/g, '');
    });
    </script>
</body>
</html>
