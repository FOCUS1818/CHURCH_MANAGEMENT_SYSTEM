<?php
/**
 * OLEBU Church Management System
 * Logout Page
 */

require_once '../config/config.php';
require_once '../functions.php';

if (isLoggedIn()) {
    logActivity('logout', 'users', $_SESSION['user_id']);
}

session_unset();
session_destroy();

header('Location: ' . APP_URL . '/login.php');
exit;
