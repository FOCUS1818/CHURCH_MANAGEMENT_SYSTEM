<?php
/**
 * OLEBU Church Management System
 * Attendance Management Page
 */

require_once '../config/config.php';
require_once '../classes/Database.php';
require_once '../classes/Attendance.php';
require_once '../classes/Member.php';
require_once '../classes/Event.php';
require_once '../functions.php';

requireLogin();

$database = new Database();
$db = $database->getConnection();
$attendance = new Attendance($db);
$member = new Member($db);
$event = new Event($db);

$error = '';
$success = '';

// Handle form submission
if ($_POST && isset($_POST['record_attendance'])) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $attendance->member_id = (int)$_POST['member_id'];
        $attendance->event_id = !empty($_POST['event_id']) ? (int)$_POST['event_id'] : null;
        $attendance->service_type = sanitizeInput($_POST['service_type'] ?? '');
        $attendance->attendance_date = $_POST['attendance_date'] ?? date('Y-m-d');
        $attendance->exercise_type = $_POST['exercise_type'] ?? 'present';
        $attendance->notes = sanitizeInput($_POST['notes'] ?? '');
        $attendance->recorded_by = $_SESSION['user_id'];
        
        if (empty($attendance->member_id)) {
            $error = 'Please select a member.';
        } else {
            if ($attendance->create()) {
                logActivity('create', 'attendance', $attendance->attendance_id);
                header('Location: attendance.php?success=added');
                exit;
            } else {
                $error = 'Failed to record attendance. Please try again.';
            }
        }
    }
}

// Get all data
$attendances = $attendance->readAll();
$members = $member->readAll();
$events = $event->getUpcoming(30);

// Handle delete
if (isset($_POST['delete_id']) && verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $attendance->delete($_POST['delete_id']);
    logActivity('delete', 'attendance', $_POST['delete_id']);
    header('Location: attendance.php?success=deleted');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <nav class="bg-indigo-600 text-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center">
                        <a href="dashboard.php" class="flex items-center space-x-2">
                            <i class="fas fa-church text-2xl"></i>
                            <span class="font-bold text-xl">OLEBU Church</span>
                        </a>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Welcome, <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
                        <a href="logout.php" class="bg-indigo-700 px-3 py-2 rounded-md hover:bg-indigo-800">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <div class="flex">
            <aside class="w-64 bg-white shadow-md min-h-screen">
                <div class="p-4">
                    <nav class="space-y-2">
                        <a href="dashboard.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-home w-5"></i><span>Dashboard</span>
                        </a>
                        <a href="members.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users w-5"></i><span>Members</span>
                        </a>
                        <a href="households.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-house-user w-5"></i><span>Households</span>
                        </a>
                        <a href="small-groups.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users-rectangle w-5"></i><span>Small Groups</span>
                        </a>
                        <a href="events.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-calendar-alt w-5"></i><span>Events</span>
                        </a>
                        <a href="attendance.php" class="flex items-center space-x-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-md">
                            <i class="fas fa-clipboard-check w-5"></i><span>Attendance</span>
                        </a>
                        <a href="ministries.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-church w-5"></i><span>Ministries</span>
                        </a>
                        <a href="contributions.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-hand-holding-heart w-5"></i><span>Contributions</span>
                        </a>
                    </nav>
                </div>
            </aside>

            <main class="flex-1 p-8">
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-2xl font-bold text-gray-900">Attendance Management</h1>
                    <button onclick="document.getElementById('attendanceModal').classList.remove('hidden')" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                        <i class="fas fa-plus mr-2"></i>Record Attendance
                    </button>
                </div>

                <?php if (isset($_GET['success'])): ?>
                    <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md mb-6">
                        Attendance recorded successfully.
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md mb-6">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <!-- Attendance Table -->
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Member</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Service Type</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if ($attendances->rowCount() > 0): ?>
                                <?php while ($row = $attendances->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                                            <?php echo htmlspecialchars(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php echo formatDate($row['attendance_date']); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php echo htmlspecialchars($row['service_type'] ?? '-'); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                                <?php echo $row['exercise_type'] === 'present' ? 'bg-green-100 text-green-800' : 
                                                    ($row['exercise_type'] === 'absent' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                                <?php echo ucfirst($row['exercise_type']); ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <form method="POST" class="inline" onsubmit="return confirm('Delete this record?');">
                                                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                                <input type="hidden" name="delete_id" value="<?php echo $row['attendance_id']; ?>">
                                                <button type="submit" class="text-red-600 hover:text-red-900">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="px-6 py-4 text-center text-gray-500">No attendance records found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <!-- Record Attendance Modal -->
    <div id="attendanceModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-4">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Record Attendance</h3>
                <button onclick="document.getElementById('attendanceModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="record_attendance" value="1">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Member *</label>
                    <select name="member_id" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                        <option value="">Select Member</option>
                        <?php while ($m = $members->fetch(PDO::FETCH_ASSOC)): ?>
                            <option value="<?php echo $m['member_id']; ?>">
                                <?php echo htmlspecialchars($m['first_name'] . ' ' . $m['last_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Service Type</label>
                    <input type="text" name="service_type" placeholder="e.g., Sunday Service" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Date</label>
                        <input type="date" name="attendance_date" value="<?php echo date('Y-m-d'); ?>" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                        <select name="exercise_type" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                            <option value="present">Present</option>
                            <option value="absent">Absent</option>
                            <option value="excused">Excused</option>
                        </select>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                    <textarea name="notes" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500"></textarea>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="document.getElementById('attendanceModal').classList.add('hidden')" class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400">Cancel</button>
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">Record</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
