<?php
/**
 * OLEBU Church Management System
 * Events Management Page
 */

require_once '../config/config.php';
require_once '../classes/Database.php';
require_once '../classes/Event.php';
require_once '../functions.php';

requireLogin();

$database = new Database();
$db = $database->getConnection();
$event = new Event($db);

$error = '';
$success = '';

// Handle form submission
if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $event->event_name = sanitizeInput($_POST['event_name'] ?? '');
        $event->event_date = $_POST['event_date'] ?? '';
        $event->event_time = $_POST['event_time'] ?? '';
        $event->description = sanitizeInput($_POST['description'] ?? '');
        $event->location = sanitizeInput($_POST['location'] ?? '');
        $event->event_type = $_POST['event_type'] ?? 'service';
        $event->max_capacity = !empty($_POST['max_capacity']) ? (int)$_POST['max_capacity'] : null;
        $event->created_by = $_SESSION['user_id'];
        
        if (empty($event->event_name) || empty($event->event_date)) {
            $error = 'Event name and date are required.';
        } else {
            if ($event->create()) {
                logActivity('create', 'events', $event->event_id);
                header('Location: events.php?success=added');
                exit;
            } else {
                $error = 'Failed to add event. Please try again.';
            }
        }
    }
}

// Get events
$events = $event->readAll();

// Handle delete
if (isset($_POST['delete_id']) && verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $event->delete($_POST['delete_id']);
    logActivity('delete', 'events', $_POST['delete_id']);
    header('Location: events.php?success=deleted');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events - <?php echo APP_NAME; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="bg-gray-100">
    <div class="min-h-screen">
        <nav class="bg-indigo-600 text-white shadow-lg">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex items-center justify-between h-16">
                    <div class="flex items-center">
                        <a href="dashboard.php" class="flex items-center space-x-2">
                            <i class="fas fa-church text-2xl"></i>
                            <span class="font-bold text-xl">OLEBU Church</span>
                        </a>
                    </div>
                    <div class="flex items-center space-x-4">
                        <span class="text-sm">Welcome, <?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
                        <a href="logout.php" class="bg-indigo-700 px-3 py-2 rounded-md hover:bg-indigo-800">
                            <i class="fas fa-sign-out-alt mr-2"></i>Logout
                        </a>
                    </div>
                </div>
            </div>
        </nav>

        <div class="flex">
            <aside class="w-64 bg-white shadow-md min-h-screen">
                <div class="p-4">
                    <nav class="space-y-2">
                        <a href="dashboard.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-home w-5"></i><span>Dashboard</span>
                        </a>
                        <a href="members.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users w-5"></i><span>Members</span>
                        </a>
                        <a href="households.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-house-user w-5"></i><span>Households</span>
                        </a>
                        <a href="small-groups.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-users-rectangle w-5"></i><span>Small Groups</span>
                        </a>
                        <a href="events.php" class="flex items-center space-x-2 px-4 py-2 bg-indigo-50 text-indigo-600 rounded-md">
                            <i class="fas fa-calendar-alt w-5"></i><span>Events</span>
                        </a>
                        <a href="attendance.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-clipboard-check w-5"></i><span>Attendance</span>
                        </a>
                        <a href="ministries.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-church w-5"></i><span>Ministries</span>
                        </a>
                        <a href="contributions.php" class="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:bg-gray-50 rounded-md">
                            <i class="fas fa-hand-holding-heart w-5"></i><span>Contributions</span>
                        </a>
                    </nav>
                </div>
            </aside>

            <main class="flex-1 p-8">
                <div class="flex justify-between items-center mb-6">
                    <h1 class="text-2xl font-bold text-gray-900">Church Events</h1>
                    <button onclick="document.getElementById('eventModal').classList.remove('hidden')" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                        <i class="fas fa-plus mr-2"></i>Add Event
                    </button>
                </div>

                <?php if (isset($_GET['success'])): ?>
                    <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md mb-6">
                        Event added successfully.
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md mb-6">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <!-- Events Table -->
                <div class="bg-white rounded-lg shadow overflow-hidden">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Event Name</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date & Time</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Type</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Location</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php if ($events->rowCount() > 0): ?>
                                <?php while ($row = $events->fetch(PDO::FETCH_ASSOC)): ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap font-medium text-gray-900">
                                            <?php echo htmlspecialchars($row['event_name']); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <?php echo formatDate($row['event_date']); ?> at <?php echo htmlspecialchars($row['event_time'] ?? 'N/A'); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                                                <?php echo htmlspecialchars($row['event_type']); ?>
                                            </span>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-gray-500">
                                            <?php echo htmlspecialchars($row['location'] ?? '-'); ?>
                                        </td>
                                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                            <form method="POST" class="inline" onsubmit="return confirm('Delete this event?');">
                                                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                                <input type="hidden" name="delete_id" value="<?php echo $row['event_id']; ?>">
                                                <button type="submit" class="text-red-600 hover:text-red-900">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="px-6 py-4 text-center text-gray-500">No events found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>

    <!-- Add Event Modal -->
    <div id="eventModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-4">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Add New Event</h3>
                <button onclick="document.getElementById('eventModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Event Name *</label>
                    <input type="text" name="event_name" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Date *</label>
                        <input type="date" name="event_date" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Time</label>
                        <input type="time" name="event_time" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                    </div>
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Type</label>
                        <select name="event_type" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                            <option value="service">Service</option>
                            <option value="meeting">Meeting</option>
                            <option value="youth">Youth</option>
                            <option value="community">Community</option>
                            <option value="special">Special</option>
                            <option value="worship">Worship</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Max Capacity</label>
                        <input type="number" name="max_capacity" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Location</label>
                    <input type="text" name="location" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                    <textarea name="description" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500"></textarea>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="document.getElementById('eventModal').classList.add('hidden')" class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400">Cancel</button>
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">Add Event</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
