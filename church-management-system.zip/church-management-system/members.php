<?php
require_once 'config/config.php';

use App\Database;

$database = new Database();
$db = $database->getConnection();

// Get active tab from query parameter
$active_tab = $_GET['tab'] ?? 'members';

// Get specific household if requested
$household_id = $_GET['household'] ?? null;
$small_group_id = $_GET['small_group'] ?? null;

// Get all active members ordered alphabetically
$stmt = $db->prepare("SELECT m.*, 
                      GROUP_CONCAT(DISTINCT sg.group_name ORDER BY sg.group_name SEPARATOR ', ') as small_groups 
                      FROM members m 
                      LEFT JOIN member_small_groups msg ON m.id = msg.member_id
                      LEFT JOIN small_groups sg ON msg.small_group_id = sg.id
                      WHERE m.membership_status = 'active'
                      GROUP BY m.id
                      ORDER BY m.last_name, m.first_name");
$stmt->execute();
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all households ordered by name
$stmt = $db->query("SELECT * FROM households ORDER BY household_name");
$households = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get all active small groups ordered by name
$stmt = $db->query("SELECT * FROM small_groups WHERE is_active = 1 ORDER BY group_name");
$smallGroups = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get member counts for each small group
$groupMemberCounts = [];
foreach ($smallGroups as $group) {
    $stmt = $db->prepare("SELECT COUNT(m.id) as count FROM members m JOIN member_small_groups msg ON m.id = msg.member_id WHERE msg.small_group_id = ? AND m.membership_status = 'active'");
    $stmt->execute([$group['id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $groupMemberCounts[$group['id']] = $result['count'] ?? 0;
}

// Get member counts for each household
$householdMemberCounts = [];
foreach ($households as $household) {
    $stmt = $db->prepare("SELECT COUNT(*) as count FROM members WHERE household_id = ? AND membership_status = 'active'");
    $stmt->execute([$household['id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $householdMemberCounts[$household['id']] = $result['count'] ?? 0;
}

// If viewing a specific household, get those members
$householdMembers = [];
$currentHousehold = null;
if ($household_id) {
    $stmt = $db->prepare("SELECT * FROM households WHERE id = ?");
    $stmt->execute([$household_id]);
    $currentHousehold = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $db->prepare("SELECT first_name, last_name, photo, email, phone, membership_status 
                          FROM members 
                          WHERE household_id = ? AND membership_status = 'active'
                          ORDER BY last_name, first_name");
    $stmt->execute([$household_id]);
    $householdMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// If viewing a specific small group, get those members
$groupMembers = [];
$currentGroup = null;
if ($small_group_id) {
    $stmt = $db->prepare("SELECT * FROM small_groups WHERE id = ?");
    $stmt->execute([$small_group_id]);
    $currentGroup = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $stmt = $db->prepare("SELECT m.first_name, m.last_name, m.photo, m.email, m.phone, m.membership_status 
                          FROM members m 
                          JOIN member_small_groups msg ON m.id = msg.member_id 
                          WHERE msg.small_group_id = ? AND m.membership_status = 'active'
                          ORDER BY m.last_name, m.first_name");
    $stmt->execute([$small_group_id]);
    $groupMembers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Members - Olebu SDA Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center">
                            <i class="fas fa-church text-white text-lg"></i>
                        </div>
                        <h1 class="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                            OLEBU SDA CHURCH
                        </h1>
                    </div>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Home</a>
                    <a href="sermons.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Sermons</a>
                    <a href="events.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Events</a>
                    <a href="live-streaming.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Live Stream</a>
                    <a href="ministries.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Ministries</a>
                    <a href="members.php" class="text-indigo-600 font-medium">Members</a>
                    <a href="giving.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Give</a>
                    <a href="contact.php" class="text-gray-700 hover:text-indigo-600 transition-colors duration-200 font-medium">Contact</a>
                    <a href="admin/login.php" class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-lg hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 font-medium shadow-lg hover:shadow-xl">
                        Admin
                    </a>
                </div>
                <div class="md:hidden">
                    <button class="text-gray-700 hover:text-indigo-600">
                        <i class="fas fa-bars text-xl"></i>
                    </button>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
    <!-- Hero Section -->
    <div class="bg-gradient-to-r from-pink-500 to-rose-600 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">Church Members Portal</h1>
            <p class="text-xl text-pink-100">Welcome to our church family</p>
        </div>
    </div>

    <!-- Tab Navigation -->
    <div class="mt-8">
        <div class="border-b border-gray-200">
            <nav class="flex justify-center space-x-8" aria-label="Tabs">
                <a href="?tab=members" class="<?php echo $active_tab === 'members' ? 'border-pink-500 text-pink-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?> inline-flex items-center px-1 py-4 border-b-2 font-medium text-sm">
                    <i class="fas fa-users mr-2"></i>Members
                </a>
                <a href="?tab=households" class="<?php echo $active_tab === 'households' ? 'border-pink-500 text-pink-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?> inline-flex items-center px-1 py-4 border-b-2 font-medium text-sm">
                    <i class="fas fa-home mr-2"></i>Households
                </a>
                <a href="?tab=small-groups" class="<?php echo $active_tab === 'small-groups' ? 'border-pink-500 text-pink-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'; ?> inline-flex items-center px-1 py-4 border-b-2 font-medium text-sm">
                    <i class="fas fa-users-rectangle mr-2"></i>Small Groups
                </a>
            </nav>
        </div>
    </div>

    <!-- Members Tab Content -->
    <?php if ($active_tab === 'members'): ?>
        <?php if (empty($members)): ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-1.306-.835-2.418-2-2.83M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-1.306.835-2.418 2-2.83m0 0a3 3 0 000-5.356M9 12a3 3 0 000 5.356m0 0a3 3 0 000-5.356m0 0a3 3 0 000 5.356"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No members found</h3>
                <p class="mt-1 text-sm text-gray-500">Check back later.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-8">
                <?php foreach ($members as $member): ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 p-6">
                        <div class="text-center">
                            <?php if ($member['photo']): ?>
                                <img src="uploads/<?php echo htmlspecialchars($member['photo']); ?>" 
                                     alt="<?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>" 
                                     class="w-24 h-24 rounded-full mx-auto object-cover mb-4">
                            <?php else: ?>
                                <div class="w-24 h-24 rounded-full mx-auto bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center mb-4">
                                    <span class="text-3xl font-bold text-white">
                                        <?php echo strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1)); ?>
                                    </span>
                                </div>
                            <?php endif; ?>
                            
                            <h3 class="text-lg font-semibold text-gray-900 mb-1">
                                <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                            </h3>
                            
                            <?php if ($member['email']): ?>
                                <p class="text-sm text-gray-500 mb-1">
                                    <i class="fas fa-envelope mr-1"></i>
                                    <?php echo htmlspecialchars($member['email']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <?php if ($member['phone']): ?>
                                <p class="text-sm text-gray-500">
                                    <i class="fas fa-phone mr-1"></i>
                                    <?php echo htmlspecialchars($member['phone']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <?php if (!empty($member['small_groups'])): ?>
                                <p class="text-sm text-indigo-600 mt-2">
                                    <i class="fas fa-users mr-1"></i>
                                    <?php echo htmlspecialchars($member['small_groups']); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="mt-8 text-center text-gray-600">
                <p>Total Members: <?php echo count($members); ?></p>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Households Tab Content -->
    <?php if ($active_tab === 'households'): ?>
        <?php if ($household_id && $currentHousehold): ?>
            <!-- View specific household members -->
            <div class="mt-8">
                <div class="flex items-center mb-6">
                    <a href="?tab=households" class="text-indigo-600 hover:text-indigo-800 mr-2">
                        <i class="fas fa-arrow-left"></i> Back to Households
                    </a>
                </div>
                <h2 class="text-2xl font-bold text-gray-900 text-center mb-2">
                    <?php echo htmlspecialchars($currentHousehold['household_name']); ?>
                </h2>
                <p class="text-gray-600 text-center mb-8">Household Members</p>
                
                <?php if ($currentHousehold['address'] || $currentHousehold['phone'] || $currentHousehold['email']): ?>
                    <div class="bg-white rounded-lg shadow-md p-4 mb-6 max-w-2xl mx-auto">
                        <h3 class="font-semibold text-gray-700 mb-2">Contact Information</h3>
                        <?php if ($currentHousehold['address']): ?>
                            <p class="text-sm text-gray-600"><i class="fas fa-map-marker-alt mr-2"></i><?php echo htmlspecialchars($currentHousehold['address']); ?></p>
                        <?php endif; ?>
                        <?php if ($currentHousehold['phone']): ?>
                            <p class="text-sm text-gray-600"><i class="fas fa-phone mr-2"></i><?php echo htmlspecialchars($currentHousehold['phone']); ?></p>
                        <?php endif; ?>
                        <?php if ($currentHousehold['email']): ?>
                            <p class="text-sm text-gray-600"><i class="fas fa-envelope mr-2"></i><?php echo htmlspecialchars($currentHousehold['email']); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (empty($householdMembers)): ?>
                    <p class="text-center text-gray-500">No active members in this household.</p>
                <?php else: ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        <?php foreach ($householdMembers as $member): ?>
                            <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 p-6">
                                <div class="text-center">
                                    <?php if ($member['photo']): ?>
                                        <img src="uploads/<?php echo htmlspecialchars($member['photo']); ?>" 
                                             alt="<?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>" 
                                             class="w-24 h-24 rounded-full mx-auto object-cover mb-4">
                                    <?php else: ?>
                                        <div class="w-24 h-24 rounded-full mx-auto bg-gradient-to-r from-pink-500 to-rose-600 flex items-center justify-center mb-4">
                                            <span class="text-3xl font-bold text-white">
                                                <?php echo strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1)); ?>
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <h3 class="text-lg font-semibold text-gray-900 mb-1">
                                        <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                                    </h3>
                                    
                                    <?php if ($member['email']): ?>
                                        <p class="text-sm text-gray-500 mb-1">
                                            <i class="fas fa-envelope mr-1"></i>
                                            <?php echo htmlspecialchars($member['email']); ?>
                                        </p>
                                    <?php endif; ?>
                                    
                                    <?php if ($member['phone']): ?>
                                        <p class="text-sm text-gray-500">
                                            <i class="fas fa-phone mr-1"></i>
                                            <?php echo htmlspecialchars($member['phone']); ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="mt-8 text-center text-gray-600">
                        <p>Members: <?php echo count($householdMembers); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="mt-8">
                <h2 class="text-2xl font-bold text-gray-900 text-center mb-8">Our Church Households & Families</h2>
                <?php if (empty($households)): ?>
                    <div class="text-center py-12">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">No households found</h3>
                        <p class="mt-1 text-sm text-gray-500">Check back later.</p>
                    </div>
                <?php else: ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php foreach ($households as $household): ?>
                            <a href="?tab=households&household=<?php echo $household['id']; ?>" class="block bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 p-6">
                                <div class="flex items-start justify-between mb-4">
                                    <div class="w-12 h-12 bg-gradient-to-r from-pink-500 to-rose-600 rounded-lg flex items-center justify-center">
                                        <i class="fas fa-home text-white text-lg"></i>
                                    </div>
                                    <span class="px-2 py-1 text-xs rounded-full bg-pink-100 text-pink-600">
                                        <?php echo $householdMemberCounts[$household['id']]; ?> member<?php echo $householdMemberCounts[$household['id']] !== 1 ? 's' : ''; ?>
                                    </span>
                                </div>
                                
                                <h3 class="text-lg font-semibold text-gray-900 mb-3 hover:text-indigo-600">
                                    <?php echo htmlspecialchars($household['household_name']); ?>
                                    <i class="fas fa-chevron-right text-xs ml-1"></i>
                                </h3>
                                
                                <?php if ($household['address']): ?>
                                    <p class="text-sm text-gray-500 mb-2">
                                        <i class="fas fa-map-marker-alt mr-1"></i>
                                        <?php echo htmlspecialchars($household['address']); ?>
                                    </p>
                                <?php endif; ?>
                                
                                <?php if ($household['phone']): ?>
                                    <p class="text-sm text-gray-500 mb-2">
                                        <i class="fas fa-phone mr-1"></i>
                                        <?php echo htmlspecialchars($household['phone']); ?>
                                    </p>
                                <?php endif; ?>
                                
                                <?php if ($household['email']): ?>
                                    <p class="text-sm text-gray-500">
                                        <i class="fas fa-envelope mr-1"></i>
                                        <?php echo htmlspecialchars($household['email']); ?>
                                    </p>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="mt-8 text-center text-gray-600">
                        <p>Total Households: <?php echo count($households); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Small Groups Tab Content -->
    <?php if ($active_tab === 'small-groups'): ?>
        <?php if ($small_group_id && $currentGroup): ?>
            <!-- View specific small group members -->
            <div class="mt-8">
                <div class="flex items-center mb-6">
                    <a href="?tab=small-groups" class="text-indigo-600 hover:text-indigo-800 mr-2">
                        <i class="fas fa-arrow-left"></i> Back to Small Groups
                    </a>
                </div>
                <h2 class="text-2xl font-bold text-gray-900 text-center mb-2">
                    <?php echo htmlspecialchars($currentGroup['group_name']); ?>
                </h2>
                <p class="text-gray-600 text-center mb-8">Group Members</p>
                
                <?php if ($currentGroup['description'] || $currentGroup['location'] || $currentGroup['meeting_day']): ?>
                    <div class="bg-white rounded-lg shadow-md p-4 mb-6 max-w-2xl mx-auto">
                        <h3 class="font-semibold text-gray-700 mb-2">Group Details</h3>
                        <?php if ($currentGroup['description']): ?>
                            <p class="text-sm text-gray-600 mb-2"><?php echo htmlspecialchars($currentGroup['description']); ?></p>
                        <?php endif; ?>
                        <?php if ($currentGroup['meeting_day']): ?>
                            <p class="text-sm text-gray-600">
                                <i class="fas fa-calendar-day mr-2"></i>
                                <?php echo htmlspecialchars($currentGroup['meeting_day']); ?>
                                <?php if ($currentGroup['meeting_time']): ?>
                                    at <?php echo date('g:i A', strtotime($currentGroup['meeting_time'])); ?>
                                <?php endif; ?>
                            </p>
                        <?php endif; ?>
                        <?php if ($currentGroup['location']): ?>
                            <p class="text-sm text-gray-600">
                                <i class="fas fa-map-marker-alt mr-2"></i>
                                <?php echo htmlspecialchars($currentGroup['location']); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (empty($groupMembers)): ?>
                    <p class="text-center text-gray-500">No active members in this small group.</p>
                <?php else: ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        <?php foreach ($groupMembers as $member): ?>
                            <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 p-6">
                                <div class="text-center">
                                    <?php if ($member['photo']): ?>
                                        <img src="uploads/<?php echo htmlspecialchars($member['photo']); ?>" 
                                             alt="<?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>" 
                                             class="w-24 h-24 rounded-full mx-auto object-cover mb-4">
                                    <?php else: ?>
                                        <div class="w-24 h-24 rounded-full mx-auto bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center mb-4">
                                            <span class="text-3xl font-bold text-white">
                                                <?php echo strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1)); ?>
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <h3 class="text-lg font-semibold text-gray-900 mb-1">
                                        <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                                    </h3>
                                    
                                    <?php if ($member['email']): ?>
                                        <p class="text-sm text-gray-500 mb-1">
                                            <i class="fas fa-envelope mr-1"></i>
                                            <?php echo htmlspecialchars($member['email']); ?>
                                        </p>
                                    <?php endif; ?>
                                    
                                    <?php if ($member['phone']): ?>
                                        <p class="text-sm text-gray-500">
                                            <i class="fas fa-phone mr-1"></i>
                                            <?php echo htmlspecialchars($member['phone']); ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="mt-8 text-center text-gray-600">
                        <p>Members: <?php echo count($groupMembers); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="mt-8">
                <h2 class="text-2xl font-bold text-gray-900 text-center mb-8">Our Small Groups</h2>
                <?php if (empty($smallGroups)): ?>
                    <div class="text-center py-12">
                        <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-1.306-.835-2.418-2-2.83M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-1.306.835-2.418 2-2.83m0 0a3 3 0 000-5.356M9 12a3 3 0 000 5.356m0 0a3 3 0 000-5.356m0 0a3 3 0 000 5.356"></path>
                        </svg>
                        <h3 class="mt-2 text-sm font-medium text-gray-900">No small groups found</h3>
                        <p class="mt-1 text-sm text-gray-500">Check back later.</p>
                    </div>
                <?php else: ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <?php foreach ($smallGroups as $group): ?>
                            <a href="?tab=small-groups&small_group=<?php echo $group['id']; ?>" class="block bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 p-6">
                                <div class="flex items-start justify-between mb-4">
                                    <div class="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                                        <i class="fas fa-users-rectangle text-white text-lg"></i>
                                    </div>
                                    <span class="px-2 py-1 text-xs rounded-full <?php echo $group['is_active'] ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'; ?>">
                                        <?php echo $group['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </div>
                                
                                <h3 class="text-lg font-semibold text-gray-900 mb-3 hover:text-indigo-600">
                                    <?php echo htmlspecialchars($group['group_name']); ?>
                                    <i class="fas fa-chevron-right text-xs ml-1"></i>
                                </h3>
                                
                                <?php if ($group['description']): ?>
                                    <p class="text-sm text-gray-500 mb-3">
                                        <?php echo htmlspecialchars($group['description']); ?>
                                    </p>
                                <?php endif; ?>
                                
                                <?php if ($group['meeting_day']): ?>
                                    <p class="text-sm text-gray-600 mb-2">
                                        <i class="fas fa-calendar-day mr-1"></i>
                                        <?php echo htmlspecialchars($group['meeting_day']); ?>
                                        <?php if ($group['meeting_time']): ?>
                                            at <?php echo date('g:i A', strtotime($group['meeting_time'])); ?>
                                        <?php endif; ?>
                                    </p>
                                <?php endif; ?>
                                
                                <?php if ($group['location']): ?>
                                    <p class="text-sm text-gray-500 mb-3">
                                        <i class="fas fa-map-marker-alt mr-1"></i>
                                        <?php echo htmlspecialchars($group['location']); ?>
                                    </p>
                                <?php endif; ?>
                                
                                <div class="pt-3 border-t mt-3">
                                    <span class="text-sm text-gray-500">
                                        <i class="fas fa-user-friends mr-1"></i>
                                        <?php echo $groupMemberCounts[$group['id']]; ?> member<?php echo $groupMemberCounts[$group['id']] !== 1 ? 's' : ''; ?>
                                    </span>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="mt-8 text-center text-gray-600">
                        <p>Total Small Groups: <?php echo count($smallGroups); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php endif; ?>
    </div>

<?php include 'includes/footer.php'; ?>
