<?php
/**
 * Donation Class
 * Church Management System
 */

namespace App;

use PDO;
use PDOException;

class Donation {
    private $conn;
    private $table_name = "donations";
    private $columnCache = [];
    private $tableExistsCache = null;

    public function __construct($db) {
        $this->conn = $db;
    }

    private function tableExists() {
        if ($this->tableExistsCache !== null) {
            return $this->tableExistsCache;
        }

        try {
            $stmt = $this->conn->query("SHOW TABLES LIKE '{$this->table_name}'");
            $this->tableExistsCache = $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("Donation table check error: " . $e->getMessage());
            $this->tableExistsCache = false;
        }

        return $this->tableExistsCache;
    }

    private function hasColumn($column) {
        if (!$this->tableExists()) {
            $this->columnCache[$column] = false;
            return false;
        }

        if (array_key_exists($column, $this->columnCache)) {
            return $this->columnCache[$column];
        }

        try {
            $stmt = $this->conn->query("SHOW COLUMNS FROM {$this->table_name} LIKE '{$column}'");
            $this->columnCache[$column] = $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            error_log("Donation column check error: " . $e->getMessage());
            $this->columnCache[$column] = false;
        }

        return $this->columnCache[$column];
    }

    private function notesColumn() {
        if ($this->hasColumn('notes')) {
            return 'notes';
        }
        if ($this->hasColumn('note')) {
            return 'note';
        }
        return null;
    }

    private function donationDateColumn() {
        return $this->hasColumn('donation_date') ? 'donation_date' : 'created_at';
    }

    /**
     * Create a new donation record
     */
    public function create($data) {
        try {
            if (!$this->tableExists()) {
                error_log("Donation create error: table '{$this->table_name}' does not exist.");
                return ['success' => false, 'error' => 'Table does not exist'];
            }

            $insertData = [
                'donor_name' => $data['donor_name'] ?? '',
                'donor_email' => !empty($data['donor_email']) ? $data['donor_email'] : '',
                'donor_phone' => !empty($data['donor_phone']) ? $data['donor_phone'] : '',
                'amount' => $data['amount'] ?? 0,
                'payment_method' => $data['payment_method'] ?? 'cash',
                'donation_type' => $data['donation_type'] ?? 'offering',
                'payment_status' => $data['payment_status'] ?? 'completed',
                'transaction_id' => !empty($data['transaction_id']) ? $data['transaction_id'] : null,
            ];

            // Use the correct column name based on what exists in the table
            $notesColumn = $this->notesColumn();
            if ($notesColumn) {
                $insertData[$notesColumn] = $data['notes'] ?? ($data['note'] ?? null);
            }

            // Add optional columns if they exist
            if ($this->hasColumn('donation_purpose')) {
                $insertData['donation_purpose'] = $data['donation_purpose'] ?? null;
            }
            if ($this->hasColumn('is_anonymous')) {
                $insertData['is_anonymous'] = (int)($data['is_anonymous'] ?? 0);
            }
            if ($this->hasColumn('payment_reference')) {
                $insertData['payment_reference'] = $data['payment_reference'] ?? null;
            }
            if ($this->hasColumn('donation_date')) {
                $insertData['donation_date'] = $data['donation_date'] ?? date('Y-m-d');
            }

            $columns = array_keys($insertData);
            $placeholders = array_map(function ($column) {
                return ':' . $column;
            }, $columns);

            $query = "INSERT INTO {$this->table_name} (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";
            
            error_log("Donation insert query: " . $query);
            error_log("Donation insert data: " . print_r($insertData, true));
            
            $stmt = $this->conn->prepare($query);

            foreach ($insertData as $column => $value) {
                if ($column === 'amount') {
                    $stmt->bindValue(':' . $column, $value, PDO::PARAM_STR);
                } else {
                    $stmt->bindValue(':' . $column, $value);
                }
            }

            if ($stmt->execute()) {
                $lastId = $this->conn->lastInsertId();
                error_log("Donation created with ID: " . $lastId);
                return $lastId;
            }
            error_log("Donation execute returned false");
            return ['success' => false, 'error' => 'Execute failed'];
        } catch (PDOException $e) {
            error_log("Donation creation error: " . $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Get all donations with pagination
     */
    public function getAll($page = 1, $limit = 20, $filters = []) {
        if (!$this->tableExists()) {
            return [];
        }

        $offset = ($page - 1) * $limit;
        $dateColumn = $this->donationDateColumn();
        $hasPurpose = $this->hasColumn('donation_purpose');
        
        $query = "SELECT * FROM " . $this->table_name . " WHERE 1=1";
        $params = [];

        // Apply filters
        if (!empty($filters['date_from'])) {
            $query .= " AND DATE({$dateColumn}) >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $query .= " AND DATE({$dateColumn}) <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        if (!empty($filters['donation_type'])) {
            $query .= " AND donation_type = :donation_type";
            $params[':donation_type'] = $filters['donation_type'];
        }
        
        if (!empty($filters['payment_status'])) {
            $query .= " AND payment_status = :payment_status";
            $params[':payment_status'] = $filters['payment_status'];
        }

        if (!empty($filters['search'])) {
            $searchParts = ["donor_name LIKE :search", "donor_email LIKE :search"];
            if ($hasPurpose) {
                $searchParts[] = "donation_purpose LIKE :search";
            }
            $query .= " AND (" . implode(' OR ', $searchParts) . ")";
            $params[':search'] = '%' . $filters['search'] . '%';
        }

        $query .= " ORDER BY created_at DESC LIMIT :limit OFFSET :offset";

        try {
            $stmt = $this->conn->prepare($query);
            
            // Bind filter parameters
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            // Bind pagination parameters
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Get donations error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get donation by ID
     */
    public function getById($id) {
        if (!$this->tableExists()) {
            return false;
        }

        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Get donation by ID error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Update donation
     */
    public function update($id, $data) {
        try {
            if (!$this->tableExists()) {
                error_log("Donation update error: table '{$this->table_name}' does not exist.");
                return false;
            }

            $updateData = [
                'donor_name' => $data['donor_name'] ?? '',
                'donor_email' => $data['donor_email'] ?? null,
                'donor_phone' => $data['donor_phone'] ?? null,
                'amount' => $data['amount'] ?? 0,
                'payment_method' => $data['payment_method'] ?? 'cash',
                'donation_type' => $data['donation_type'] ?? 'offering',
                'payment_status' => $data['payment_status'] ?? 'pending',
                'transaction_id' => $data['transaction_id'] ?? null
            ];

            if ($this->hasColumn('donation_purpose')) {
                $updateData['donation_purpose'] = $data['donation_purpose'] ?? null;
            }

            if ($this->hasColumn('is_anonymous')) {
                $updateData['is_anonymous'] = (int)($data['is_anonymous'] ?? 0);
            }

            if ($this->hasColumn('payment_reference')) {
                $updateData['payment_reference'] = $data['payment_reference'] ?? null;
            }

            $notesColumn = $this->notesColumn();
            if ($notesColumn) {
                $updateData[$notesColumn] = $data['notes'] ?? ($data['note'] ?? null);
            }

            if ($this->hasColumn('donation_date')) {
                $updateData['donation_date'] = $data['donation_date'] ?? date('Y-m-d');
            }

            $setParts = [];
            foreach (array_keys($updateData) as $column) {
                $setParts[] = "{$column} = :{$column}";
            }

            $query = "UPDATE {$this->table_name} SET " . implode(', ', $setParts) . " WHERE id = :id";
            $stmt = $this->conn->prepare($query);

            $stmt->bindParam(':id', $id, PDO::PARAM_INT);

            foreach ($updateData as $column => $value) {
                $stmt->bindValue(':' . $column, $value);
            }

            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("Update donation error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete donation
     */
    public function delete($id) {
        if (!$this->tableExists()) {
            return false;
        }

        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        
        try {
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':id', $id, PDO::PARAM_INT);
            
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("Delete donation error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get total count for pagination
     */
    public function getTotalCount($filters = []) {
        if (!$this->tableExists()) {
            return 0;
        }

        $dateColumn = $this->donationDateColumn();
        $hasPurpose = $this->hasColumn('donation_purpose');
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE 1=1";
        $params = [];

        // Apply same filters as getAll method
        if (!empty($filters['date_from'])) {
            $query .= " AND DATE({$dateColumn}) >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $query .= " AND DATE({$dateColumn}) <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }
        
        if (!empty($filters['donation_type'])) {
            $query .= " AND donation_type = :donation_type";
            $params[':donation_type'] = $filters['donation_type'];
        }
        
        if (!empty($filters['payment_status'])) {
            $query .= " AND payment_status = :payment_status";
            $params[':payment_status'] = $filters['payment_status'];
        }

        if (!empty($filters['search'])) {
            $searchParts = ["donor_name LIKE :search", "donor_email LIKE :search"];
            if ($hasPurpose) {
                $searchParts[] = "donation_purpose LIKE :search";
            }
            $query .= " AND (" . implode(' OR ', $searchParts) . ")";
            $params[':search'] = '%' . $filters['search'] . '%';
        }

        try {
            $stmt = $this->conn->prepare($query);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            return $result['total'];
        } catch (PDOException $e) {
            error_log("Get total count error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Get donation statistics
     */
    public function getStats($filters = []) {
        if (!$this->tableExists()) {
            return [];
        }

        $dateColumn = $this->donationDateColumn();
        $query = "SELECT 
                    COUNT(*) as total_donations,
                    SUM(amount) as total_amount,
                    AVG(amount) as average_amount,
                    donation_type,
                    COUNT(*) as type_count
                  FROM " . $this->table_name . " 
                  WHERE payment_status = 'completed'";
        
        $params = [];

        if (!empty($filters['date_from'])) {
            $query .= " AND DATE({$dateColumn}) >= :date_from";
            $params[':date_from'] = $filters['date_from'];
        }
        
        if (!empty($filters['date_to'])) {
            $query .= " AND DATE({$dateColumn}) <= :date_to";
            $params[':date_to'] = $filters['date_to'];
        }

        $query .= " GROUP BY donation_type";

        try {
            $stmt = $this->conn->prepare($query);
            
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Get donation stats error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get recent donations
     */
    public function getRecent($limit = 10) {
        if (!$this->tableExists()) {
            return [];
        }

        $query = "SELECT * FROM " . $this->table_name . " 
                  ORDER BY created_at DESC 
                  LIMIT :limit";

        try {
            $stmt = $this->conn->prepare($query);
            $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            error_log("Get recent donations error: " . $e->getMessage());
            return [];
        }
    }
}
?>
