<?php
/**
 * LiveStream Class
 * Church Management System
 */

namespace App;

class LiveStream {
    private $conn;
    private $table_name = "live_streams";

    public $id;
    public $title;
    public $description;
    public $stream_url;
    public $stream_type;
    public $is_active;
    public $event_id;
    public $sermon_id;
    public $created_by;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Create new live stream
     */
    public function create() {
        $query = "INSERT INTO " . $this->table_name . "
                  (title, description, stream_url, stream_type, is_active, event_id, sermon_id, created_by)
                  VALUES (:title, :description, :stream_url, :stream_type, :is_active, :event_id, :sermon_id, :created_by)";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":stream_url", $this->stream_url);
        $stmt->bindParam(":stream_type", $this->stream_type);
        $stmt->bindParam(":is_active", $this->is_active);
        $stmt->bindParam(":event_id", $this->event_id);
        $stmt->bindParam(":sermon_id", $this->sermon_id);
        $stmt->bindParam(":created_by", $this->created_by);

        if($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    /**
     * Get live stream by ID
     */
    public function getById($id) {
        $query = "SELECT ls.*, u.first_name, u.last_name, e.title as event_title, s.title as sermon_title
                  FROM " . $this->table_name . " ls
                  LEFT JOIN users u ON ls.created_by = u.id
                  LEFT JOIN events e ON ls.event_id = e.id
                  LEFT JOIN sermons s ON ls.sermon_id = s.id
                  WHERE ls.id = :id";

        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            $this->id = $row['id'];
            $this->title = $row['title'];
            $this->description = $row['description'];
            $this->stream_url = $row['stream_url'];
            $this->stream_type = $row['stream_type'];
            $this->is_active = $row['is_active'];
            $this->event_id = $row['event_id'];
            $this->sermon_id = $row['sermon_id'];
            $this->created_by = $row['created_by'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return $row;
        }
        return false;
    }

    /**
     * Get all live streams with pagination and filters
     */
    public function getAll($page = 1, $limit = 10, $search = '', $isActive = null) {
        $offset = ($page - 1) * $limit;

        $query = "SELECT ls.*, u.first_name, u.last_name, e.title as event_title, s.title as sermon_title
                  FROM " . $this->table_name . " ls
                  LEFT JOIN users u ON ls.created_by = u.id
                  LEFT JOIN events e ON ls.event_id = e.id
                  LEFT JOIN sermons s ON ls.sermon_id = s.id
                  WHERE 1=1";

        $params = [];

        if(!empty($search)) {
            $query .= " AND (ls.title LIKE :search OR ls.description LIKE :search)";
            $params[':search'] = "%$search%";
        }

        if($isActive !== null) {
            $query .= " AND ls.is_active = :is_active";
            $params[':is_active'] = $isActive;
        }

        $query .= " ORDER BY ls.created_at DESC LIMIT :limit OFFSET :offset";

        $stmt = $this->conn->prepare($query);

        foreach($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }

        $stmt->bindParam(":limit", $limit, \PDO::PARAM_INT);
        $stmt->bindParam(":offset", $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Get total count of live streams
     */
    public function getTotalCount($search = '', $isActive = null) {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE 1=1";
        $params = [];

        if(!empty($search)) {
            $query .= " AND (title LIKE :search OR description LIKE :search)";
            $params[':search'] = "%$search%";
        }

        if($isActive !== null) {
            $query .= " AND is_active = :is_active";
            $params[':is_active'] = $isActive;
        }

        $stmt = $this->conn->prepare($query);

        foreach($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }

        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row['total'];
    }

    /**
     * Update live stream
     */
    public function update() {
        $query = "UPDATE " . $this->table_name . "
                  SET title = :title, description = :description, stream_url = :stream_url,
                      stream_type = :stream_type, is_active = :is_active, event_id = :event_id, sermon_id = :sermon_id
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":stream_url", $this->stream_url);
        $stmt->bindParam(":stream_type", $this->stream_type);
        $stmt->bindParam(":is_active", $this->is_active);
        $stmt->bindParam(":event_id", $this->event_id);
        $stmt->bindParam(":sermon_id", $this->sermon_id);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Delete live stream
     */
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Get active live streams
     */
    public function getActive() {
        $query = "SELECT ls.*, e.title as event_title, s.title as sermon_title
                  FROM " . $this->table_name . " ls
                  LEFT JOIN events e ON ls.event_id = e.id
                  LEFT JOIN sermons s ON ls.sermon_id = s.id
                  WHERE ls.is_active = 1
                  ORDER BY ls.created_at DESC";

        $stmt = $this->conn->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Get live streams statistics
     */
    public function getStatistics() {
        $stats = [];

        // Total live streams
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['total'] = $stmt->fetch(\PDO::FETCH_ASSOC)['total'];

        // Active live streams
        $query = "SELECT COUNT(*) as active FROM " . $this->table_name . " WHERE is_active = 1";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['active'] = $stmt->fetch(\PDO::FETCH_ASSOC)['active'];

        // Live streams by type
        $query = "SELECT stream_type, COUNT(*) as count FROM " . $this->table_name . " GROUP BY stream_type";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['by_type'] = $stmt->fetchAll(\PDO::FETCH_ASSOC);

        return $stats;
    }
}
?>