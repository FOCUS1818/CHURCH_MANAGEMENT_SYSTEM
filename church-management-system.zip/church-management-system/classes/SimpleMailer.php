<?php
/**
 * Simple SMTP Mailer Class
 * Church Management System
 * 
 * A lightweight SMTP mailer that doesn't require external dependencies
 */

namespace App;

class SimpleMailer {
    private $host;
    private $port;
    private $username;
    private $password;
    private $fromEmail;
    private $fromName;
    private $error;
    
    public function __construct($config = []) {
        $this->host = $config['host'] ?? 'smtp.gmail.com';
        $this->port = $config['port'] ?? 587;
        $this->username = $config['username'] ?? '';
        $this->password = $config['password'] ?? '';
        $this->fromEmail = $config['from_email'] ?? '';
        $this->fromName = $config['from_name'] ?? '';
    }
    
    /**
     * Send an email via SMTP
     */
    public function send($to, $subject, $body, $isHTML = true) {
        try {
            $socket = $this->connect();
            if (!$socket) {
                return false;
            }
            
            $this->authenticate($socket);
            $this->sendMail($socket, $to, $subject, $body, $isHTML);
            $this->disconnect($socket);
            
            return true;
        } catch (\Exception $e) {
            $this->error = $e->getMessage();
            error_log("SimpleMailer error: " . $this->error);
            return false;
        }
    }
    
    /**
     * Get last error message
     */
    public function getError() {
        return $this->error;
    }
    
    /**
     * Connect to SMTP server
     */
    private function connect() {
        // Use ssl:// for port 465, no prefix for port 587 (STARTTLS)
        $host = $this->host;
        
        error_log("Connecting to: $host on port " . $this->port);
        
        $socket = fsockopen($host, $this->port, $errno, $errstr, 30);
        if (!$socket) {
            throw new \Exception("Connection failed: $errstr ($errno)");
        }
        
        stream_set_timeout($socket, 30);
        
        // Read greeting
        $response = $this->getResponse($socket);
        error_log("Server greeting: $response");
        
        if (strpos($response, '220') === false) {
            throw new \Exception("Invalid server greeting: $response");
        }
        
        // Send EHLO
        $this->sendCommand($socket, "EHLO " . $this->host);
        $response = $this->getResponse($socket);
        error_log("EHLO response: $response");
        
        return $socket;
    }
    
    /**
     * Authenticate with SMTP server
     */
    private function authenticate($socket) {
        // For port 587, use STARTTLS
        if ($this->port == 587) {
            $this->sendCommand($socket, "STARTTLS");
            $response = $this->getResponse($socket);
            error_log("STARTTLS response: $response");
            
            if (strpos($response, '220') === false) {
                throw new \Exception("STARTTLS not supported: $response");
            }
            
            // Enable TLS - try TLS 1.2 first
            $cryptoMethods = [
                STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT,
                STREAM_CRYPTO_METHOD_TLS_CLIENT,
                STREAM_CRYPTO_METHOD_TLSv1_1_CLIENT
            ];
            
            $cryptoEnabled = false;
            foreach ($cryptoMethods as $method) {
                $result = stream_socket_enable_crypto($socket, true, $method);
                if ($result === true) {
                    $cryptoEnabled = true;
                    error_log("TLS enabled with method: $method");
                    break;
                }
            }
            
            if (!$cryptoEnabled) {
                throw new \Exception("Failed to enable TLS encryption");
            }
            
            // Re-send EHLO after TLS
            $this->sendCommand($socket, "EHLO " . $this->host);
            $response = $this->getResponse($socket);
            error_log("EHLO after TLS: $response");
        }
        
        // Authenticate
        $this->sendCommand($socket, "AUTH LOGIN");
        $response = $this->getResponse($socket);
        error_log("AUTH LOGIN response: $response");
        
        $this->sendCommand($socket, base64_encode($this->username));
        $response = $this->getResponse($socket);
        error_log("Username response: $response");
        
        $this->sendCommand($socket, base64_encode($this->password));
        $response = $this->getResponse($socket);
        error_log("Password response: $response");
        
        if (strpos($response, '235') === false && strpos($response, '2.7.0') === false) {
            throw new \Exception("Authentication failed: $response");
        }
    }
    
    /**
     * Send the actual email
     */
    private function sendMail($socket, $to, $subject, $body, $isHTML) {
        // Set sender
        $this->sendCommand($socket, "MAIL FROM: <" . $this->fromEmail . ">");
        $response = $this->getResponse($socket);
        
        // Set recipient
        $this->sendCommand($socket, "RCPT TO: <" . $to . ">");
        $response = $this->getResponse($socket);
        
        // Start data
        $this->sendCommand($socket, "DATA");
        $response = $this->getResponse($socket);
        
        // Build headers
        $headers = "From: " . $this->fromName . " <" . $this->fromEmail . ">\r\n";
        $headers .= "To: " . $to . "\r\n";
        $headers .= "Reply-To: " . $this->fromEmail . "\r\n";
        $headers .= "Message-ID: <" . time() . "." . md5($to) . "@" . $this->host . ">\r\n";
        $headers .= "Date: " . date('r') . "\r\n";
        
        if ($isHTML) {
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
            $headers .= "Content-Transfer-Encoding: 8bit\r\n";
        }
        
        // Send email
        fputs($socket, $headers . "\r\n");
        fputs($socket, $body . "\r\n");
        fputs($socket, ".\r\n");
        
        $response = $this->getResponse($socket);
        
        if (strpos($response, '250') === false && strpos($response, 'OK') === false) {
            throw new \Exception("Email rejected: $response");
        }
    }
    
    /**
     * Disconnect from SMTP server
     */
    private function disconnect($socket) {
        $this->sendCommand($socket, "QUIT");
        fclose($socket);
    }
    
    /**
     * Send SMTP command
     */
    private function sendCommand($socket, $command) {
        fputs($socket, $command . "\r\n");
    }
    
    /**
     * Get SMTP response - handles multi-line responses
     */
    private function getResponse($socket) {
        $response = '';
        $timeout = time() + 10;
        
        while (time() < $timeout) {
            $line = fgets($socket, 512);
            if ($line === false) {
                usleep(100000); // 100ms delay
                continue;
            }
            
            $response .= trim($line);
            
            // Check if this is the last line (no hyphen after status code)
            if (strlen($line) >= 4 && $line[3] !== '-') {
                break;
            }
        }
        
        return $response;
    }
}
