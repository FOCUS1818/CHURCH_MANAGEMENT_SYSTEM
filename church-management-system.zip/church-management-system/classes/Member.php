<?php
/**
 * Member Class
 * Church Management System
 */

namespace App;

class Member {
    private $conn;
    private $table_name = "members";

    public $id;
    public $household_id;
    public $small_group_id;
    public $first_name;
    public $last_name;
    public $middle_name;
    public $gender;
    public $date_of_birth;
    public $marital_status;
    public $phone;
    public $email;
    public $address;
    public $photo;
    public $family_role;
    public $membership_status;
    public $membership_class_completed;
    public $baptism_date;
    public $spiritual_gifts;
    public $notes;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Create new member
     */
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (household_id, small_group_id, first_name, last_name, middle_name, gender, date_of_birth, 
                   marital_status, phone, email, address, photo, family_role, membership_status, 
                   membership_class_completed, baptism_date, spiritual_gifts, notes) 
                  VALUES (:household_id, :small_group_id, :first_name, :last_name, :middle_name, :gender, :date_of_birth, 
                          :marital_status, :phone, :email, :address, :photo, :family_role, :membership_status, 
                          :membership_class_completed, :baptism_date, :spiritual_gifts, :notes)";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":household_id", $this->household_id);
        $stmt->bindParam(":small_group_id", $this->small_group_id);
        $stmt->bindParam(":first_name", $this->first_name);
        $stmt->bindParam(":last_name", $this->last_name);
        $stmt->bindParam(":middle_name", $this->middle_name);
        $stmt->bindParam(":gender", $this->gender);
        $stmt->bindParam(":date_of_birth", $this->date_of_birth);
        $stmt->bindParam(":marital_status", $this->marital_status);
        $stmt->bindParam(":phone", $this->phone);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":photo", $this->photo);
        $stmt->bindParam(":family_role", $this->family_role);
        $stmt->bindParam(":membership_status", $this->membership_status);
        $stmt->bindParam(":membership_class_completed", $this->membership_class_completed);
        $stmt->bindParam(":baptism_date", $this->baptism_date);
        $stmt->bindParam(":spiritual_gifts", $this->spiritual_gifts);
        $stmt->bindParam(":notes", $this->notes);

        if($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    /**
     * Get member by ID
     */
    public function getById($id) {
        $query = "SELECT m.*, h.household_name, h.address as household_address, h.phone as household_phone, h.email as household_email 
                  FROM " . $this->table_name . " m 
                  LEFT JOIN households h ON m.household_id = h.id 
                  WHERE m.id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            $this->id = $row['id'];
            $this->household_id = $row['household_id'];
            $this->small_group_id = $row['small_group_id'];
            $this->first_name = $row['first_name'];
            $this->last_name = $row['last_name'];
            $this->middle_name = $row['middle_name'];
            $this->gender = $row['gender'];
            $this->date_of_birth = $row['date_of_birth'];
            $this->marital_status = $row['marital_status'];
            $this->phone = $row['phone'];
            $this->email = $row['email'];
            $this->address = $row['address'];
            $this->photo = $row['photo'];
            $this->family_role = $row['family_role'];
            $this->membership_status = $row['membership_status'];
            $this->membership_class_completed = $row['membership_class_completed'];
            $this->baptism_date = $row['baptism_date'];
            $this->spiritual_gifts = $row['spiritual_gifts'];
            $this->notes = $row['notes'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        return false;
    }

    /**
     * Get all members with pagination and search
     */
    public function getAll($page = 1, $limit = 10, $search = '', $status = '') {
        $offset = ($page - 1) * $limit;
        
        $query = "SELECT m.*, h.household_name 
                  FROM " . $this->table_name . " m 
                  LEFT JOIN households h ON m.household_id = h.id 
                  WHERE 1=1";
        
        $params = [];
        
        if(!empty($search)) {
            $query .= " AND (m.first_name LIKE :search OR m.last_name LIKE :search OR m.email LIKE :search)";
            $params[':search'] = "%$search%";
        }
        
        if(!empty($status)) {
            $query .= " AND m.membership_status = :status";
            $params[':status'] = $status;
        }
        
        $query .= " ORDER BY m.last_name, m.first_name LIMIT :limit OFFSET :offset";
        
        $stmt = $this->conn->prepare($query);
        
        foreach($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->bindParam(":limit", $limit, \PDO::PARAM_INT);
        $stmt->bindParam(":offset", $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Get total count of members
     */
    public function getTotalCount($search = '', $status = '') {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE 1=1";
        $params = [];
        
        if(!empty($search)) {
            $query .= " AND (first_name LIKE :search OR last_name LIKE :search OR email LIKE :search)";
            $params[':search'] = "%$search%";
        }
        
        if(!empty($status)) {
            $query .= " AND membership_status = :status";
            $params[':status'] = $status;
        }
        
        $stmt = $this->conn->prepare($query);
        
        foreach($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row['total'];
    }

    /**
     * Update member
     */
    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                  SET household_id = :household_id, small_group_id = :small_group_id, first_name = :first_name, last_name = :last_name, 
                      middle_name = :middle_name, gender = :gender, date_of_birth = :date_of_birth, 
                      marital_status = :marital_status, phone = :phone, email = :email, address = :address, 
                      photo = :photo, family_role = :family_role, membership_status = :membership_status, 
                      membership_class_completed = :membership_class_completed, baptism_date = :baptism_date, 
                      spiritual_gifts = :spiritual_gifts, notes = :notes 
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":household_id", $this->household_id);
        $stmt->bindParam(":small_group_id", $this->small_group_id);
        $stmt->bindParam(":first_name", $this->first_name);
        $stmt->bindParam(":last_name", $this->last_name);
        $stmt->bindParam(":middle_name", $this->middle_name);
        $stmt->bindParam(":gender", $this->gender);
        $stmt->bindParam(":date_of_birth", $this->date_of_birth);
        $stmt->bindParam(":marital_status", $this->marital_status);
        $stmt->bindParam(":phone", $this->phone);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":address", $this->address);
        $stmt->bindParam(":photo", $this->photo);
        $stmt->bindParam(":family_role", $this->family_role);
        $stmt->bindParam(":membership_status", $this->membership_status);
        $stmt->bindParam(":membership_class_completed", $this->membership_class_completed);
        $stmt->bindParam(":baptism_date", $this->baptism_date);
        $stmt->bindParam(":spiritual_gifts", $this->spiritual_gifts);
        $stmt->bindParam(":notes", $this->notes);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Delete member
     */
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Get members by household
     */
    public function getByHousehold($householdId) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE household_id = :household_id ORDER BY family_role, first_name";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":household_id", $householdId);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Get member statistics
     */
    public function getStatistics() {
        $stats = [];
        
        // Total members
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['total'] = $stmt->fetch(\PDO::FETCH_ASSOC)['total'];
        
        // Active members
        $query = "SELECT COUNT(*) as active FROM " . $this->table_name . " WHERE membership_status = 'active'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['active'] = $stmt->fetch(\PDO::FETCH_ASSOC)['active'];
        
        // New members this month
        $query = "SELECT COUNT(*) as new_this_month FROM " . $this->table_name . " WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['new_this_month'] = $stmt->fetch(\PDO::FETCH_ASSOC)['new_this_month'];
        
        // Members by gender
        $query = "SELECT gender, COUNT(*) as count FROM " . $this->table_name . " GROUP BY gender";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['by_gender'] = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        // Members by status
        $query = "SELECT membership_status, COUNT(*) as count FROM " . $this->table_name . " GROUP BY membership_status";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['by_status'] = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        return $stats;
    }

    /**
     * Get upcoming birthdays
     */
    public function getUpcomingBirthdays($days = 30) {
        $query = "SELECT *, 
                  CASE 
                    WHEN MONTH(date_of_birth) = MONTH(CURRENT_DATE()) AND DAY(date_of_birth) >= DAY(CURRENT_DATE()) 
                    THEN DATEDIFF(DATE_ADD(CURRENT_DATE(), INTERVAL YEAR(CURRENT_DATE()) - YEAR(date_of_birth) YEAR), CURRENT_DATE())
                    WHEN MONTH(date_of_birth) > MONTH(CURRENT_DATE()) 
                    THEN DATEDIFF(DATE_ADD(CURRENT_DATE(), INTERVAL YEAR(CURRENT_DATE()) - YEAR(date_of_birth) + 1 YEAR), CURRENT_DATE())
                    ELSE DATEDIFF(DATE_ADD(CURRENT_DATE(), INTERVAL YEAR(CURRENT_DATE()) - YEAR(date_of_birth) + 1 YEAR), CURRENT_DATE())
                  END as days_until_birthday
                  FROM " . $this->table_name . " 
                  WHERE date_of_birth IS NOT NULL 
                  AND date_of_birth <= CURDATE()
                  AND YEAR(date_of_birth) <= YEAR(CURDATE())
                  HAVING days_until_birthday <= :days 
                  ORDER BY days_until_birthday";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":days", $days, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Save member small groups (multiple)
     */
    public function saveSmallGroups($member_id, $small_group_ids) {
        // Delete existing small group associations
        $this->deleteSmallGroups($member_id);
        
        // Insert new small group associations
        if (!empty($small_group_ids)) {
            $query = "INSERT INTO member_small_groups (member_id, small_group_id) VALUES (:member_id, :small_group_id)";
            $stmt = $this->conn->prepare($query);
            
            foreach ($small_group_ids as $small_group_id) {
                $stmt->bindParam(':member_id', $member_id);
                $stmt->bindParam(':small_group_id', $small_group_id);
                $stmt->execute();
            }
        }
        return true;
    }

    /**
     * Delete member small groups
     */
    public function deleteSmallGroups($member_id) {
        $query = "DELETE FROM member_small_groups WHERE member_id = :member_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $member_id);
        return $stmt->execute();
    }

    /**
     * Get member small groups
     */
    public function getSmallGroups($member_id) {
        $query = "SELECT sg.id, sg.group_name 
                  FROM small_groups sg 
                  INNER JOIN member_small_groups msg ON sg.id = msg.small_group_id 
                  WHERE msg.member_id = :member_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $member_id);
        $stmt->execute();
        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Get member small group IDs
     */
    public function getSmallGroupIds($member_id) {
        $query = "SELECT small_group_id FROM member_small_groups WHERE member_id = :member_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':member_id', $member_id);
        $stmt->execute();
        $results = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        return array_column($results, 'small_group_id');
    }
}
?>
