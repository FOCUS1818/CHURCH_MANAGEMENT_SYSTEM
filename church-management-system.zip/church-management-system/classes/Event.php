<?php
/**
 * Event Class
 * Church Management System
 */

namespace App;

class Event {
    private $conn;
    private $table_name = "events";

    public $id;
    public $title;
    public $description;
    public $event_type;
    public $start_datetime;
    public $end_datetime;
    public $location;
    public $max_capacity;
    public $requires_rsvp;
    public $rsvp_deadline;
    public $flyer_image;
    public $created_by;
    public $created_at;
    public $updated_at;
    public $live_stream_url;
    public $is_live;
    public $is_featured;

    public function __construct($db) {
        $this->conn = $db;
    }

    /**
     * Check if a column exists on events table
     */
    private function hasColumn($columnName) {
        $query = "SHOW COLUMNS FROM " . $this->table_name . " LIKE :column_name";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":column_name", $columnName);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }

    /**
     * Create new event
     */
    public function create() {
        $columns = [
            'title', 'description', 'event_type', 'start_datetime', 'end_datetime', 'location',
            'max_capacity', 'requires_rsvp', 'rsvp_deadline', 'flyer_image', 'created_by'
        ];

        if ($this->hasColumn('live_stream_url')) {
            $columns[] = 'live_stream_url';
        }

        if ($this->hasColumn('is_live')) {
            $columns[] = 'is_live';
        }

        if ($this->hasColumn('is_featured')) {
            $columns[] = 'is_featured';
        }

        $placeholders = array_map(function($column) {
            return ':' . $column;
        }, $columns);

        $query = "INSERT INTO " . $this->table_name . " (" . implode(', ', $columns) . ") VALUES (" . implode(', ', $placeholders) . ")";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":event_type", $this->event_type);
        $stmt->bindParam(":start_datetime", $this->start_datetime);
        $stmt->bindParam(":end_datetime", $this->end_datetime);
        $stmt->bindParam(":location", $this->location);
        $stmt->bindParam(":max_capacity", $this->max_capacity);
        $stmt->bindParam(":requires_rsvp", $this->requires_rsvp);
        $stmt->bindParam(":rsvp_deadline", $this->rsvp_deadline);
        $stmt->bindParam(":flyer_image", $this->flyer_image);
        $stmt->bindParam(":created_by", $this->created_by);

        if ($this->hasColumn('live_stream_url')) {
            $stmt->bindParam(":live_stream_url", $this->live_stream_url);
        }

        if ($this->hasColumn('is_live')) {
            $stmt->bindParam(":is_live", $this->is_live);
        }

        if ($this->hasColumn('is_featured')) {
            $stmt->bindParam(":is_featured", $this->is_featured);
        }

        if($stmt->execute()) {
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    /**
     * Get event by ID
     */
    public function getById($id) {
        $query = "SELECT e.*, u.first_name, u.last_name 
                  FROM " . $this->table_name . " e 
                  LEFT JOIN users u ON e.created_by = u.id 
                  WHERE e.id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();

        if($stmt->rowCount() > 0) {
            $row = $stmt->fetch(\PDO::FETCH_ASSOC);
            $this->id = $row['id'];
            $this->title = $row['title'];
            $this->description = $row['description'];
            $this->event_type = $row['event_type'];
            $this->start_datetime = $row['start_datetime'];
            $this->end_datetime = $row['end_datetime'];
            $this->location = $row['location'];
            $this->max_capacity = $row['max_capacity'];
            $this->requires_rsvp = $row['requires_rsvp'];
            $this->rsvp_deadline = $row['rsvp_deadline'];
            $this->flyer_image = $row['flyer_image'];
            $this->created_by = $row['created_by'];
            $this->created_at = $row['created_at'];
            $this->updated_at = $row['updated_at'];
            return true;
        }
        return false;
    }

    /**
     * Get all events with pagination and filters
     */
    public function getAll($page = 1, $limit = 10, $search = '', $eventType = '', $dateFrom = '', $dateTo = '') {
        $offset = ($page - 1) * $limit;
        
        $query = "SELECT e.*, u.first_name, u.last_name 
                  FROM " . $this->table_name . " e 
                  LEFT JOIN users u ON e.created_by = u.id 
                  WHERE 1=1";
        
        $params = [];
        
        if(!empty($search)) {
            $query .= " AND (e.title LIKE :search OR e.description LIKE :search)";
            $params[':search'] = "%$search%";
        }
        
        if(!empty($eventType)) {
            $query .= " AND e.event_type = :event_type";
            $params[':event_type'] = $eventType;
        }
        
        if(!empty($dateFrom)) {
            $query .= " AND e.start_datetime >= :date_from";
            $params[':date_from'] = $dateFrom;
        }
        
        if(!empty($dateTo)) {
            $query .= " AND e.start_datetime <= :date_to";
            $params[':date_to'] = $dateTo;
        }
        
        $query .= " ORDER BY e.start_datetime DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->conn->prepare($query);
        
        foreach($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->bindParam(":limit", $limit, \PDO::PARAM_INT);
        $stmt->bindParam(":offset", $offset, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Get total count of events
     */
    public function getTotalCount($search = '', $eventType = '', $dateFrom = '', $dateTo = '') {
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name . " WHERE 1=1";
        $params = [];
        
        if(!empty($search)) {
            $query .= " AND (title LIKE :search OR description LIKE :search)";
            $params[':search'] = "%$search%";
        }
        
        if(!empty($eventType)) {
            $query .= " AND event_type = :event_type";
            $params[':event_type'] = $eventType;
        }
        
        if(!empty($dateFrom)) {
            $query .= " AND start_datetime >= :date_from";
            $params[':date_from'] = $dateFrom;
        }
        
        if(!empty($dateTo)) {
            $query .= " AND start_datetime <= :date_to";
            $params[':date_to'] = $dateTo;
        }
        
        $stmt = $this->conn->prepare($query);
        
        foreach($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->execute();
        $row = $stmt->fetch(\PDO::FETCH_ASSOC);
        return $row['total'];
    }

    /**
     * Update event
     */
    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                  SET title = :title, description = :description, event_type = :event_type, 
                      start_datetime = :start_datetime, end_datetime = :end_datetime, location = :location, 
                      max_capacity = :max_capacity, requires_rsvp = :requires_rsvp, rsvp_deadline = :rsvp_deadline, 
                      flyer_image = :flyer_image 
                  WHERE id = :id";

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":title", $this->title);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":event_type", $this->event_type);
        $stmt->bindParam(":start_datetime", $this->start_datetime);
        $stmt->bindParam(":end_datetime", $this->end_datetime);
        $stmt->bindParam(":location", $this->location);
        $stmt->bindParam(":max_capacity", $this->max_capacity);
        $stmt->bindParam(":requires_rsvp", $this->requires_rsvp);
        $stmt->bindParam(":rsvp_deadline", $this->rsvp_deadline);
        $stmt->bindParam(":flyer_image", $this->flyer_image);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Delete event
     */
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);

        if($stmt->execute()) {
            return true;
        }
        return false;
    }

    /**
     * Get upcoming events
     */
    public function getUpcoming($limit = 10) {
        $query = "SELECT * FROM " . $this->table_name . " 
                  WHERE start_datetime > NOW() 
                  ORDER BY start_datetime ASC 
                  LIMIT :limit";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":limit", $limit, \PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll(\PDO::FETCH_ASSOC);
    }

    /**
     * Get event statistics
     */
    public function getStatistics() {
        $stats = [];
        
        // Total events
        $query = "SELECT COUNT(*) as total FROM " . $this->table_name;
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['total'] = $stmt->fetch(\PDO::FETCH_ASSOC)['total'];
        
        // Upcoming events
        $query = "SELECT COUNT(*) as upcoming FROM " . $this->table_name . " WHERE start_datetime > NOW()";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['upcoming'] = $stmt->fetch(\PDO::FETCH_ASSOC)['upcoming'];
        
        // Events this month
        $query = "SELECT COUNT(*) as this_month FROM " . $this->table_name . " 
                  WHERE MONTH(start_datetime) = MONTH(CURRENT_DATE()) AND YEAR(start_datetime) = YEAR(CURRENT_DATE())";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['this_month'] = $stmt->fetch(\PDO::FETCH_ASSOC)['this_month'];
        
        // Events by type
        $query = "SELECT event_type, COUNT(*) as count FROM " . $this->table_name . " GROUP BY event_type";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $stats['by_type'] = $stmt->fetchAll(\PDO::FETCH_ASSOC);
        
        return $stats;
    }
}
?>
