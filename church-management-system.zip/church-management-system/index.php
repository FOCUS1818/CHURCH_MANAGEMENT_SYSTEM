<?php
require_once 'config/config.php';
require_once 'classes/Member.php';

use App\Database;
use App\Member;

$database = new Database();
$db = $database->getConnection();

// Get all active weekly verses
$stmt = $db->prepare("SELECT verse_text, reference FROM weekly_verses WHERE is_active = 1 ORDER BY week_start DESC");
$stmt->execute();
$weeklyVerses = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get upcoming events
$stmt = $db->prepare("SELECT * FROM events WHERE start_datetime > NOW() ORDER BY start_datetime ASC LIMIT 3");
$stmt->execute();
$upcomingEvents = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get recent sermons
$stmt = $db->prepare("SELECT * FROM sermons ORDER BY sermon_date DESC LIMIT 3");
$stmt->execute();
$recentSermons = $stmt->fetchAll(PDO::FETCH_ASSOC);

$pageTitle = "Welcome to Our Church";
include 'includes/header.php';
include 'includes/navigation.php';
?>
    <!-- Hero Section -->
    <section id="home" class="relative min-h-screen flex items-center justify-center overflow-hidden">
        <!-- Background with gradient and pattern -->
        <div class="absolute inset-0 bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900"></div>
        <div class="absolute inset-0 bg-black opacity-40"></div>
        
        <!-- Animated background elements -->
        <div class="absolute inset-0 overflow-hidden">
            <div class="absolute -top-40 -right-40 w-80 h-80 bg-white opacity-10 rounded-full blur-3xl animate-pulse"></div>
            <div class="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 opacity-10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        
        <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
            <div class="animate-fade-in">
                <h1 class="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
                    Welcome to <span class="bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">OLEBU SDA CHURCH</span>
                </h1>
                <p class="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto leading-relaxed">
                    Growing in faith, serving in love, building community together
                </p>
                
                <!-- Weekly Verse -->
                <?php if (!empty($weeklyVerses)): ?>
                <div class="glass-effect rounded-2xl p-8 mb-12 max-w-4xl mx-auto animate-slide-in">
                    <div class="flex items-center justify-center mb-4">
                        <i class="fas fa-quote-left text-yellow-400 text-2xl mr-3"></i>
                        <h3 class="text-lg font-semibold text-yellow-400">Weekly Verse</h3>
                    </div>
                    <div id="verse-container">
                        <blockquote class="text-lg md:text-xl text-white italic mb-4 leading-relaxed transition-opacity duration-500">
                            "<?php echo htmlspecialchars($weeklyVerses[0]['verse_text']); ?>"
                        </blockquote>
                        <cite class="text-sm text-gray-300 font-medium">- <?php echo htmlspecialchars($weeklyVerses[0]['reference']); ?></cite>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="flex flex-col sm:flex-row gap-6 justify-center animate-bounce-in">
                    <a href="#plan-visit" class="group bg-white text-indigo-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-all duration-300 shadow-2xl hover:shadow-3xl hover-lift">
                        <i class="fas fa-calendar-check mr-2"></i>
                        Plan Your Visit
                    </a>
                    <a href="sermons.php" class="group border-2 border-white text-white px-8 py-4 rounded-xl font-semibold hover:bg-white hover:text-indigo-600 transition-all duration-300 shadow-2xl hover:shadow-3xl hover-lift">
                        <i class="fas fa-play mr-2"></i>
                        Watch Sermons
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Scroll indicator -->
        <div class="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <i class="fas fa-chevron-down text-white text-2xl"></i>
        </div>
    </section>

    <!-- Service Times -->
    <section class="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16 fade-on-scroll">
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Service Times</h2>
                <p class="text-xl text-gray-600 max-w-2xl mx-auto">Join us for worship and fellowship in our beautiful sanctuary</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div class="group text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 hover-lift fade-on-scroll">
                    <div class="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                        <i class="fas fa-sun text-white text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-3">Saturday</h3>
                    <p class="text-3xl font-bold text-indigo-600 mb-3">7:00 AM-01:30 PM</p>
                    <p class="text-gray-600 text-lg">Main Service</p>
                    <div class="mt-4 text-sm text-gray-500">
                        <i class="fas fa-clock mr-1"></i>
                        Duration: 6.5 hours
                    </div>
                </div>
                <div class="group text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 hover-lift fade-on-scroll">
                    <div class="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                        <i class="fas fa-moon text-white text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-3">Sunday</h3>
                    <p class="text-3xl font-bold text-indigo-600 mb-3">7:00 PM</p>
                    <p class="text-gray-600 text-lg">Bible Studies</p>
                    <div class="mt-4 text-sm text-gray-500">
                        <i class="fas fa-clock mr-1"></i>
                        Duration: 1.5 hours
                    </div>
                </div>
                <div class="group text-center p-8 bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 hover-lift fade-on-scroll">
                    <div class="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                        <i class="fas fa-book text-white text-2xl"></i>
                    </div>
                    <h3 class="text-2xl font-bold text-gray-900 mb-3">Wednesday</h3>
                    <p class="text-3xl font-bold text-indigo-600 mb-3">7:00 PM</p>
                    <p class="text-gray-600 text-lg">Midweek Prayers</p>
                    <div class="mt-4 text-sm text-gray-500">
                        <i class="fas fa-clock mr-1"></i>
                        Duration: 1 hour
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                <div class="fade-on-scroll">
                    <div class="mb-8">
                        <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">About Our Church</h2>
                        <div class="w-20 h-1 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-full"></div>
                    </div>
                    <p class="text-xl text-gray-600 mb-8 leading-relaxed">
                        Olebu SDA Church has been serving our community for over 10 years. 
                        We are committed to sharing the love of Christ through worship, fellowship, 
                        and service to others.
                    </p>
                    <div class="space-y-8">
                        <div class="flex items-start space-x-4">
                            <div class="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center flex-shrink-0">
                                <i class="fas fa-bullseye text-white text-xl"></i>
                            </div>
                            <div>
                                <h3 class="text-2xl font-bold text-gray-900 mb-3">Our Mission</h3>
                                <p class="text-gray-600 text-lg">To make disciples of Jesus Christ who love God, love others, and serve the world.</p>
                            </div>
                        </div>
                        <div class="flex items-start space-x-4">
                            <div class="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg flex items-center justify-center flex-shrink-0">
                                <i class="fas fa-eye text-white text-xl"></i>
                            </div>
                            <div>
                                <h3 class="text-2xl font-bold text-gray-900 mb-3">Our Vision</h3>
                                <p class="text-gray-600 text-lg">To be a vibrant, growing community of believers who transform lives through the power of the Gospel.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="fade-on-scroll">
                    <div class="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-3xl p-10 text-white shadow-2xl">
                        <div class="text-center mb-8">
                            <div class="w-16 h-16 bg-white bg-opacity-20 rounded-full flex items-center justify-center mx-auto mb-4">
                                <i class="fas fa-cross text-3xl"></i>
                            </div>
                            <h3 class="text-3xl font-bold mb-2">Statement of Faith</h3>
                            <p class="text-indigo-100">What we believe</p>
                        </div>
                        <ul class="space-y-6">
                            <li class="flex items-start space-x-4">
                                <div class="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                                    <i class="fas fa-check text-sm"></i>
                                </div>
                                <span class="text-lg">We believe in the Trinity: Father, Son, and Holy Spirit</span>
                            </li>
                            <li class="flex items-start space-x-4">
                                <div class="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                                    <i class="fas fa-check text-sm"></i>
                                </div>
                                <span class="text-lg">We believe in the authority of Scripture</span>
                            </li>
                            <li class="flex items-start space-x-4">
                                <div class="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                                    <i class="fas fa-check text-sm"></i>
                                </div>
                                <span class="text-lg">We believe in salvation by grace through faith</span>
                            </li>
                            <li class="flex items-start space-x-4">
                                <div class="w-8 h-8 bg-white bg-opacity-20 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                                    <i class="fas fa-check text-sm"></i>
                                </div>
                                <span class="text-lg">We believe in the Great Commission</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Upcoming Events -->
    <section class="py-20 bg-gradient-to-br from-gray-50 to-indigo-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16 fade-on-scroll">
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Upcoming Events</h2>
                <p class="text-xl text-gray-600 max-w-2xl mx-auto">Join us for these special occasions and community gatherings</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php foreach ($upcomingEvents as $event): ?>
                <div class="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden hover-lift fade-on-scroll">
                    <div class="p-8">
                        <div class="flex items-center justify-between mb-4">
                            <div class="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                                <i class="fas fa-calendar-alt text-white text-xl"></i>
                            </div>
                            <span class="px-3 py-1 bg-indigo-100 text-indigo-800 text-sm font-medium rounded-full">
                                <?php echo ucfirst($event['event_type'] ?? 'Event'); ?>
                            </span>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-900 mb-3 group-hover:text-indigo-600 transition-colors duration-300">
                            <?php echo htmlspecialchars($event['title']); ?>
                        </h3>
                        <p class="text-gray-600 mb-6 leading-relaxed">
                            <?php echo htmlspecialchars(substr($event['description'], 0, 120)) . (strlen($event['description']) > 120 ? '...' : ''); ?>
                        </p>
                        <div class="space-y-3">
                            <div class="flex items-center text-gray-500">
                                <i class="fas fa-clock mr-3 text-indigo-500"></i>
                                <span><?php echo formatDateTime($event['start_datetime'], 'M j, Y g:i A'); ?></span>
                            </div>
                            <?php if ($event['location']): ?>
                            <div class="flex items-center text-gray-500">
                                <i class="fas fa-map-marker-alt mr-3 text-indigo-500"></i>
                                <span><?php echo htmlspecialchars($event['location']); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-12 fade-on-scroll">
                <a href="events.php" class="group inline-flex items-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-300 shadow-lg hover:shadow-xl hover-lift">
                    <i class="fas fa-calendar-plus mr-2"></i>
                    View All Events
                    <i class="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform duration-300"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- Recent Sermons -->
    <section class="py-20 bg-white">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="text-center mb-16 fade-on-scroll">
                <h2 class="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Recent Sermons</h2>
                <p class="text-xl text-gray-600 max-w-2xl mx-auto">Listen to our latest messages and grow in faith</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                <?php foreach ($recentSermons as $sermon): ?>
                <div class="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden hover-lift fade-on-scroll">
                    <div class="p-8">
                        <div class="flex items-center justify-between mb-4">
                            <div class="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg flex items-center justify-center">
                                <i class="fas fa-microphone text-white text-xl"></i>
                            </div>
                            <span class="px-3 py-1 bg-purple-100 text-purple-800 text-sm font-medium rounded-full">
                                <?php echo formatDate($sermon['sermon_date']); ?>
                            </span>
                        </div>
                        <h3 class="text-2xl font-bold text-gray-900 mb-3 group-hover:text-purple-600 transition-colors duration-300">
                            <?php echo htmlspecialchars($sermon['title']); ?>
                        </h3>
                        <p class="text-gray-600 mb-4">
                            by <span class="font-semibold text-gray-900"><?php echo htmlspecialchars($sermon['speaker']); ?></span>
                        </p>
                        <?php if ($sermon['topic']): ?>
                        <p class="text-sm text-gray-500 mb-6">
                            <i class="fas fa-tag mr-1"></i>
                            <?php echo htmlspecialchars($sermon['topic']); ?>
                        </p>
                        <?php endif; ?>
                        <?php if ($sermon['video_url']): ?>
                        <a href="<?php echo htmlspecialchars($sermon['video_url']); ?>" target="_blank" 
                           class="group/link inline-flex items-center text-purple-600 hover:text-purple-700 font-semibold transition-colors duration-300">
                            <i class="fas fa-play mr-2 group-hover/link:scale-110 transition-transform duration-300"></i>
                            Watch Now
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            
            <div class="text-center mt-12 fade-on-scroll">
                <a href="sermons.php" class="group inline-flex items-center bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-4 rounded-xl font-semibold hover:from-purple-700 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-xl hover-lift">
                    <i class="fas fa-headphones mr-2"></i>
                    View All Sermons
                    <i class="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform duration-300"></i>
                </a>
            </div>
        </div>
    </section>

    <!-- Plan Your Visit -->
    <section id="plan-visit" class="py-20 bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white relative overflow-hidden">
        <!-- Background elements -->
        <div class="absolute inset-0">
            <div class="absolute top-0 left-0 w-full h-full bg-black opacity-20"></div>
            <div class="absolute -top-40 -right-40 w-80 h-80 bg-white opacity-5 rounded-full blur-3xl"></div>
            <div class="absolute -bottom-40 -left-40 w-80 h-80 bg-purple-300 opacity-5 rounded-full blur-3xl"></div>
        </div>
        
        <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div class="fade-on-scroll">
                <h2 class="text-4xl md:text-6xl font-bold mb-6">Plan Your Visit</h2>
                <p class="text-xl md:text-2xl mb-12 text-gray-200 max-w-3xl mx-auto">We'd love to welcome you to our church family</p>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                    <div class="group p-8 glass-effect rounded-2xl hover-lift">
                        <div class="w-16 h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                            <i class="fas fa-heart text-white text-2xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-4">What to Expect</h3>
                        <p class="text-gray-200 leading-relaxed">Friendly faces, inspiring worship, and meaningful messages that speak to your heart.</p>
                    </div>
                    <div class="group p-8 glass-effect rounded-2xl hover-lift">
                        <div class="w-16 h-16 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                            <i class="fas fa-tshirt text-white text-2xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-4">Dress Code</h3>
                        <p class="text-gray-200 leading-relaxed">Come as you are! We welcome everyone in whatever makes you comfortable.</p>
                    </div>
                    <div class="group p-8 glass-effect rounded-2xl hover-lift">
                        <div class="w-16 h-16 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                            <i class="fas fa-child text-white text-2xl"></i>
                        </div>
                        <h3 class="text-2xl font-bold mb-4">Children</h3>
                        <p class="text-gray-200 leading-relaxed">We have programs for children of all ages during our services.</p>
                    </div>
                </div>
                
                <a href="contact.php" class="group inline-flex items-center bg-white text-indigo-600 px-8 py-4 rounded-xl font-semibold hover:bg-gray-100 transition-all duration-300 shadow-2xl hover:shadow-3xl hover-lift">
                    <i class="fas fa-envelope mr-2"></i>
                    Get in Touch
                    <i class="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform duration-300"></i>
                </a>
            </div>
        </div>
    </section>

<?php include 'includes/footer.php'; ?>
