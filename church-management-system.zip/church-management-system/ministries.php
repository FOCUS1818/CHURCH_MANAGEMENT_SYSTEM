<?php
require_once 'config/config.php';

use App\Database;

$database = new Database();
$db = $database->getConnection();

// Get ministries
$stmt = $db->prepare("SELECT m.*, COUNT(mm.member_id) as member_count, 
                      CONCAT(mem.first_name, ' ', mem.last_name) as leader_name,
                      mem.photo as leader_photo
                      FROM ministries m 
                      LEFT JOIN members mem ON m.leader_id = mem.id
                      LEFT JOIN ministry_members mm ON m.id = mm.ministry_id AND mm.is_active = 1 
                      WHERE m.is_active = 1 
                      GROUP BY m.id 
                      ORDER BY m.name");
$stmt->execute();
$ministries = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ministries - Olebu SDA Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-indigo-600">Olebu SDA Church</a>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600">Home</a>
                    <a href="index.php#about" class="text-gray-700 hover:text-indigo-600">About</a>
                    <a href="sermons.php" class="text-gray-700 hover:text-indigo-600">Sermons</a>
                    <a href="events.php" class="text-gray-700 hover:text-indigo-600">Events</a>
                    <a href="ministries.php" class="text-indigo-600 font-medium">Ministries</a>
                    <a href="members.php" class="text-gray-700 hover:text-indigo-600">Members</a>
                    <a href="contact.php" class="text-gray-700 hover:text-indigo-600">Contact</a>
                    <a href="admin/login.php" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">Admin</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="bg-gradient-to-r from-teal-600 to-green-600 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">Our Ministries</h1>
            <p class="text-xl text-teal-100">Discover ways to get involved and grow in your faith</p>
        </div>
    </div>

        <?php if (empty($ministries)): ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-1.306-.835-2.418-2-2.83M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-1.306.835-2.418 2-2.83m0 0a3 3 0 000-5.356M9 12a3 3 0 000 5.356m0 0a3 3 0 000-5.356m0 0a3 3 0 000 5.356"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No ministries available</h3>
                <p class="mt-1 text-sm text-gray-500">Check back later for ministry opportunities.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($ministries as $ministry): ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                        <div class="p-6">
                            <div class="flex items-center justify-between mb-4">
                                <h3 class="text-xl font-semibold text-gray-900"><?php echo htmlspecialchars($ministry['name']); ?></h3>
                                <span class="px-2 py-1 text-xs font-semibold bg-indigo-100 text-indigo-800 rounded-full">
                                    <?php echo $ministry['member_count']; ?> members
                                </span>
                            </div>
                            
                            <?php if ($ministry['description']): ?>
                                <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($ministry['description']); ?></p>
                            <?php endif; ?>
                            
                            <div class="space-y-3">
                                <?php if ($ministry['meeting_schedule']): ?>
                                    <div class="flex items-center text-sm text-gray-500">
                                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"></path>
                                        </svg>
                                        <span><?php echo htmlspecialchars($ministry['meeting_schedule']); ?></span>
                                    </div>
                                <?php endif; ?>
                                
                                <?php if ($ministry['contact_email']): ?>
                                    <div class="flex items-center text-sm text-gray-500">
                                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z"></path>
                                            <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z"></path>
                                        </svg>
                                        <a href="mailto:<?php echo htmlspecialchars($ministry['contact_email']); ?>" 
                                           class="text-indigo-600 hover:text-indigo-500">
                                            <?php echo htmlspecialchars($ministry['contact_email']); ?>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($ministry['leader_name']): ?>
                                <div class="mt-4 flex items-center">
                                    <?php if ($ministry['leader_photo']): ?>
                                        <img src="<?php echo htmlspecialchars($ministry['leader_photo']); ?>" 
                                             alt="<?php echo htmlspecialchars($ministry['leader_name']); ?>" 
                                             class="w-12 h-12 rounded-full object-cover mr-3">
                                    <?php else: ?>
                                        <div class="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
                                            <span class="text-indigo-600 font-semibold">
                                                <?php echo strtoupper(substr($ministry['leader_name'], 0, 1)); ?>
                                            </span>
                                        </div>
                                    <?php endif; ?>
                                    <div>
                                        <p class="text-sm font-medium text-gray-900">Leader: <?php echo htmlspecialchars($ministry['leader_name']); ?></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                            <div class="mt-6">
                                <?php 
                                // Check for custom link or use default based on ministry name
                                $button_link = !empty($ministry['custom_link']) ? $ministry['custom_link'] : 'contact.php?ministry=' . urlencode($ministry['name']);
                                $external_link = '';
                                
                                // For Youth Ministries, use the external link
                                if (stripos($ministry['name'], 'Youth') !== false) {
                                    $external_link = 'https://www.gcyouthministries.org/';
                                }
                                // For Youth Outreach specifically
                                if (stripos($ministry['name'], 'Outreach') !== false) {
                                    $external_link = 'https://www.gcyouthministries.org/ministries/young-adults/outreach-mission/';
                                }
                                // For Men's Ministry
                                if (stripos($ministry['name'], 'Men') !== false) {
                                    $external_link = 'https://mgucadventist.org/amm/';
                                }
                                // For Worship Team
                                if (stripos($ministry['name'], 'Worship') !== false) {
                                    $external_link = 'https://gc.adventist.org/about-us/departments-services/#12-strong-stewardship-strong';
                                }
                                // For Women's Ministry
                                if (stripos($ministry['name'], 'Women') !== false) {
                                    $external_link = 'https://women.adventist.org/';
                                }
                                // For Children's Ministry
                                if (stripos($ministry['name'], 'Children') !== false || stripos($ministry['name'], 'Kids') !== false) {
                                    $external_link = 'https://children.adventist.org/';
                                }
                                
                                // If there's an external link, show dropdown; otherwise use default
                                if (!empty($external_link)) {
                                    $local_link = 'ministry-details.php?id=' . $ministry['id'];
                                ?>
                                <div class="space-y-2">
                                    <a href="<?php echo htmlspecialchars($local_link); ?>" 
                                       class="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 text-center block transition duration-300">
                                        Know More (Local Page)
                                    </a>
                                    <a href="<?php echo htmlspecialchars($external_link); ?>" 
                                       target="_blank"
                                       class="w-full bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 text-center block transition duration-300">
                                        Visit General Church Site
                                    </a>
                                </div>
                                <?php } else { ?>
                                <a href="<?php echo htmlspecialchars($button_link); ?>" 
                                   class="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 text-center block transition duration-300">
                                    Know More
                                </a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <!-- Call to Action -->
        <div class="mt-16 bg-indigo-600 rounded-lg p-8 text-center text-white">
            <h2 class="text-2xl font-bold mb-4">Ready to Get Involved?</h2>
            <p class="text-lg mb-6">We have many opportunities for you to serve and grow in your faith. Contact us to learn more about how you can get involved.</p>
            <a href="contact.php" class="bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition duration-300">
                Contact Us Today
            </a>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>
