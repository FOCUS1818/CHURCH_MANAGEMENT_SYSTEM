<?php 
require 'c:/wamp64/www/church-management-system/config/config.php'; 
$db = (new App\Database())->getConnection(); 
$stmt = $db->prepare("SELECT m.*, 
GROUP_CONCAT(DISTINCT sg.group_name ORDER BY sg.group_name SEPARATOR ', ') as small_groups 
FROM members m 
LEFT JOIN member_small_groups msg ON m.id = msg.member_id
LEFT JOIN small_groups sg ON msg.small_group_id = sg.id
WHERE m.membership_status = 'active'
GROUP BY m.id
ORDER BY m.last_name, m.first_name");
$stmt->execute();
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);
print_r($members);
