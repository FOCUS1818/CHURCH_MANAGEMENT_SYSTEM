<?php
require_once '../config/config.php';
require_once '../classes/Event.php';

use App\Database;
use App\Event;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$event = new Event($db);

$error = '';
$success = '';

if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $event->title = sanitizeInput($_POST['title'] ?? '');
        $event->description = sanitizeInput($_POST['description'] ?? '');
        $event->event_type = $_POST['event_type'] ?? 'service';
        $event->start_datetime = $_POST['start_datetime'] ?? '';
        $event->end_datetime = $_POST['end_datetime'] ?? '';
        $event->location = sanitizeInput($_POST['location'] ?? '');
        $event->max_capacity = (int)($_POST['max_capacity'] ?? 0);
        $event->requires_rsvp = isset($_POST['requires_rsvp']) ? 1 : 0;
        $event->rsvp_deadline = $_POST['rsvp_deadline'] ?? null;
        $event->live_stream_url = sanitizeInput($_POST['live_stream_url'] ?? '');
        $event->is_live = isset($_POST['is_live']) ? 1 : 0;
        $event->created_by = $_SESSION['user_id'];
        
        if (empty($event->title) || empty($event->start_datetime)) {
            $error = 'Please fill in all required fields.';
        } elseif (date('Y', strtotime($event->start_datetime)) < date('Y')) {
            $error = 'The event date cannot be from a past year.';
        } else {
            // Handle file upload for flyer image
            if (isset($_FILES['flyer_image']) && $_FILES['flyer_image']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = uploadFile($_FILES['flyer_image'], '../uploads/', ['jpg', 'jpeg', 'png', 'gif']);
                if ($uploadResult['success']) {
                    $event->flyer_image = $uploadResult['filename'];
                } else {
                    $error = $uploadResult['message'];
                }
            }
            
            if (empty($error)) {
                if ($event->create()) {
                    $success = 'Event created successfully!';
                    logActivity('event_add', 'events', $event->id);
                    
                    // Send email notification to all members
                    $emailTitle = 'New Event: ' . $event->title;
                    $descriptionHtml = $event->description ? '<p>' . htmlspecialchars($event->description) . '</p>' : '';
                    $locationHtml = $event->location ? '<p><strong>Location:</strong> ' . htmlspecialchars($event->location) . '</p>' : '';
                    $emailContent = buildNotificationEmail(
                        $emailTitle,
                        "<p>Dear {member_first_name},</p>
                        <p>A new event has been added: <strong>" . $event->title . "</strong></p>
                        " . $descriptionHtml . "
                        <p><strong>Date:</strong> " . date('F j, Y', strtotime($event->start_datetime)) . "</p>
                        " . $locationHtml . "
                        <p>We hope to see you there!</p>",
                        'View Events',
                        BASE_URL . 'events.php'
                    );
                    
                    $notificationResult = notifyAllMembers($emailTitle, $emailContent, 'event');
                    
                    if ($notificationResult['success']) {
                        $success .= " Email notifications sent to {$notificationResult['sent']} members.";
                    }
                    
                    // Clear form data
                    $_POST = [];
                } else {
                    $error = 'Failed to create event. Please try again.';
                }
            }
        }
    }
}
?>
<?php
$pageTitle = "Add Event";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Events', 'url' => 'events.php'],
    ['name' => 'Add Event']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        Add New Event
                    </h2>
                    <p class="text-gray-600 mt-1">Create a new church event or activity</p>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <a href="events.php" class="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Events
                    </a>
                </div>
            </div>
        </div>

        <div class="max-w-3xl mx-auto">
            <?php if ($error): ?>
                <div class="mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="mb-4 bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Event Information</h3>
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="title" class="block text-sm font-medium text-gray-700">Event Title *</label>
                            <input type="text" id="title" name="title" required 
                                   value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="event_type" class="block text-sm font-medium text-gray-700">Event Type</label>
                            <select id="event_type" name="event_type" 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="service" <?php echo ($_POST['event_type'] ?? '') === 'service' ? 'selected' : ''; ?>>Service</option>
                                <option value="meeting" <?php echo ($_POST['event_type'] ?? '') === 'meeting' ? 'selected' : ''; ?>>Meeting</option>
                                <option value="youth" <?php echo ($_POST['event_type'] ?? '') === 'youth' ? 'selected' : ''; ?>>Youth</option>
                                <option value="community" <?php echo ($_POST['event_type'] ?? '') === 'community' ? 'selected' : ''; ?>>Community</option>
                                <option value="special" <?php echo ($_POST['event_type'] ?? '') === 'special' ? 'selected' : ''; ?>>Special</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                            <textarea id="description" name="description" rows="4" 
                                      class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Date & Time</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="start_datetime" class="block text-sm font-medium text-gray-700">Start Date & Time *</label>
                            <input type="datetime-local" id="start_datetime" name="start_datetime" required 
                                   value="<?php echo htmlspecialchars($_POST['start_datetime'] ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="end_datetime" class="block text-sm font-medium text-gray-700">End Date & Time</label>
                            <input type="datetime-local" id="end_datetime" name="end_datetime" 
                                   value="<?php echo htmlspecialchars($_POST['end_datetime'] ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Location & Capacity</h3>
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="location" class="block text-sm font-medium text-gray-700">Location</label>
                            <input type="text" id="location" name="location" 
                                   value="<?php echo htmlspecialchars($_POST['location'] ?? ''); ?>"
                                   placeholder="e.g., Main Sanctuary, Fellowship Hall"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="max_capacity" class="block text-sm font-medium text-gray-700">Maximum Capacity</label>
                            <input type="number" id="max_capacity" name="max_capacity" min="0" 
                                   value="<?php echo htmlspecialchars($_POST['max_capacity'] ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">RSVP Settings</h3>
                    
                    <div class="space-y-4">
                        <div class="flex items-center">
                            <input type="checkbox" id="requires_rsvp" name="requires_rsvp" value="1" 
                                   <?php echo isset($_POST['requires_rsvp']) ? 'checked' : ''; ?>
                                   class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                            <label for="requires_rsvp" class="ml-2 block text-sm text-gray-900">
                                This event requires RSVP
                            </label>
                        </div>
                        
                        <div id="rsvp_deadline_container" class="<?php echo isset($_POST['requires_rsvp']) ? '' : 'hidden'; ?>">
                            <label for="rsvp_deadline" class="block text-sm font-medium text-gray-700">RSVP Deadline</label>
                            <input type="datetime-local" id="rsvp_deadline" name="rsvp_deadline" 
                                   value="<?php echo htmlspecialchars($_POST['rsvp_deadline'] ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Live Streaming</h3>

                    <div class="space-y-4">
                        <div class="flex items-center">
                            <input type="checkbox" id="is_live" name="is_live" value="1"
                                   <?php echo isset($_POST['is_live']) ? 'checked' : ''; ?>
                                   class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                            <label for="is_live" class="ml-2 block text-sm text-gray-900">
                                This event will be streamed live
                            </label>
                        </div>

                        <div id="live_stream_container" class="<?php echo isset($_POST['is_live']) ? '' : 'hidden'; ?>">
                            <label for="live_stream_url" class="block text-sm font-medium text-gray-700">Live Stream URL</label>
                            <input type="url" id="live_stream_url" name="live_stream_url"
                                   value="<?php echo htmlspecialchars($_POST['live_stream_url'] ?? ''); ?>"
                                   placeholder="https://youtube.com/watch?v=..."
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <p class="mt-2 text-sm text-gray-500">Enter the URL of the live stream (YouTube, Vimeo, etc.)</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Event Flyer</h3>

                    <div>
                        <label for="flyer_image" class="block text-sm font-medium text-gray-700">Flyer Image</label>
                        <input type="file" id="flyer_image" name="flyer_image" accept="image/*"
                               class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                        <p class="mt-2 text-sm text-gray-500">Upload an image for the event flyer (optional)</p>
                    </div>
                </div>

                <div class="flex justify-end space-x-3">
                    <a href="events.php" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                        Cancel
                    </a>
                    <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                        Create Event
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Show/hide RSVP deadline based on checkbox
        document.getElementById('requires_rsvp').addEventListener('change', function() {
            const container = document.getElementById('rsvp_deadline_container');
            if (this.checked) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        });

        // Show/hide live stream URL based on checkbox
        document.getElementById('is_live').addEventListener('change', function() {
            const container = document.getElementById('live_stream_container');
            if (this.checked) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        });
    </script>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
