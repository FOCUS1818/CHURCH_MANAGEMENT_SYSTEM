<?php
require_once '../config/config.php';
require_once '../classes/User.php';
require_once '../classes/Member.php';

use App\Database;
use App\Member;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

// Get statistics
$member = new Member($db);
$stats = $member->getStatistics();

// Get recent members
$recentMembers = $member->getAll(1, 10);

// Get upcoming birthdays
$upcomingBirthdays = $member->getUpcomingBirthdays(7);

// Generate HTML content for PDF
$html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Church Dashboard Report - ' . date('F Y') . '</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4F46E5;
        }
        .header h1 {
            color: #4F46E5;
            margin: 0;
        }
        .header p {
            color: #666;
            margin: 5px 0 0 0;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        .stat-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
        }
        .stat-card .label {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
        .stat-card .value {
            font-size: 28px;
            font-weight: bold;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #4F46E5;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .section {
            margin-bottom: 30px;
        }
        .section h2 {
            color: #4F46E5;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #666;
            font-size: 12px;
        }
        @media print {
            body { padding: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Church Dashboard Report</h1>
        <p>Generated on ' . date('F j, Y g:i A') . '</p>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="label">Total Members</div>
            <div class="value">' . $stats['total'] . '</div>
        </div>
        <div class="stat-card">
            <div class="label">Active Members</div>
            <div class="value">' . $stats['active'] . '</div>
        </div>
        <div class="stat-card">
            <div class="label">New This Month</div>
            <div class="value">' . $stats['new_this_month'] . '</div>
        </div>
        <div class="stat-card">
            <div class="label">Upcoming Birthdays (7 days)</div>
            <div class="value">' . count($upcomingBirthdays) . '</div>
        </div>
    </div>

    <div class="section">
        <h2>Recent Members</h2>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Join Date</th>
                </tr>
            </thead>
            <tbody>';
            
foreach ($recentMembers as $m) {
    $html .= '
                <tr>
                    <td>' . htmlspecialchars($m['first_name'] . ' ' . $m['last_name']) . '</td>
                    <td>' . htmlspecialchars($m['email']) . '</td>
                    <td>' . htmlspecialchars($m['phone'] ?? 'N/A') . '</td>
                    <td>' . date('M j, Y', strtotime($m['created_at'])) . '</td>
                </tr>';
}

$html .= '
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>Upcoming Birthdays</h2>
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Birthday</th>
                    <th>Contact</th>
                </tr>
            </thead>
            <tbody>';
            
foreach ($upcomingBirthdays as $b) {
    $html .= '
                <tr>
                    <td>' . htmlspecialchars($b['first_name'] . ' ' . $b['last_name']) . '</td>
                    <td>' . date('F j', strtotime($b['date_of_birth'])) . '</td>
                    <td>' . htmlspecialchars($b['phone'] ?? 'N/A') . '</td>
                </tr>';
}

$html .= '
            </tbody>
        </table>
    </div>

    <div class="footer">
        <p>Church Management System - Report generated automatically</p>
    </div>

    <div class="no-print" style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #4F46E5; color: white; border: none; border-radius: 5px; cursor: pointer;">Print / Save as PDF</button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #666; color: white; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px;">Close</button>
    </div>
</body>
</html>
';

echo $html;
