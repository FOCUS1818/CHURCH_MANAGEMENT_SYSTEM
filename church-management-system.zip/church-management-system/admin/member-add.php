<?php
require_once '../config/config.php';
require_once '../classes/Member.php';

use App\Database;
use App\Member;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$member = new Member($db);

$error = '';
$success = '';

// Get households for dropdown
$stmt = $db->prepare("SELECT id, household_name FROM households ORDER BY household_name");
$stmt->execute();
$households = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get small groups for dropdown
$stmt = $db->prepare("SELECT id, group_name FROM small_groups WHERE is_active = 1 ORDER BY group_name");
$stmt->execute();
$small_groups = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $member->household_id = !empty($_POST['household_id']) ? (int)$_POST['household_id'] : null;
        $member->small_group_id = !empty($_POST['small_group_id']) ? (int)$_POST['small_group_id'] : null;
        $small_group_ids = $_POST['small_group_ids'] ?? [];
        $member->first_name = sanitizeInput($_POST['first_name'] ?? '');
        $member->last_name = sanitizeInput($_POST['last_name'] ?? '');
        $member->middle_name = sanitizeInput($_POST['middle_name'] ?? '');
        $member->gender = $_POST['gender'] ?? '';
        $member->date_of_birth = $_POST['date_of_birth'] ?: null;
        $member->marital_status = $_POST['marital_status'] ?? 'single';
        $member->phone = sanitizeInput($_POST['phone'] ?? '');
        $member->email = sanitizeInput($_POST['email'] ?? '');
        $member->address = sanitizeInput($_POST['address'] ?? '');
        $member->family_role = $_POST['family_role'] ?? 'other';
        $member->membership_status = $_POST['membership_status'] ?? 'visitor';
        $member->membership_class_completed = isset($_POST['membership_class_completed']) ? 1 : 0;
        $member->baptism_date = $_POST['baptism_date'] ?: null;
        $member->spiritual_gifts = sanitizeInput($_POST['spiritual_gifts'] ?? '');
        $member->notes = sanitizeInput($_POST['notes'] ?? '');
        
        // Validate required fields
        if (empty($member->first_name) || empty($member->last_name) || empty($member->gender)) {
            $error = 'Please fill in all required fields.';
        }
        // Validate first name - letters only
        elseif (!validateName($member->first_name)) {
            $error = 'First name should only contain letters (a-z, A-Z). Numbers are not allowed.';
        }
        // Validate last name - letters only
        elseif (!validateName($member->last_name)) {
            $error = 'Last name should only contain letters (a-z, A-Z). Numbers are not allowed.';
        }
        // Validate middle name if provided - letters only
        elseif (!empty($member->middle_name) && !validateName($member->middle_name)) {
            $error = 'Middle name should only contain letters (a-z, A-Z). Numbers are not allowed.';
        }
        // Validate phone - numbers only
        elseif (!empty($member->phone) && !validatePhone($member->phone)) {
            $error = 'Phone number should only contain numbers. Letters are not allowed.';
        }
        // Validate notes - max 50 words
        elseif (!validateWordLimit($member->notes, 50)) {
            $error = 'Notes should not exceed 50 words. Please shorten your notes.';
        }
        // Validate date of birth is not in the future
        elseif (!empty($member->date_of_birth) && strtotime($member->date_of_birth) > strtotime('today')) {
            $error = 'Date of birth cannot be in the future.';
        }
        // Validate baptism date is not in the future and not before DOB
        elseif (!empty($member->baptism_date)) {
            if (strtotime($member->baptism_date) > strtotime('today')) {
                $error = 'Baptism date cannot be in the future.';
            } elseif (!empty($member->date_of_birth) && strtotime($member->baptism_date) < strtotime($member->date_of_birth)) {
                $error = 'Baptism date cannot be before date of birth.';
            }
        }
        
        // Handle photo upload
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
            $uploadResult = uploadFile($_FILES['photo'], '../uploads/', ['jpg', 'jpeg', 'png', 'gif']);
            if ($uploadResult['success']) {
                $member->photo = $uploadResult['filename'];
            } else {
                $error = $uploadResult['message'];
            }
        }
        
        if (empty($error)) {
            if ($member->create()) {
                // Save small groups if any selected
                if (!empty($small_group_ids)) {
                    $member->saveSmallGroups($member->id, $small_group_ids);
                }
                logActivity('member_created', 'members', $member->id);
                $success = 'Member added successfully!';
                // Reset form
                $member = new Member($db);
            } else {
                $error = 'Failed to add member. Please try again.';
            }
        }
    }
}
?>
<?php
$pageTitle = "Add Member";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Members', 'url' => 'members.php'],
    ['name' => 'Add Member']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <div class="px-4 py-6 sm:px-0">
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Add New Member</h1>
                    <p class="text-gray-600 mt-1">Create a new member profile</p>
                </div>
                <a href="members.php" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 transition-colors duration-200">
                    <i class="fas fa-arrow-left mr-2"></i>
                    Back to Members
                </a>
            </div>

            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md mb-6">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="bg-white shadow rounded-lg p-6" id="memberForm">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Personal Information -->
                    <div class="space-y-6">
                        <h3 class="text-lg font-medium text-gray-900">Personal Information</h3>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="first_name" class="block text-sm font-medium text-gray-700 mb-2">First Name *</label>
                                <input type="text" id="first_name" name="first_name" required 
                                       value="<?php echo htmlspecialchars($member->first_name ?? ''); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                            <div>
                                <label for="last_name" class="block text-sm font-medium text-gray-700 mb-2">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" required 
                                       value="<?php echo htmlspecialchars($member->last_name ?? ''); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                        </div>
                        
                        <div>
                            <label for="middle_name" class="block text-sm font-medium text-gray-700 mb-2">Middle Name</label>
                            <input type="text" id="middle_name" name="middle_name" 
                                   value="<?php echo htmlspecialchars($member->middle_name ?? ''); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="gender" class="block text-sm font-medium text-gray-700 mb-2">Gender *</label>
                                <select id="gender" name="gender" required 
                                        class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                    <option value="">Select Gender</option>
                                    <option value="male" <?php echo $member->gender === 'male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="female" <?php echo $member->gender === 'female' ? 'selected' : ''; ?>>Female</option>
                                    <option value="other" <?php echo $member->gender === 'other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                            <div>
                                <label for="date_of_birth" class="block text-sm font-medium text-gray-700 mb-2">Date of Birth</label>
                                <input type="date" id="date_of_birth" name="date_of_birth" 
                                       value="<?php echo htmlspecialchars($member->date_of_birth ?? ''); ?>"
                                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            </div>
                        </div>
                        
                        <div>
                            <label for="marital_status" class="block text-sm font-medium text-gray-700 mb-2">Marital Status</label>
                            <select id="marital_status" name="marital_status" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="single" <?php echo $member->marital_status === 'single' ? 'selected' : ''; ?>>Single</option>
                                <option value="married" <?php echo $member->marital_status === 'married' ? 'selected' : ''; ?>>Married</option>
                                <option value="divorced" <?php echo $member->marital_status === 'divorced' ? 'selected' : ''; ?>>Divorced</option>
                                <option value="widowed" <?php echo $member->marital_status === 'widowed' ? 'selected' : ''; ?>>Widowed</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="photo" class="block text-sm font-medium text-gray-700 mb-2">Photo</label>
                            <input type="file" id="photo" name="photo" accept="image/*" 
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>
                    
                    <!-- Contact Information -->
                    <div class="space-y-6">
                        <h3 class="text-lg font-medium text-gray-900">Contact Information</h3>
                        
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email</label>
                            <input type="email" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($member->email ?? ''); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                        
                        <div>
                            <label for="phone" class="block text-sm font-medium text-gray-700 mb-2">Phone</label>
                            <input type="tel" id="phone" name="phone" pattern="[0-9]*" inputmode="numeric" placeholder="10 digit phone number (e.g., 1234567890)"
                                   value="<?php echo htmlspecialchars($member->phone ?? ''); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                   oninput="formatPhoneNumber(this)">
                            <p class="text-xs text-gray-500 mt-1">Enter 10 digit phone number</p>
                        </div>
                        
                        <div>
                            <label for="address" class="block text-sm font-medium text-gray-700 mb-2">Address</label>
                            <textarea id="address" name="address" rows="3" 
                                      class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"><?php echo htmlspecialchars($member->address ?? ''); ?></textarea>
                        </div>
                        
                        <div>
                            <label for="household_id" class="block text-sm font-medium text-gray-700 mb-2">Household</label>
                            <select id="household_id" name="household_id" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="">Select Household (Optional)</option>
                                <?php foreach ($households as $household): ?>
                                    <option value="<?php echo $household['id']; ?>" <?php echo $member->household_id == $household['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($household['household_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="small_group_ids" class="block text-sm font-medium text-gray-700 mb-2">Small Groups</label>
                            <select id="small_group_ids" name="small_group_ids[]" multiple 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                    size="4">
                                <?php foreach ($small_groups as $group): ?>
                                    <option value="<?php echo $group['id']; ?>">
                                        <?php echo htmlspecialchars($group['group_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="text-xs text-gray-500 mt-1">Hold Ctrl/Cmd to select multiple groups</p>
                        </div>
                        
                        <div>
                            <label for="family_role" class="block text-sm font-medium text-gray-700 mb-2">Family Role</label>
                            <select id="family_role" name="family_role" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="other" <?php echo $member->family_role === 'other' ? 'selected' : ''; ?>>Other</option>
                                <option value="father" <?php echo $member->family_role === 'father' ? 'selected' : ''; ?>>Father</option>
                                <option value="mother" <?php echo $member->family_role === 'mother' ? 'selected' : ''; ?>>Mother</option>
                                <option value="child" <?php echo $member->family_role === 'child' ? 'selected' : ''; ?>>Child</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <!-- Membership Information -->
                <div class="mt-8 space-y-6">
                    <h3 class="text-lg font-medium text-gray-900">Membership Information</h3>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="membership_status" class="block text-sm font-medium text-gray-700 mb-2">Membership Status</label>
                            <select id="membership_status" name="membership_status" 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                                <option value="visitor" <?php echo $member->membership_status === 'visitor' ? 'selected' : ''; ?>>Visitor</option>
                                <option value="active" <?php echo $member->membership_status === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $member->membership_status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                <option value="deceased" <?php echo $member->membership_status === 'deceased' ? 'selected' : ''; ?>>Deceased</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="baptism_date" class="block text-sm font-medium text-gray-700 mb-2">Baptism Date</label>
                            <input type="date" id="baptism_date" name="baptism_date" 
                                   value="<?php echo htmlspecialchars($member->baptism_date ?? ''); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                        </div>
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="membership_class_completed" name="membership_class_completed" 
                               <?php echo $member->membership_class_completed ? 'checked' : ''; ?>
                               class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                        <label for="membership_class_completed" class="ml-2 block text-sm text-gray-900">
                            Membership class completed
                        </label>
                    </div>
                    
                    <div>
                        <label for="spiritual_gifts" class="block text-sm font-medium text-gray-700 mb-2">Spiritual Gifts</label>
                        <textarea id="spiritual_gifts" name="spiritual_gifts" rows="3" 
                                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"><?php echo htmlspecialchars($member->spiritual_gifts ?? ''); ?></textarea>
                    </div>
                    
                    <div>
                        <label for="notes" class="block text-sm font-medium text-gray-700 mb-2">Notes <span class="text-gray-500">(max 50 words)</span></label>
                        <textarea id="notes" name="notes" rows="4" 
                                  class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                                  oninput="updateWordCount(this, 'notesCount', 50)"><?php echo htmlspecialchars($member->notes ?? ''); ?></textarea>
                        <p class="text-sm text-gray-500 mt-1">Words: <span id="notesCount"><?php echo !empty($member->notes) ? getWordCount($member->notes) : 0; ?></span>/50</p>
                    </div>
                </div>
                
                <div class="mt-8 flex justify-end space-x-4">
                    <a href="members.php" class="bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700">
                        Cancel
                    </a>
                    <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700">
                        Add Member
                    </button>
                </div>
            </form>
            
            <script>
            // Phone number formatting - remove any non-numeric characters
            function formatPhoneNumber(input) {
                let value = input.value.replace(/\D/g, ''); // Remove all non-digits
                if (value.length > 10) {
                    value = value.substring(0, 10); // Limit to 10 digits
                }
                input.value = value;
            }
            
            // Word count function with display
            function updateWordCount(textarea, displayId, limit) {
                const text = textarea.value.trim();
                const words = text === '' ? 0 : text.split(/\s+/).filter(word => word.length > 0).length;
                const display = document.getElementById(displayId);
                display.textContent = words;
                
                if (words > limit) {
                    display.classList.add('text-red-600');
                    display.classList.remove('text-gray-500');
                } else {
                    display.classList.remove('text-red-600');
                    display.classList.add('text-gray-500');
                }
            }
            
            // Block input when word limit is reached
            function enforceWordLimit(textarea, limit) {
                const text = textarea.value.trim();
                const words = text === '' ? [] : text.split(/\s+/);
                
                if (words.length > limit) {
                    // Reconstruct the text with only allowed words
                    const allowedText = words.slice(0, limit).join(' ');
                    textarea.value = allowedText;
                    
                    // Update display
                    const displayId = 'notesCount';
                    const display = document.getElementById(displayId);
                    if (display) {
                        display.textContent = limit;
                    }
                    
                    return false; // Limit reached
                }
                return true; // Within limit
            }
            
            // Common male and female names for gender validation
            const commonMaleNames = ['john', 'james', 'michael', 'david', 'richard', 'charles', 'joseph', 'thomas', 'christopher', 'daniel', 'matthew', 'anthony', 'mark', 'donald', 'steven', 'paul', 'andrew', 'joshua', 'kenneth', 'kevin', 'brian', 'george', 'edward', 'ronald', 'timothy', 'jason', 'jeffrey', 'ryan', 'jacob', 'gary', 'nicholas', 'eric', 'jonathan', 'stephen', 'larry', 'justin', 'scott', 'brandon', 'raymond', 'samuel', 'gregory', 'benjamin', 'patrick', 'frank', 'alexander', 'jack', 'dennis', 'jerry', 'tyler', 'aaron', 'jose', 'adam', 'nathan', 'henry', 'douglas', 'zachary', 'peter', 'kyle', 'noah', 'ethan', 'jeremy', 'walter', 'christian', 'keith', 'roger', 'terry', 'austin', 'sean', 'gerald', 'carl', 'harold', 'dylan', 'arthur', 'lawrence', 'jordan', 'jesse', 'bryan', 'billy', 'bruce', 'gabriel', 'joe', 'logan', 'albert', 'willie', 'alan', 'eugene', 'russell', 'bobby', 'philip', 'ralph', 'roy', 'louis', 'johnny', 'howard', 'phillip', 'wayne', 'vincent', 'randy', 'martin', 'harry', 'oscar', 'clarence', 'ray', 'mario', 'isaac', 'abraham', 'jacob', 'joshua', 'samuel', 'david', 'solomon', 'elijah', 'daniel', 'moses', 'aaron', 'elisha', 'isaiah', 'jeremiah', 'ezekiel', 'nehemiah', 'job'];
            const commonFemaleNames = ['mary', 'patricia', 'jennifer', 'linda', 'elizabeth', 'barbara', 'susan', 'jessica', 'sarah', 'karen', 'lisa', 'nancy', 'betty', 'margaret', 'sandra', 'ashley', 'kimberly', 'emily', 'donna', 'michelle', 'dorothy', 'carol', 'amanda', 'melissa', 'deborah', 'stephanie', 'rebecca', 'sharon', 'laura', 'cynthia', 'kathleen', 'amy', 'shirley', 'angela', 'helen', 'anna', 'brenda', 'pamela', 'emma', 'nicole', 'hermina', 'irene', 'jane', 'lorraine', 'marie', 'janet', 'catherine', 'frances', 'ann', 'joyce', 'diane', 'alice', 'julie', 'heather', 'teresa', 'doris', 'gloria', 'evelyn', 'jean', 'cheryl', 'mildred', 'katherine', 'joan', 'judith', 'martha', 'debra', 'joyce', 'alexandra', 'vivian', 'hannah', 'clara', 'lucy', 'paula', 'bailey', 'ruby', 'caroline', 'leah', 'cathy', 'nichole', 'grace', 'terri', 'claire', 'sara', 'madison', 'kathryn', 'abigail', 'sophia', 'denise', 'amber', 'marilyn', 'danielle', 'beverly', 'isabella', 'natalie', 'brittany', 'charlotte', 'christina', 'louise', 'alexis', 'margaret', 'samantha', 'victoria', 'cynthia', 'rachel', 'catherine', 'katherine', 'elizabeth', 'martha', 'sarah', 'rebecca', 'priscilla', 'phoebe', 'lucy', 'mary', 'anna', 'ruth', 'deborah', 'leah', 'naomi', 'miriam'];
            
            // Form validation
            document.getElementById('memberForm').addEventListener('submit', function(e) {
                const firstName = document.getElementById('first_name').value.trim();
                const lastName = document.getElementById('last_name').value.trim();
                const middleName = document.getElementById('middle_name').value.trim();
                const phone = document.getElementById('phone').value;
                const notes = document.getElementById('notes').value;
                const gender = document.getElementById('gender').value;
                const dateOfBirth = document.getElementById('date_of_birth').value;
                const baptismDate = document.getElementById('baptism_date').value;
                const familyRole = document.getElementById('family_role').value;
                
                // Name validation - letters only
                const namePattern = /^[a-zA-Z\s\-\'\.\x{00C0}-\x{024F}]+$/;
                
                if (firstName && !namePattern.test(firstName)) {
                    alert('First name should only contain letters (a-z, A-Z). Numbers are not allowed.');
                    e.preventDefault();
                    return false;
                }
                
                if (lastName && !namePattern.test(lastName)) {
                    alert('Last name should only contain letters (a-z, A-Z). Numbers are not allowed.');
                    e.preventDefault();
                    return false;
                }
                
                if (middleName && !namePattern.test(middleName)) {
                    alert('Middle name should only contain letters (a-z, A-Z). Numbers are not allowed.');
                    e.preventDefault();
                    return false;
                }
                
                // Phone validation - numbers only
                if (phone && !/^\d+$/.test(phone)) {
                    alert('Phone number should only contain numbers. Letters are not allowed.');
                    e.preventDefault();
                    return false;
                }
                
                // Phone length validation
                if (phone && phone.length !== 10) {
                    alert('Phone number must be exactly 10 digits.');
                    e.preventDefault();
                    return false;
                }
                
                // Notes word limit
                const wordCount = notes.trim() === '' ? 0 : notes.trim().split(/\s+/).filter(word => word.length > 0).length;
                if (wordCount > 50) {
                    alert('Notes should not exceed 50 words. Please shorten your notes.');
                    e.preventDefault();
                    return false;
                }
                
                // Gender and name validation - BLOCK if mismatch
                const name = firstName.toLowerCase().trim();
                
                // Check if name strongly suggests a different gender
                if (gender === 'male') {
                    const strongMaleNames = ['john', 'james', 'michael', 'david', 'richard', 'charles', 'joseph', 'thomas', 'christopher', 'daniel', 'matthew', 'anthony', 'mark', 'donald', 'steven', 'paul', 'andrew', 'joshua', 'kenneth', 'kevin', 'brian', 'george', 'edward', 'ronald', 'timothy', 'jason', 'jeffrey', 'ryan', 'jacob', 'gary', 'nicholas', 'eric', 'jonathan', 'stephen'];
                    const femaleNames = ['mary', 'patricia', 'jennifer', 'linda', 'elizabeth', 'barbara', 'susan', 'jessica', 'sarah', 'karen', 'lisa', 'nancy', 'betty', 'margaret', 'sandra', 'ashley', 'kimberly', 'emily', 'donna', 'michelle', 'dorothy', 'carol', 'amanda', 'melissa', 'deborah', 'stephanie', 'rebecca', 'sharon', 'laura', 'cynthia', 'kathleen', 'amy', 'shirley', 'angela', 'helen', 'anna', 'brenda', 'pamela', 'emma', 'nicole', 'hermina', 'irene', 'jane', 'lorraine', 'marie', 'janet', 'catherine', 'frances', 'ann', 'joyce', 'diane', 'alice', 'julie', 'heather', 'teresa'];
                    
                    if (femaleNames.includes(name)) {
                        alert('Error: The name "' + firstName + '" is typically a female name. Please select Female as the gender.');
                        e.preventDefault();
                        return false;
                    }
                } else if (gender === 'female') {
                    const strongFemaleNames = ['mary', 'patricia', 'jennifer', 'linda', 'elizabeth', 'barbara', 'susan', 'jessica', 'sarah', 'karen', 'lisa', 'nancy', 'betty', 'margaret', 'sandra', 'ashley', 'kimberly', 'emily', 'donna', 'michelle', 'dorothy', 'carol', 'amanda', 'melissa', 'deborah', 'stephanie', 'rebecca', 'sharon', 'laura', 'cynthia', 'kathleen', 'amy', 'shirley', 'angela', 'helen', 'anna', 'brenda', 'pamela', 'emma', 'nicole'];
                    const maleNames = ['john', 'james', 'michael', 'david', 'richard', 'charles', 'joseph', 'thomas', 'christopher', 'daniel', 'matthew', 'anthony', 'mark', 'donald', 'steven', 'paul', 'andrew', 'joshua', 'kenneth', 'kevin', 'brian', 'george', 'edward', 'ronald', 'timothy', 'jason', 'jeffrey', 'ryan', 'jacob', 'gary', 'nicholas', 'eric', 'jonathan', 'stephen'];
                    
                    if (maleNames.includes(name)) {
                        alert('Error: The name "' + firstName + '" is typically a male name. Please select Male as the gender.');
                        e.preventDefault();
                        return false;
                    }
                }
                
                // Family role validation - must match gender
                const familyRole = document.getElementById('family_role').value;
                if (familyRole === 'father' && gender !== 'male') {
                    alert('Error: Family role "Father" can only be selected with Male gender.');
                    e.preventDefault();
                    return false;
                }
                if (familyRole === 'mother' && gender !== 'female') {
                    alert('Error: Family role "Mother" can only be selected with Female gender.');
                    e.preventDefault();
                    return false;
                }
                
                // Baptism date validation - cannot be before date of birth
                if (baptismDate && dateOfBirth) {
                    const dob = new Date(dateOfBirth);
                    const baptism = new Date(baptismDate);
                    
                    if (baptism < dob) {
                        alert('Baptism date cannot be before date of birth.');
                        e.preventDefault();
                        return false;
                    }
                }
                
                // If no DOB but baptism date is in future, warn
                if (baptismDate && !dateOfBirth) {
                    const today = new Date();
                    const baptism = new Date(baptismDate);
                    if (baptism > today) {
                        alert('Baptism date cannot be in the future. Please enter the date of birth first.');
                        e.preventDefault();
                        return false;
                    }
                }
                
                return true;
            });
            
            // Add input restrictions for name fields - remove numbers on input
            document.getElementById('first_name').addEventListener('input', function(e) {
                this.value = this.value.replace(/[0-9]/g, '');
            });
            
            document.getElementById('last_name').addEventListener('input', function(e) {
                this.value = this.value.replace(/[0-9]/g, '');
            });
            
            document.getElementById('middle_name').addEventListener('input', function(e) {
                this.value = this.value.replace(/[0-9]/g, '');
            });
            
            // Phone field - format to numbers only
            document.getElementById('phone').addEventListener('input', function(e) {
                formatPhoneNumber(this);
            });
            
            // Notes field - enforce word limit on input
            document.getElementById('notes').addEventListener('input', function() {
                enforceWordLimit(this, 50);
            });
            
            // Date of birth change - update baptism date min attribute
            document.getElementById('date_of_birth').addEventListener('change', function() {
                const baptismDateInput = document.getElementById('baptism_date');
                if (this.value) {
                    baptismDateInput.min = this.value;
                } else {
                    baptismDateInput.removeAttribute('min');
                }
            });
            
            // Initialize baptism date min on page load if DOB exists
            window.addEventListener('DOMContentLoaded', function() {
                const dob = document.getElementById('date_of_birth').value;
                const baptismDateInput = document.getElementById('baptism_date');
                if (dob) {
                    baptismDateInput.min = dob;
                }
            });
            </script>
        </div>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
