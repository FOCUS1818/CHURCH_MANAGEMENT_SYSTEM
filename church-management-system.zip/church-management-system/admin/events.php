<?php
require_once '../config/config.php';
require_once '../classes/Event.php';

use App\Database;
use App\Event;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$event = new Event($db);

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$search = $_GET['search'] ?? '';
$eventType = $_GET['event_type'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';

$events = $event->getAll($page, 10, $search, $eventType, $dateFrom, $dateTo);
$totalCount = $event->getTotalCount($search, $eventType, $dateFrom, $dateTo);
$paginationData = getPaginationData($page, $totalCount, 10);
?>
<?php
$pageTitle = "Events";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Events']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Events Management</h1>
                    <p class="text-gray-600 mt-1">Manage church events and activities</p>
                </div>
                <a href="event-add.php" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors duration-200">
                    <i class="fas fa-plus mr-2"></i>
                    Add Event
                </a>
            </div>
        </div>

        <!-- Search and filters -->
        <div class="bg-white shadow rounded-lg mb-6">
            <div class="px-4 py-5 sm:p-6">
                <form method="GET" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    <div>
                        <input type="text" name="search" placeholder="Search events..." 
                               value="<?php echo htmlspecialchars($search); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    <div>
                        <select name="event_type" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">All Types</option>
                            <option value="service" <?php echo $eventType === 'service' ? 'selected' : ''; ?>>Service</option>
                            <option value="meeting" <?php echo $eventType === 'meeting' ? 'selected' : ''; ?>>Meeting</option>
                            <option value="youth" <?php echo $eventType === 'youth' ? 'selected' : ''; ?>>Youth</option>
                            <option value="community" <?php echo $eventType === 'community' ? 'selected' : ''; ?>>Community</option>
                            <option value="special" <?php echo $eventType === 'special' ? 'selected' : ''; ?>>Special</option>
                        </select>
                    </div>
                    <div>
                        <input type="date" name="date_from" placeholder="From Date" 
                               value="<?php echo htmlspecialchars($dateFrom); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    <div>
                        <input type="date" name="date_to" placeholder="To Date" 
                               value="<?php echo htmlspecialchars($dateTo); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                            Search
                        </button>
                        <a href="events.php" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700">
                            Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Events table -->
        <div class="bg-white shadow overflow-hidden sm:rounded-md">
            <div class="px-4 py-5 sm:p-0">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Event</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date & Time</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RSVP</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($events as $event): ?>
                            <tr>
                                <td class="px-6 py-4">
                                    <div>
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo htmlspecialchars($event['title']); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo htmlspecialchars(substr($event['description'], 0, 100)) . (strlen($event['description']) > 100 ? '...' : ''); ?>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                                        <?php 
                                        switch($event['event_type']) {
                                            case 'service': echo 'bg-blue-100 text-blue-800'; break;
                                            case 'meeting': echo 'bg-green-100 text-green-800'; break;
                                            case 'youth': echo 'bg-purple-100 text-purple-800'; break;
                                            case 'community': echo 'bg-orange-100 text-orange-800'; break;
                                            case 'special': echo 'bg-red-100 text-red-800'; break;
                                            default: echo 'bg-gray-100 text-gray-800';
                                        }
                                        ?>">
                                        <?php echo ucfirst($event['event_type']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <div><?php echo formatDateTime($event['start_datetime'], 'M j, Y'); ?></div>
                                    <div class="text-gray-500"><?php echo formatDateTime($event['start_datetime'], 'g:i A'); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo htmlspecialchars($event['location'] ?: 'TBD'); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php if ($event['requires_rsvp']): ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                            Required
                                        </span>
                                    <?php else: ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                            Not Required
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <a href="event-edit.php?id=<?php echo $event['id']; ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                                    <a href="event-view.php?id=<?php echo $event['id']; ?>" class="text-green-600 hover:text-green-900 mr-3">View</a>
                                    <a href="event-delete.php?id=<?php echo $event['id']; ?>&csrf_token=<?php echo urlencode(generateCSRFToken()); ?>" 
                                       onclick="return confirm('Are you sure you want to delete this event?')"
                                       class="text-red-600 hover:text-red-900">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <?php if ($paginationData['total_pages'] > 1): ?>
            <div class="mt-6">
                <?php echo generatePagination($paginationData, 'events.php'); ?>
            </div>
        <?php endif; ?>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
