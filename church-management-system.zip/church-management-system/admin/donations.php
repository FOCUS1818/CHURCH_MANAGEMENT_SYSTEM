<?php
require_once '../config/config.php';
require_once '../classes/Donation.php';

use App\Database;
use App\Donation;

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$database = new Database();
$db = $database->getConnection();
$donation = new Donation($db);

// Handle actions
$action = $_GET['action'] ?? '';
$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_manual_donation') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error_message = 'Invalid request. Please refresh and try again.';
    } else {
        $donor_name = sanitizeInput($_POST['donor_name'] ?? '');
        $donor_email = sanitizeInput($_POST['donor_email'] ?? '');
        $donor_phone = sanitizeInput($_POST['donor_phone'] ?? '');
        $amount = floatval($_POST['amount'] ?? 0);
        $payment_method = sanitizeInput($_POST['payment_method'] ?? 'cash');
        
        // Map to valid ENUM values from schema
        $validPaymentMethods = ['cash', 'bank_transfer', 'check', 'credit_card', 'debit_card'];
        if (!in_array($payment_method, $validPaymentMethods)) {
            $payment_method = 'cash';
        }
        $donation_type = sanitizeInput($_POST['donation_type'] ?? 'offering');
        
        // Map to valid ENUM values from schema
        $validDonationTypes = ['tithe', 'offering', 'special', 'building_fund', 'missions', 'other'];
        if (!in_array($donation_type, $validDonationTypes)) {
            $donation_type = 'offering';
        }
        
        $donation_purpose = sanitizeInput($_POST['donation_purpose'] ?? '');
        $notes = sanitizeInput($_POST['notes'] ?? '');
        $donation_date = $_POST['donation_date'] ?? date('Y-m-d');
        $payment_status = sanitizeInput($_POST['payment_status'] ?? 'completed');
        
        // Map to valid ENUM values from schema
        $validStatuses = ['pending', 'completed', 'failed', 'cancelled'];
        if (!in_array($payment_status, $validStatuses)) {
            $payment_status = 'completed';
        }
        
        $is_anonymous = isset($_POST['is_anonymous']) ? 1 : 0;

        // Server-side validation
        $validation_errors = [];
        
        // Validate donor name (letters, spaces, hyphens, apostrophes only)
        if ($donor_name === '') {
            $validation_errors[] = 'Donor name is required.';
        } elseif (!preg_match('/^[A-Za-z\s\-\']+$/', $donor_name)) {
            $validation_errors[] = 'Donor name can only contain letters, spaces, hyphens, and apostrophes.';
        }
        
        // Validate email if provided
        if ($donor_email !== '' && !filter_var($donor_email, FILTER_VALIDATE_EMAIL)) {
            $validation_errors[] = 'Please enter a valid email address.';
        }
        
        // Validate phone if provided (numbers, +, -, spaces, parentheses)
        if ($donor_phone !== '' && !preg_match('/^[0-9+\-\s()]{7,15}$/', $donor_phone)) {
            $validation_errors[] = 'Please enter a valid phone number (7-15 characters, numbers only).';
        }
        
        // Validate amount
        if ($amount <= 0) {
            $validation_errors[] = 'Please enter a valid amount greater than 0.';
        }
        
        // Validate donation purpose (letters, spaces, hyphens only)
        if ($donation_purpose !== '' && !preg_match('/^[A-Za-z\s\-\']+$/', $donation_purpose)) {
            $validation_errors[] = 'Donation purpose can only contain letters, spaces, and hyphens.';
        }

        if (!empty($validation_errors)) {
            $error_message = implode(' ', $validation_errors);
        } else {
            $payload = [
                'donor_name' => $donor_name,
                'donor_email' => $donor_email,
                'donor_phone' => $donor_phone,
                'amount' => $amount,
                'payment_method' => $payment_method,
                'donation_type' => $donation_type,
                'donation_purpose' => $donation_purpose,
                'notes' => $notes,
                'donation_date' => $donation_date,
                'payment_status' => $payment_status,
                'is_anonymous' => $is_anonymous,
                'transaction_id' => null,
                'payment_reference' => null
            ];

            $createdId = $donation->create($payload);
            
            if ($createdId && is_numeric($createdId)) {
                $success_message = 'Manual donation added successfully.';
                logActivity('donation_add_manual', 'donations', $createdId);
                $_POST = [];
            } else {
                $error_msg = '';
                if (is_array($createdId)) {
                    $error_msg = $createdId['error'] ?? 'Unknown error';
                } elseif ($createdId === false) {
                    $error_msg = 'Database operation failed - check logs';
                } else {
                    $error_msg = 'Unexpected result type: ' . gettype($createdId);
                }
$error_message = "Unable to add donation. Details: $error_msg";
            }
        }
    }
}

if ($action === 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if ($donation->delete($id)) {
        $success_message = "Donation deleted successfully.";
    } else {
        $error_message = "Error deleting donation.";
    }
}

if ($action === 'update_status' && isset($_GET['id']) && isset($_GET['status'])) {
    $id = intval($_GET['id']);
    $status = $_GET['status'];
    $allowed_statuses = ['pending', 'completed', 'failed', 'cancelled'];
    
    if (in_array($status, $allowed_statuses)) {
        $donation_data = $donation->getById($id);
        if ($donation_data) {
            $donation_data['payment_status'] = $status;
            if ($donation->update($id, $donation_data)) {
                $success_message = "Donation status updated successfully.";
            } else {
                $error_message = "Error updating donation status.";
            }
        }
    }
}

// Get filters
$filters = [
    'search' => $_GET['search'] ?? '',
    'donation_type' => $_GET['donation_type'] ?? '',
    'payment_status' => $_GET['payment_status'] ?? '',
    'date_from' => $_GET['date_from'] ?? '',
    'date_to' => $_GET['date_to'] ?? ''
];

// Pagination
$page = intval($_GET['page'] ?? 1);
$limit = 20;

// Get donations
$donations = $donation->getAll($page, $limit, $filters);
$total_count = $donation->getTotalCount($filters);
$total_pages = ceil($total_count / $limit);

// Get statistics
$stats = $donation->getStats($filters);
$total_amount = 0;
$total_donations = 0;
foreach ($stats as $stat) {
    $total_amount += $stat['total_amount'];
    $total_donations += $stat['type_count'];
}

$pageTitle = "Donations Management";
include '../includes/admin-header.php';

// Start output buffering to capture page content
ob_start();
?>
            <!-- Header -->
            <div class="mb-8">
                <div class="flex items-center justify-between">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-900 flex items-center">
                            <i class="fas fa-heart mr-3 text-green-600"></i>
                            Donations Management
                        </h1>
                        <p class="text-gray-600 mt-2">Manage and track all donations</p>
                    </div>
                </div>
            </div>

            <!-- Success/Error Messages -->
            <?php if ($success_message): ?>
            <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg">
                <div class="flex items-center">
                    <i class="fas fa-check-circle mr-2"></i>
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($error_message): ?>
            <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg">
                <div class="flex items-center">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="bg-white rounded-xl shadow-sm p-6 mb-8 border border-gray-200">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="text-lg font-semibold text-gray-900">Add Manual Donation</h3>
                    <span class="text-sm text-gray-500">For cash, transfer, or other offline giving</span>
                </div>

                <form method="POST" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="action" value="add_manual_donation">

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Donor Name *</label>
                        <input type="text" name="donor_name" required
                               pattern="[A-Za-z\s\-']+"
                               title="Only letters, spaces, hyphens, and apostrophes allowed"
                               value="<?php echo htmlspecialchars($_POST['donor_name'] ?? ''); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Donor Email</label>
                        <input type="email" name="donor_email"
                               pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                               title="Please enter a valid email address"
                               value="<?php echo htmlspecialchars($_POST['donor_email'] ?? ''); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Donor Phone</label>
                        <input type="tel" name="donor_phone"
                               pattern="[0-9+\-\s()]{7,15}"
                               title="Only numbers, +, -, spaces, and parentheses allowed (7-15 characters)"
                               maxlength="15"
                               value="<?php echo htmlspecialchars($_POST['donor_phone'] ?? ''); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Amount *</label>
                        <input type="number" step="0.01" min="0.01" name="amount" required
                               title="Enter a valid amount greater than 0"
                               value="<?php echo htmlspecialchars($_POST['amount'] ?? ''); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Donation Type</label>
                        <select name="donation_type" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="tithe" <?php echo (($_POST['donation_type'] ?? '') === 'tithe') ? 'selected' : ''; ?>>Tithe</option>
                            <option value="offering" <?php echo (($_POST['donation_type'] ?? 'offering') === 'offering') ? 'selected' : ''; ?>>Offering</option>
                            <option value="special" <?php echo (($_POST['donation_type'] ?? '') === 'special') ? 'selected' : ''; ?>>Special</option>
                            <option value="building_fund" <?php echo (($_POST['donation_type'] ?? '') === 'building_fund') ? 'selected' : ''; ?>>Building Fund</option>
                            <option value="missions" <?php echo (($_POST['donation_type'] ?? '') === 'missions') ? 'selected' : ''; ?>>Missions</option>
                            <option value="other" <?php echo (($_POST['donation_type'] ?? '') === 'other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                        <select name="payment_method" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="cash" <?php echo (($_POST['payment_method'] ?? 'cash') === 'cash') ? 'selected' : ''; ?>>Cash</option>
                            <option value="bank_transfer" <?php echo (($_POST['payment_method'] ?? '') === 'bank_transfer') ? 'selected' : ''; ?>>Bank Transfer</option>
                            <option value="check" <?php echo (($_POST['payment_method'] ?? '') === 'check') ? 'selected' : ''; ?>>Check</option>
                            <option value="card" <?php echo (($_POST['payment_method'] ?? '') === 'card') ? 'selected' : ''; ?>>Card</option>
                            <option value="other" <?php echo (($_POST['payment_method'] ?? '') === 'other') ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Donation Date</label>
                        <input type="date" name="donation_date"
                               value="<?php echo htmlspecialchars($_POST['donation_date'] ?? date('Y-m-d')); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Payment Status</label>
                        <select name="payment_status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="completed" <?php echo (($_POST['payment_status'] ?? 'completed') === 'completed') ? 'selected' : ''; ?>>Completed</option>
                            <option value="pending" <?php echo (($_POST['payment_status'] ?? '') === 'pending') ? 'selected' : ''; ?>>Pending</option>
                            <option value="failed" <?php echo (($_POST['payment_status'] ?? '') === 'failed') ? 'selected' : ''; ?>>Failed</option>
                            <option value="cancelled" <?php echo (($_POST['payment_status'] ?? '') === 'cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Purpose</label>
                        <input type="text" name="donation_purpose"
                               pattern="[A-Za-z\s\-']+"
                               title="Only letters, spaces, hyphens, and apostrophes allowed"
                               value="<?php echo htmlspecialchars($_POST['donation_purpose'] ?? ''); ?>"
                               placeholder="e.g. Sunday Service"
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>

                    <div class="md:col-span-3">
                        <label class="block text-sm font-medium text-gray-700 mb-2">Notes</label>
                        <textarea name="notes" rows="3"
                                  class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"><?php echo htmlspecialchars($_POST['notes'] ?? ''); ?></textarea>
                    </div>

                    <div class="md:col-span-3 flex items-center justify-between">
                        <label class="inline-flex items-center">
                            <input type="checkbox" name="is_anonymous" value="1" <?php echo isset($_POST['is_anonymous']) ? 'checked' : ''; ?> class="h-4 w-4 text-indigo-600 border-gray-300 rounded">
                            <span class="ml-2 text-sm text-gray-700">Mark as anonymous</span>
                        </label>

                        <button type="submit" class="px-5 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200">
                            <i class="fas fa-plus mr-1"></i>
                            Add Donation
                        </button>
                    </div>
                </form>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-money-bill-wave text-green-600 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Total Amount</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo CURRENCY_SYMBOL; ?><?php echo number_format($total_amount, 2); ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-hand-holding-heart text-blue-600 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Total Donations</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo number_format($total_donations); ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-chart-line text-purple-600 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">Average Amount</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo CURRENCY_SYMBOL; ?><?php echo $total_donations > 0 ? number_format($total_amount / $total_donations, 2) : '0.00'; ?></p>
                        </div>
                    </div>
                </div>
                
                <div class="bg-white rounded-xl shadow-sm p-6 border border-gray-200">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-calendar-day text-orange-600 text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <p class="text-sm font-medium text-gray-600">This Month</p>
                            <p class="text-2xl font-bold text-gray-900"><?php echo count(array_filter($donations, function($d) { return date('Y-m', strtotime($d['donation_date'])) === date('Y-m'); })); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filters -->
            <div class="bg-white rounded-xl shadow-sm p-6 mb-8 border border-gray-200">
                <form method="GET" class="grid grid-cols-1 md:grid-cols-6 gap-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Search</label>
                        <input type="text" name="search" value="<?php echo htmlspecialchars($filters['search']); ?>" 
                               placeholder="Name, email, purpose..." 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Type</label>
                        <select name="donation_type" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">All Types</option>
                            <option value="tithe" <?php echo $filters['donation_type'] === 'tithe' ? 'selected' : ''; ?>>Tithe</option>
                            <option value="offering" <?php echo $filters['donation_type'] === 'offering' ? 'selected' : ''; ?>>Offering</option>
                            <option value="special" <?php echo $filters['donation_type'] === 'special' ? 'selected' : ''; ?>>Special</option>
                            <option value="building_fund" <?php echo $filters['donation_type'] === 'building_fund' ? 'selected' : ''; ?>>Building Fund</option>
                            <option value="missions" <?php echo $filters['donation_type'] === 'missions' ? 'selected' : ''; ?>>Missions</option>
                            <option value="other" <?php echo $filters['donation_type'] === 'other' ? 'selected' : ''; ?>>Other</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                        <select name="payment_status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">All Status</option>
                            <option value="pending" <?php echo $filters['payment_status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="completed" <?php echo $filters['payment_status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                            <option value="failed" <?php echo $filters['payment_status'] === 'failed' ? 'selected' : ''; ?>>Failed</option>
                            <option value="cancelled" <?php echo $filters['payment_status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">From Date</label>
                        <input type="date" name="date_from" value="<?php echo htmlspecialchars($filters['date_from']); ?>" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">To Date</label>
                        <input type="date" name="date_to" value="<?php echo htmlspecialchars($filters['date_to']); ?>" 
                               class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    
                    <div class="flex items-end space-x-2">
                        <button type="submit" class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors duration-200">
                            <i class="fas fa-search mr-1"></i>
                            Filter
                        </button>
                        <a href="donations.php" class="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors duration-200">
                            <i class="fas fa-times mr-1"></i>
                            Clear
                        </a>
                    </div>
                </form>
            </div>

            <!-- Donations Table -->
            <div class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900">
                        Donations (<?php echo number_format($total_count); ?> total)
                    </h3>
                </div>
                
                <?php if (empty($donations)): ?>
                <div class="p-8 text-center">
                    <i class="fas fa-heart text-gray-300 text-4xl mb-4"></i>
                    <p class="text-gray-500 text-lg">No donations found</p>
                </div>
                <?php else: ?>
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Donor</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amount</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Payment</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($donations as $don): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div>
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo $don['is_anonymous'] ? 'Anonymous' : htmlspecialchars($don['donor_name']); ?>
                                        </div>
                                        <?php if (!$don['is_anonymous']): ?>
                                        <div class="text-sm text-gray-500"><?php echo htmlspecialchars($don['donor_email']); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm font-bold text-gray-900"><?php echo CURRENCY_SYMBOL; ?><?php echo number_format($don['amount'], 2); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                                        <?php echo ucfirst(str_replace('_', ' ', $don['donation_type'])); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="text-sm text-gray-900"><?php echo ucfirst(str_replace('_', ' ', $don['payment_method'])); ?></div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php
                                    $status_colors = [
                                        'pending' => 'bg-yellow-100 text-yellow-800',
                                        'completed' => 'bg-green-100 text-green-800',
                                        'failed' => 'bg-red-100 text-red-800',
                                        'cancelled' => 'bg-gray-100 text-gray-800'
                                    ];
                                    $color_class = $status_colors[$don['payment_status']] ?? 'bg-gray-100 text-gray-800';
                                    ?>
                                    <span class="px-2 py-1 text-xs font-medium rounded-full <?php echo $color_class; ?>">
                                        <?php echo ucfirst($don['payment_status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo date('M j, Y', strtotime($don['donation_date'])); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <div class="flex space-x-2">
                                        <!-- Status Update Dropdown -->
                                        <div class="relative inline-block text-left">
                                            <button type="button" class="inline-flex items-center px-3 py-1 border border-gray-300 rounded-md text-sm bg-white text-gray-700 hover:bg-gray-50" onclick="toggleDropdown(<?php echo $don['id']; ?>)">
                                                Status
                                                <i class="fas fa-chevron-down ml-1 text-xs"></i>
                                            </button>
                                            <div id="dropdown-<?php echo $don['id']; ?>" class="hidden absolute right-0 z-10 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                                                <div class="py-1">
                                                    <a href="?action=update_status&id=<?php echo $don['id']; ?>&status=pending" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Mark as Pending</a>
                                                    <a href="?action=update_status&id=<?php echo $don['id']; ?>&status=completed" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Mark as Completed</a>
                                                    <a href="?action=update_status&id=<?php echo $don['id']; ?>&status=failed" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Mark as Failed</a>
                                                    <a href="?action=update_status&id=<?php echo $don['id']; ?>&status=cancelled" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Mark as Cancelled</a>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <button onclick="viewDonation(<?php echo htmlspecialchars(json_encode($don)); ?>)" 
                                                class="text-indigo-600 hover:text-indigo-900">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        
                                        <a href="?action=delete&id=<?php echo $don['id']; ?>" 
                                           onclick="return confirm('Are you sure you want to delete this donation?')"
                                           class="text-red-600 hover:text-red-900">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                <div class="px-6 py-4 border-t border-gray-200">
                    <div class="flex items-center justify-between">
                        <div class="text-sm text-gray-700">
                            Showing <?php echo (($page - 1) * $limit) + 1; ?> to <?php echo min($page * $limit, $total_count); ?> of <?php echo $total_count; ?> results
                        </div>
                        <div class="flex space-x-2">
                            <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>&<?php echo http_build_query($filters); ?>" 
                               class="px-3 py-2 border border-gray-300 rounded-md text-sm bg-white text-gray-700 hover:bg-gray-50">
                                Previous
                            </a>
                            <?php endif; ?>
                            
                            <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                            <a href="?page=<?php echo $i; ?>&<?php echo http_build_query($filters); ?>" 
                               class="px-3 py-2 border rounded-md text-sm <?php echo $i === $page ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'; ?>">
                                <?php echo $i; ?>
                            </a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page + 1; ?>&<?php echo http_build_query($filters); ?>" 
                               class="px-3 py-2 border border-gray-300 rounded-md text-sm bg-white text-gray-700 hover:bg-gray-50">
                                Next
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Donation Details Modal -->
<div id="donationModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <div class="flex items-center justify-between mb-4">
                <h3 class="text-lg font-semibold text-gray-900">Donation Details</h3>
                <button onclick="closeDonationModal()" class="text-gray-400 hover:text-gray-600">
                    <i class="fas fa-times text-xl"></i>
                </button>
            </div>
            <div id="donationDetails" class="space-y-4">
                <!-- Details will be populated by JavaScript -->
            </div>
        </div>
    </div>
</div>

<script>
function toggleDropdown(id) {
    const dropdown = document.getElementById('dropdown-' + id);
    dropdown.classList.toggle('hidden');
    
    // Close other dropdowns
    document.querySelectorAll('[id^="dropdown-"]').forEach(el => {
        if (el.id !== 'dropdown-' + id) {
            el.classList.add('hidden');
        }
    });
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    if (!event.target.closest('[onclick^="toggleDropdown"]')) {
        document.querySelectorAll('[id^="dropdown-"]').forEach(el => {
            el.classList.add('hidden');
        });
    }
});

function viewDonation(donation) {
    const modal = document.getElementById('donationModal');
    const details = document.getElementById('donationDetails');
    
    const statusColors = {
        'pending': 'bg-yellow-100 text-yellow-800',
        'completed': 'bg-green-100 text-green-800',
        'failed': 'bg-red-100 text-red-800',
        'cancelled': 'bg-gray-100 text-gray-800'
    };
    
    details.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700">Donor Name</label>
                <p class="mt-1 text-sm text-gray-900">${donation.is_anonymous == 1 ? 'Anonymous' : donation.donor_name}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Email</label>
                <p class="mt-1 text-sm text-gray-900">${donation.is_anonymous == 1 ? 'Hidden' : donation.donor_email}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Phone</label>
                <p class="mt-1 text-sm text-gray-900">${donation.donor_phone || 'Not provided'}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Amount</label>
                <p class="mt-1 text-lg font-bold text-gray-900"><?php echo CURRENCY_SYMBOL; ?>${parseFloat(donation.amount).toFixed(2)}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Donation Type</label>
                <p class="mt-1 text-sm text-gray-900">${donation.donation_type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Payment Method</label>
                <p class="mt-1 text-sm text-gray-900">${donation.payment_method.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Status</label>
                <span class="mt-1 inline-block px-2 py-1 text-xs font-medium rounded-full ${statusColors[donation.payment_status] || 'bg-gray-100 text-gray-800'}">
                    ${donation.payment_status.charAt(0).toUpperCase() + donation.payment_status.slice(1)}
                </span>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700">Donation Date</label>
                <p class="mt-1 text-sm text-gray-900">${new Date(donation.donation_date).toLocaleDateString()}</p>
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700">Purpose</label>
                <p class="mt-1 text-sm text-gray-900">${donation.donation_purpose || 'Not specified'}</p>
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700">Transaction ID</label>
                <p class="mt-1 text-sm text-gray-900 font-mono">${donation.transaction_id || 'Not available'}</p>
            </div>
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700">Notes</label>
                <p class="mt-1 text-sm text-gray-900">${donation.notes || 'No notes'}</p>
            </div>
        </div>
    `;
    
    modal.classList.remove('hidden');
}

function closeDonationModal() {
    document.getElementById('donationModal').classList.add('hidden');
}
</script>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
