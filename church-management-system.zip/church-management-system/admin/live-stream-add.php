<?php
require_once '../config/config.php';
require_once '../classes/LiveStream.php';
require_once '../classes/Event.php';
require_once '../classes/Member.php';

use App\Database;
use App\LiveStream;
use App\Event;
use App\Member;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$liveStream = new LiveStream($db);
$event = new Event($db);

// Get events and sermons for dropdown
$events = $event->getAll(1, 100); // Get all events
$sermons = $db->query("SELECT id, title FROM sermons ORDER BY sermon_date DESC LIMIT 100")->fetchAll(\PDO::FETCH_ASSOC);

$error = '';
$success = '';

if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $title = sanitizeInput($_POST['title'] ?? '');
        $description = sanitizeInput($_POST['description'] ?? '');
        $stream_url = sanitizeInput($_POST['stream_url'] ?? '');
        $stream_type = $_POST['stream_type'] ?? 'youtube';
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        $event_id = !empty($_POST['event_id']) ? (int)$_POST['event_id'] : null;
        $sermon_id = !empty($_POST['sermon_id']) ? (int)$_POST['sermon_id'] : null;

        // Validation
        $validation_errors = [];
        
        // Validate title
        if (empty($title)) {
            $validation_errors[] = 'Stream title is required.';
        } elseif (!preg_match('/^[A-Za-z0-9\s\-\_\.\,\!\?\'\"]+$/', $title)) {
            $validation_errors[] = 'Stream title can only contain letters, numbers, and basic punctuation.';
        }
        
        // Validate stream URL
        if (empty($stream_url)) {
            $validation_errors[] = 'Stream URL is required.';
        } elseif (!filter_var($stream_url, FILTER_VALIDATE_URL)) {
            $validation_errors[] = 'Please enter a valid URL for the stream.';
        } else {
            // Validate specific stream type URLs
            if ($stream_type === 'youtube' && !preg_match('/^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/', $stream_url)) {
                $validation_errors[] = 'Please enter a valid YouTube URL.';
            } elseif ($stream_type === 'vimeo' && !preg_match('/^(https?:\/\/)?(www\.)?vimeo\.com\/.+/', $stream_url)) {
                $validation_errors[] = 'Please enter a valid Vimeo URL.';
            } elseif ($stream_type === 'hls' && !preg_match('/\.m3u8$/i', $stream_url)) {
                $validation_errors[] = 'HLS URLs must end with .m3u8';
            }
        }
        
        // Validate stream type
        $valid_stream_types = ['youtube', 'vimeo', 'hls', 'other'];
        if (!in_array($stream_type, $valid_stream_types)) {
            $validation_errors[] = 'Invalid stream type selected.';
        }
        
        // Validate description length if provided
        if (!empty($description) && strlen($description) > 5000) {
            $validation_errors[] = 'Description must be less than 5000 characters.';
        }

        if (!empty($validation_errors)) {
            $error = implode(' ', $validation_errors);
        } else {
            $liveStream->title = $title;
            $liveStream->description = $description;
            $liveStream->stream_url = $stream_url;
            $liveStream->stream_type = $stream_type;
            $liveStream->is_active = $is_active;
            $liveStream->event_id = $event_id;
            $liveStream->sermon_id = $sermon_id;
            $liveStream->created_by = $_SESSION['user_id'];

            if ($liveStream->create()) {
                $success = 'Live stream created successfully!';
                logActivity('live_stream_add', 'live_streams', $liveStream->id);

                // Send email notification to all members if stream is active
                if ($is_active) {
                    $emailTitle = 'New Live Stream Available';
                    $descriptionHtml = $description ? '<p>' . htmlspecialchars($description) . '</p>' : '';
                    $emailContent = buildNotificationEmail(
                        $emailTitle,
                        "<p>Dear {member_first_name},</p>
                        <p>A new live stream has been added: <strong>" . $title . "</strong></p>
                        " . $descriptionHtml . "
                        <p>You can watch the live stream by clicking the button below.</p>",
                        'Watch Live Stream',
                        BASE_URL . 'live-streaming.php'
                    );
                    
                    $notificationResult = notifyAllMembers($emailTitle, $emailContent, 'live_stream');
                    
                    if ($notificationResult['success']) {
                        $success .= " Email notifications sent to {$notificationResult['sent']} members.";
                    }
                }

                // Clear form data
                $_POST = [];
            } else {
                $error = 'Failed to create live stream. Please try again.';
            }
        }
    }
}
?>
<?php
$pageTitle = "Add Live Stream";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Live Streams', 'url' => 'live-streams.php'],
    ['name' => 'Add Stream']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        Add New Live Stream
                    </h2>
                    <p class="text-gray-600 mt-1">Create a new live stream for events or sermons</p>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <a href="live-streams.php" class="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Live Streams
                    </a>
                </div>
            </div>
        </div>

        <div class="max-w-3xl mx-auto">
            <?php if ($error): ?>
                <div class="mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="mb-4 bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Stream Information</h3>

                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="title" class="block text-sm font-medium text-gray-700">Stream Title *</label>
                            <input type="text" id="title" name="title" required
                                   pattern="[A-Za-z0-9\s\-\_\.\,\!\?'\"]+"
                                   title="Only letters, numbers, and basic punctuation allowed"
                                   maxlength="200"
                                   value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>

                        <div>
                            <label for="stream_type" class="block text-sm font-medium text-gray-700">Stream Type</label>
                            <select id="stream_type" name="stream_type" required
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="youtube" <?php echo ($_POST['stream_type'] ?? '') === 'youtube' ? 'selected' : ''; ?>>YouTube Live</option>
                                <option value="vimeo" <?php echo ($_POST['stream_type'] ?? '') === 'vimeo' ? 'selected' : ''; ?>>Vimeo Live</option>
                                <option value="hls" <?php echo ($_POST['stream_type'] ?? '') === 'hls' ? 'selected' : ''; ?>>HLS Stream</option>
                                <option value="other" <?php echo ($_POST['stream_type'] ?? '') === 'other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>

                        <div>
                            <label for="stream_url" class="block text-sm font-medium text-gray-700">Stream URL *</label>
                            <input type="url" id="stream_url" name="stream_url" required
                                   pattern="https?://.+"
                                   title="Please enter a valid URL starting with http:// or https://"
                                   value="<?php echo htmlspecialchars($_POST['stream_url'] ?? ''); ?>"
                                   placeholder="https://youtube.com/watch?v=..."
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <p class="mt-2 text-sm text-gray-500">Enter the full URL of the live stream (must start with http:// or https://)</p>
                        </div>

                        <div>
                            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                            <textarea id="description" name="description" rows="4"
                                      maxlength="5000"
                                      class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                            <p class="mt-2 text-sm text-gray-500">Maximum 5000 characters</p>
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Association</h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="event_id" class="block text-sm font-medium text-gray-700">Related Event (Optional)</label>
                            <select id="event_id" name="event_id"
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="">Select Event</option>
                                <?php foreach ($events as $e): ?>
                                    <option value="<?php echo $e['id']; ?>" <?php echo ($_POST['event_id'] ?? '') == $e['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($e['title']); ?> (<?php echo formatDateTime($e['start_datetime'], 'M j, Y g:i A'); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div>
                            <label for="sermon_id" class="block text-sm font-medium text-gray-700">Related Sermon (Optional)</label>
                            <select id="sermon_id" name="sermon_id"
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="">Select Sermon</option>
                                <?php foreach ($sermons as $s): ?>
                                    <option value="<?php echo $s['id']; ?>" <?php echo ($_POST['sermon_id'] ?? '') == $s['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($s['title']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Settings</h3>

                    <div class="space-y-4">
                        <div class="flex items-center">
                            <input type="checkbox" id="is_active" name="is_active" value="1"
                                   <?php echo (!isset($_POST['is_active']) || $_POST['is_active']) ? 'checked' : ''; ?>
                                   class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                            <label for="is_active" class="ml-2 block text-sm text-gray-900">
                                Stream is currently active and visible to viewers
                            </label>
                        </div>
                        <p class="text-sm text-gray-500">Note: Active streams will appear on the <a href="../live-streaming.php" class="text-indigo-600 hover:underline" target="_blank">public live streaming page</a></p>
                    </div>
                </div>

                <div class="flex justify-end space-x-3">
                    <a href="live-streams.php" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                        Cancel
                    </a>
                    <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                        Create Live Stream
                    </button>
                </div>
            </form>
        </div>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>