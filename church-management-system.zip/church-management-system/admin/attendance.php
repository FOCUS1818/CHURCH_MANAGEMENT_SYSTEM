<?php
/**
 * Church Management System
 * Attendance Management - Member Based
 */

require_once '../config/config.php';
require_once '../classes/Database.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
global $db;

$error = '';
$success = '';

// Get filter for member status
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'active';

// Get members based on status filter
if ($status_filter === 'all') {
    $stmt = $db->query("SELECT id, first_name, last_name, phone, photo, membership_status FROM members ORDER BY first_name, last_name");
} else {
    $stmt = $db->prepare("SELECT id, first_name, last_name, phone, photo, membership_status FROM members WHERE membership_status = ? ORDER BY first_name, last_name");
    $stmt->execute([$status_filter]);
}
$members = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get available services/dates for attendance
try {
    $services = $db->query("SELECT DISTINCT DATE(start_datetime) as service_date FROM events WHERE start_datetime >= DATE_SUB(NOW(), INTERVAL 3 MONTH) ORDER BY service_date DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $services = [];
}

// If no services exist, create default ones
if (empty($services)) {
    // Create some default service dates for the past weeks
    $default_services = [];
    for ($i = 0; $i < 12; $i++) {
        $default_services[] = date('Y-m-d', strtotime("-{$i} weeks Wednesday"));
    }
    $services = array_map(function($d) { return ['service_date' => $d]; }, $default_services);
}

// Get selected date
$selected_date = isset($_GET['service_date']) ? $_GET['service_date'] : date('Y-m-d');

// Handle attendance submission
if ($_POST && isset($_POST['mark_attendance'])) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $service_date = isset($_POST['service_date']) ? $_POST['service_date'] : '';
        $present_member_ids = isset($_POST['present_members']) ? $_POST['present_members'] : [];
        
        if (empty($service_date)) {
            $error = 'Please select a service date.';
        } else {
            // First, get or create event for this date
            $stmt = $db->prepare("SELECT id FROM events WHERE DATE(start_datetime) = ? LIMIT 1");
            $stmt->execute([$service_date]);
            $event = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($event) {
                $event_id = $event['id'];
            } else {
                // Create a temporary event for this service date
                $stmt = $db->prepare("INSERT INTO events (title, start_datetime, end_datetime, location, description, created_by) VALUES (?, ?, ?, ?, ?, ?)");
                $title = 'Church Service - ' . date('F j, Y', strtotime($service_date));
                $stmt->execute([$title, $service_date . ' 09:00:00', $service_date . ' 11:00:00', 'Main Sanctuary', 'Weekly Church Service', $_SESSION['user_id']]);
                $event_id = $db->lastInsertId();
            }
            
            // Delete existing attendance for this event
            $stmt = $db->prepare("DELETE FROM attendance WHERE event_id = ?");
            $stmt->execute([$event_id]);
            
            // Insert new attendance records
            if (!empty($present_member_ids)) {
                $stmt = $db->prepare("INSERT INTO attendance (event_id, member_id, attended, check_in_time) VALUES (?, ?, ?, NOW())");
                foreach ($present_member_ids as $member_id) {
                    $stmt->execute([$event_id, $member_id, 1]);
                }
            }
            
            $success = 'Attendance marked successfully for ' . date('F j, Y', strtotime($service_date)) . '!';
            logActivity('create', 'attendance', $event_id);
        }
    }
}

// Get attendance records for selected date
$attendance_records = [];
if ($selected_date) {
    $stmt = $db->prepare("
        SELECT a.*, m.first_name, m.last_name, m.phone, m.photo
        FROM attendance a 
        JOIN members m ON a.member_id = m.id 
        WHERE DATE(a.check_in_time) = ? OR DATE(a.created_at) = ?
        ORDER BY m.first_name, m.last_name
    ");
    $stmt->execute([$selected_date, $selected_date]);
    $attendance_records = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get attendance stats per member
$member_attendance_stats = [];
$stmt = $db->query("
    SELECT m.id, m.first_name, m.last_name, 
           COUNT(a.id) as total_attendance,
           (SELECT COUNT(DISTINCT DATE(a2.check_in_time)) FROM attendance a2 WHERE a2.member_id = m.id AND a2.attended = 1) as weeks_attended
    FROM members m
    LEFT JOIN attendance a ON m.id = a.member_id AND a.attended = 1
    GROUP BY m.id
    ORDER BY weeks_attended DESC, m.first_name
    LIMIT 20
");
$member_attendance_stats = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php
$pageTitle = "Attendance";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Attendance']
];

ob_start();
?>
    <div class="animate-fade-in">
        <div class="px-4 py-6 sm:px-0">
            <div class="mb-6">
                <h1 class="text-2xl font-bold text-gray-900">Member Attendance</h1>
                <p class="text-gray-600 mt-1">Track and manage member attendance</p>
            </div>

            <?php if ($success): ?>
                <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md mb-6">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Mark Attendance -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-lg font-semibold mb-4">Mark Attendance</h2>
                    <form method="POST">
                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                        <input type="hidden" name="mark_attendance" value="1">
                        
                        <div class="mb-4">
                            <label class="block text-sm font-medium text-gray-700 mb-2">Select Service Date *</label>
                            <input type="date" name="service_date" value="<?php echo $selected_date; ?>" required
                                   max="<?php echo date('Y-m-d'); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                        </div>
                        
                        <div class="mb-4">
                            <div class="flex justify-between items-center mb-2">
                                <label class="block text-sm font-medium text-gray-700">Select Present Members</label>
                                <div class="flex items-center gap-2">
                                    <select id="status-filter" onchange="window.location.href='?status='+this.value" class="text-xs border border-gray-300 rounded px-2 py-1">
                                        <option value="active" <?php echo $status_filter === 'active' ? 'selected' : ''; ?>>Active</option>
                                        <option value="visitor" <?php echo $status_filter === 'visitor' ? 'selected' : ''; ?>>Visitors</option>
                                        <option value="all" <?php echo $status_filter === 'all' ? 'selected' : ''; ?>>All Members</option>
                                    </select>
                                    <span class="text-sm text-gray-500">Total: <?php echo count($members); ?> members</span>
                                </div>
                            </div>
                            
                            <!-- Select All / Deselect All -->
                            <div class="flex gap-2 mb-2">
                                <button type="button" onclick="selectAllMembers()" class="text-xs bg-gray-100 px-2 py-1 rounded hover:bg-gray-200">Select All</button>
                                <button type="button" onclick="deselectAllMembers()" class="text-xs bg-gray-100 px-2 py-1 rounded hover:bg-gray-200">Deselect All</button>
                            </div>
                            
                            <div class="border border-gray-300 rounded-md max-h-80 overflow-y-auto p-3 space-y-2">
                                <?php if (count($members) > 0): ?>
                                    <?php foreach ($members as $member): ?>
                                        <label class="flex items-center space-x-3 cursor-pointer hover:bg-gray-50 p-1 rounded">
                                            <input type="checkbox" name="present_members[]" value="<?php echo $member['id']; ?>"
                                                <?php echo in_array($member['id'], array_column($attendance_records, 'member_id')) ? 'checked' : ''; ?>
                                                class="rounded text-indigo-600 focus:ring-indigo-500 member-checkbox">
                                            <?php if ($member['photo']): ?>
                                                <img src="<?php echo htmlspecialchars($member['photo']); ?>" class="w-8 h-8 rounded-full object-cover">
                                            <?php else: ?>
                                                <div class="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center">
                                                    <span class="text-xs font-bold text-indigo-600"><?php echo strtoupper(substr($member['first_name'], 0, 1) . substr($member['last_name'], 0, 1)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                            <span class="text-gray-700"><?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?></span>
                                            <?php if (isset($member['membership_status'])): ?>
                                                <span class="text-xs px-2 py-0.5 rounded <?php echo $member['membership_status'] === 'active' ? 'bg-green-100 text-green-700' : ($member['membership_status'] === 'visitor' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-500'); ?>"><?php echo ucfirst($member['membership_status']); ?></span>
                                            <?php endif; ?>
                                            <?php if ($member['phone']): ?>
                                                <span class="text-xs text-gray-400"><?php echo htmlspecialchars($member['phone']); ?></span>
                                            <?php endif; ?>
                                        </label>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p class="text-gray-500 text-center py-4">No members found. <a href="member-add.php" class="text-indigo-600 hover:underline">Add members here</a></p>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <button type="submit" class="w-full bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                            Save Attendance
                        </button>
                    </form>
                </div>
                
                <!-- View Attendance Summary -->
                <div class="bg-white rounded-lg shadow p-6">
                    <h2 class="text-lg font-semibold mb-4">Today's Attendance</h2>
                    
                    <form method="GET" class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-2">View attendance for:</label>
                        <div class="flex gap-2">
                            <input type="date" name="service_date" value="<?php echo $selected_date; ?>" 
                                   max="<?php echo date('Y-m-d'); ?>"
                                   class="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                            <button type="submit" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700">
                                View
                            </button>
                        </div>
                    </form>
                    
                    <?php if ($selected_date && count($attendance_records) > 0): ?>
                        <div class="text-sm">
                            <p class="font-medium text-gray-700 mb-2">Present Members (<?php echo count($attendance_records); ?>):</p>
                            <div class="max-h-64 overflow-y-auto space-y-2">
                                <?php foreach ($attendance_records as $record): ?>
                                    <div class="flex items-center space-x-2 p-2 bg-green-50 rounded">
                                        <i class="fas fa-check text-green-500"></i>
                                        <span class="text-gray-700"><?php echo htmlspecialchars($record['first_name'] . ' ' . $record['last_name']); ?></span>
                                        <?php if ($record['phone']): ?>
                                            <span class="text-xs text-gray-400"><?php echo htmlspecialchars($record['phone']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php elseif ($selected_date): ?>
                        <p class="text-gray-500">No attendance records for <?php echo date('F j, Y', strtotime($selected_date)); ?>.</p>
                    <?php endif; ?>
                    
                    <!-- Member Attendance Stats -->
                    <div class="mt-6 pt-6 border-t">
                        <h3 class="text-md font-semibold mb-3">Most Regular Attendees</h3>
                        <div class="space-y-2">
                            <?php foreach ($member_attendance_stats as $stat): ?>
                                <div class="flex justify-between items-center text-sm">
                                    <span><?php echo htmlspecialchars($stat['first_name'] . ' ' . $stat['last_name']); ?></span>
                                    <span class="bg-indigo-100 text-indigo-600 px-2 py-1 rounded text-xs font-medium">
                                        <?php echo $stat['weeks_attended']; ?> weeks
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function selectAllMembers() {
            document.querySelectorAll('.member-checkbox').forEach(cb => cb.checked = true);
        }
        
        function deselectAllMembers() {
            document.querySelectorAll('.member-checkbox').forEach(cb => cb.checked = false);
        }
    </script>

<?php
$pageContent = ob_get_clean();
include '../includes/admin-layout.php';
?>
