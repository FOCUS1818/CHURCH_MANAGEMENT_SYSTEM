<?php
/**
 * Church Management System
 * Sermon Delete Handler
 */

require_once '../config/config.php';
require_once '../classes/Database.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Sermon ID is required.';
    header('Location: sermons.php');
    exit;
}

$sermon_id = (int)$_GET['id'];

// Verify CSRF token if present
if (isset($_GET['csrf_token'])) {
    if (!verifyCSRFToken($_GET['csrf_token'])) {
        $_SESSION['error'] = 'Invalid security token.';
        header('Location: sermons.php');
        exit;
    }
}

// Delete the sermon
try {
    // Get the sermon to check for notes_pdf
    $stmt = $db->prepare("SELECT notes_pdf FROM sermons WHERE id = ?");
    $stmt->execute([$sermon_id]);
    $sermon = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($sermon && $sermon['notes_pdf']) {
        $pdf_path = '../uploads/sermons/' . $sermon['notes_pdf'];
        if (file_exists($pdf_path)) {
            unlink($pdf_path);
        }
    }

    // Delete the sermon
    $stmt = $db->prepare("DELETE FROM sermons WHERE id = ?");
    
    if ($stmt->execute([$sermon_id])) {
        $_SESSION['success'] = 'Sermon deleted successfully!';
        logActivity('delete', 'sermons', $sermon_id);
    } else {
        $_SESSION['error'] = 'Failed to delete sermon.';
    }
} catch (PDOException $e) {
    $_SESSION['error'] = 'Error deleting sermon: ' . $e->getMessage();
}

header('Location: sermons.php');
exit;
