<?php
require_once '../config/config.php';
require_once '../classes/LiveStream.php';

use App\Database;
use App\LiveStream;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$liveStream = new LiveStream($db);

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$search = $_GET['search'] ?? '';
$isActive = isset($_GET['is_active']) ? (int)$_GET['is_active'] : null;

$liveStreams = $liveStream->getAll($page, 10, $search, $isActive);
$totalCount = $liveStream->getTotalCount($search, $isActive);
$paginationData = getPaginationData($page, $totalCount, 10);
?>
<?php
$pageTitle = "Live Streams";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Live Streams']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Live Streaming Management</h1>
                    <p class="text-gray-600 mt-1">Manage live streams for events and sermons</p>
                </div>
                <a href="live-stream-add.php" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 transition-colors duration-200">
                    <i class="fas fa-plus mr-2"></i>
                    Add Live Stream
                </a>
            </div>
        </div>

        <!-- Search and filters -->
        <div class="bg-white shadow rounded-lg mb-6">
            <div class="px-4 py-5 sm:p-6">
                <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <input type="text" name="search" placeholder="Search streams..."
                               value="<?php echo htmlspecialchars($search); ?>"
                               class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                    </div>
                    <div>
                        <select name="is_active" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">All Status</option>
                            <option value="1" <?php echo $isActive === 1 ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo $isActive === 0 ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="flex space-x-2">
                        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                            Search
                        </button>
                        <a href="live-streams.php" class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700">
                            Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Live streams table -->
        <div class="bg-white shadow overflow-hidden sm:rounded-md">
            <div class="px-4 py-5 sm:p-0">
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Stream</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Related To</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php foreach ($liveStreams as $stream): ?>
                            <tr>
                                <td class="px-6 py-4">
                                    <div>
                                        <div class="text-sm font-medium text-gray-900">
                                            <?php echo htmlspecialchars($stream['title']); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <?php echo htmlspecialchars(substr($stream['description'], 0, 100)) . (strlen($stream['description']) > 100 ? '...' : ''); ?>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full
                                        <?php
                                        switch($stream['stream_type']) {
                                            case 'youtube': echo 'bg-red-100 text-red-800'; break;
                                            case 'vimeo': echo 'bg-blue-100 text-blue-800'; break;
                                            case 'hls': echo 'bg-green-100 text-green-800'; break;
                                            default: echo 'bg-gray-100 text-gray-800';
                                        }
                                        ?>">
                                        <?php echo ucfirst($stream['stream_type']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php if ($stream['is_active']): ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                            Active
                                        </span>
                                    <?php else: ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                                            Inactive
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php if ($stream['event_title']): ?>
                                        Event: <?php echo htmlspecialchars($stream['event_title']); ?>
                                    <?php elseif ($stream['sermon_title']): ?>
                                        Sermon: <?php echo htmlspecialchars($stream['sermon_title']); ?>
                                    <?php else: ?>
                                        Standalone
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                    <?php echo formatDate($stream['created_at']); ?>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                    <a href="live-stream-edit.php?id=<?php echo $stream['id']; ?>" class="text-indigo-600 hover:text-indigo-900 mr-3">Edit</a>
                                    <a href="live-stream-delete.php?id=<?php echo $stream['id']; ?>"
                                       onclick="return confirm('Are you sure you want to delete this live stream?')"
                                       class="text-red-600 hover:text-red-900">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Pagination -->
        <?php if ($paginationData['total_pages'] > 1): ?>
            <div class="mt-6">
                <?php echo generatePagination($paginationData, 'live-streams.php'); ?>
            </div>
        <?php endif; ?>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>