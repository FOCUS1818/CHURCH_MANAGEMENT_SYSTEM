<?php
require_once '../config/config.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

// Get ministry ID from URL
$ministry_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if (!$ministry_id) {
    header('Location: ministries.php');
    exit();
}

// Get ministry information
$stmt = $db->prepare("SELECT * FROM ministries WHERE id = :id");
$stmt->bindParam(':id', $ministry_id);
$stmt->execute();
$ministry = $stmt->fetch(\PDO::FETCH_ASSOC);

if (!$ministry) {
    header('Location: ministries.php');
    exit();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = "Invalid CSRF token";
    } else {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'add_member':
                    $member_id = (int)$_POST['member_id'];
                    $role = sanitizeInput($_POST['role'] ?? '');
                    
                    // Check if member is already in ministry
                    $checkStmt = $db->prepare("SELECT id FROM ministry_members WHERE ministry_id = :ministry_id AND member_id = :member_id");
                    $checkStmt->bindParam(':ministry_id', $ministry_id);
                    $checkStmt->bindParam(':member_id', $member_id);
                    $checkStmt->execute();
                    
                    if ($checkStmt->rowCount() > 0) {
                        $error = "Member is already in this ministry";
                    } else {
                        $insertStmt = $db->prepare("INSERT INTO ministry_members (ministry_id, member_id, role, joined_date, is_active) VALUES (:ministry_id, :member_id, :role, CURDATE(), 1)");
                        $insertStmt->bindParam(':ministry_id', $ministry_id);
                        $insertStmt->bindParam(':member_id', $member_id);
                        $insertStmt->bindParam(':role', $role);
                        
                        if ($insertStmt->execute()) {
                            $success = "Member added to ministry successfully";
                            logActivity("Added member to ministry", "ministry_members", $db->lastInsertId());
                        } else {
                            $error = "Failed to add member to ministry";
                        }
                    }
                    break;
                    
                case 'update_member':
                    $ministry_member_id = (int)$_POST['ministry_member_id'];
                    $role = sanitizeInput($_POST['role'] ?? '');
                    $is_active = isset($_POST['is_active']) ? 1 : 0;
                    
                    $updateStmt = $db->prepare("UPDATE ministry_members SET role = :role, is_active = :is_active WHERE id = :id AND ministry_id = :ministry_id");
                    $updateStmt->bindParam(':role', $role);
                    $updateStmt->bindParam(':is_active', $is_active);
                    $updateStmt->bindParam(':id', $ministry_member_id);
                    $updateStmt->bindParam(':ministry_id', $ministry_id);
                    
                    if ($updateStmt->execute()) {
                        $success = "Member updated successfully";
                        logActivity("Updated ministry member", "ministry_members", $ministry_member_id);
                    } else {
                        $error = "Failed to update member";
                    }
                    break;
                    
                case 'remove_member':
                    $ministry_member_id = (int)$_POST['ministry_member_id'];
                    
                    $deleteStmt = $db->prepare("DELETE FROM ministry_members WHERE id = :id AND ministry_id = :ministry_id");
                    $deleteStmt->bindParam(':id', $ministry_member_id);
                    $deleteStmt->bindParam(':ministry_id', $ministry_id);
                    
                    if ($deleteStmt->execute()) {
                        $success = "Member removed from ministry successfully";
                        logActivity("Removed member from ministry", "ministry_members", $ministry_member_id);
                    } else {
                        $error = "Failed to remove member from ministry";
                    }
                    break;
            }
        }
    }
}

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

// Build query for ministry members
$query = "SELECT mm.*, m.first_name, m.last_name, m.email, m.phone, m.photo, m.membership_status 
          FROM ministry_members mm 
          JOIN members m ON mm.member_id = m.id 
          WHERE mm.ministry_id = :ministry_id";

$params = [':ministry_id' => $ministry_id];

if (!empty($search)) {
    $query .= " AND (m.first_name LIKE :search OR m.last_name LIKE :search OR m.email LIKE :search)";
    $params[':search'] = "%$search%";
}

if ($status !== '') {
    $query .= " AND mm.is_active = :status";
    $params[':status'] = $status;
}

$query .= " ORDER BY mm.is_active DESC, m.last_name, m.first_name";

// Get total count
$countQuery = str_replace("SELECT mm.*, m.first_name, m.last_name, m.email, m.phone, m.photo, m.membership_status", "SELECT COUNT(*) as total", $query);
$stmt = $db->prepare($countQuery);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$totalCount = $stmt->fetch(\PDO::FETCH_ASSOC)['total'];

// Get paginated results
$offset = ($page - 1) * 10;
$query .= " LIMIT 10 OFFSET $offset";

$stmt = $db->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$ministry_members = $stmt->fetchAll(\PDO::FETCH_ASSOC);

$paginationData = getPaginationData($page, $totalCount, 10);

// Get all active members not in this ministry for the add member dropdown
$availableMembersStmt = $db->prepare("
    SELECT m.id, m.first_name, m.last_name 
    FROM members m 
    WHERE m.membership_status = 'active' 
    AND m.id NOT IN (
        SELECT mm.member_id 
        FROM ministry_members mm 
        WHERE mm.ministry_id = :ministry_id AND mm.is_active = 1
    )
    ORDER BY m.first_name, m.last_name
");
$availableMembersStmt->bindParam(':ministry_id', $ministry_id);
$availableMembersStmt->execute();
$availableMembers = $availableMembersStmt->fetchAll(\PDO::FETCH_ASSOC);
?>
<?php
$pageTitle = htmlspecialchars($ministry['name']) . " Members";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Ministries', 'url' => 'ministries.php'],
    ['name' => htmlspecialchars($ministry['name']) . ' Members']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Breadcrumb -->
        <div class="px-4 py-4 sm:px-0">
            <nav class="flex" aria-label="Breadcrumb">
                <ol class="flex items-center space-x-4">
                    <li>
                        <div>
                            <a href="dashboard.php" class="text-gray-400 hover:text-gray-500">
                                <i class="fas fa-home"></i>
                            </a>
                        </div>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="fas fa-chevron-right text-gray-400 mr-4"></i>
                            <a href="ministries.php" class="text-sm font-medium text-gray-500 hover:text-gray-700">Ministries</a>
                        </div>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <i class="fas fa-chevron-right text-gray-400 mr-4"></i>
                            <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($ministry['name']); ?> Members</span>
                        </div>
                    </li>
                </ol>
            </nav>
        </div>

        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        <?php echo htmlspecialchars($ministry['name']); ?> Members
                    </h2>
                    <p class="mt-1 text-sm text-gray-500">
                        <?php echo htmlspecialchars($ministry['description']); ?>
                    </p>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <a href="ministries.php" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Ministries
                    </a>
                    <button onclick="openAddMemberModal()" class="ml-3 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                        <i class="fas fa-plus mr-2"></i>
                        Add Member
                    </button>
                </div>
            </div>
        </div>

        <!-- Success/Error Messages -->
        <?php if (isset($success)): ?>
            <div class="px-4 py-4 sm:px-0">
                <div class="bg-green-50 border border-green-200 rounded-md p-4">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-check-circle text-green-400"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-green-800"><?php echo htmlspecialchars($success); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="px-4 py-4 sm:px-0">
                <div class="bg-red-50 border border-red-200 rounded-md p-4">
                    <div class="flex">
                        <div class="flex-shrink-0">
                            <i class="fas fa-exclamation-circle text-red-400"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-red-800"><?php echo htmlspecialchars($error); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <!-- Filters -->
        <div class="bg-white shadow rounded-lg mb-6">
            <div class="px-4 py-5 sm:p-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Filter Members</h3>
                <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <input type="hidden" name="id" value="<?php echo $ministry_id; ?>">
                    <div>
                        <label for="search" class="block text-sm font-medium text-gray-700">Search</label>
                        <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>"
                               placeholder="Search by name or email..."
                               class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                    <div>
                        <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                        <select id="status" name="status" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <option value="">All Statuses</option>
                            <option value="1" <?php echo $status === '1' ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo $status === '0' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="flex items-end">
                        <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                            <i class="fas fa-search mr-2"></i>
                            Filter
                        </button>
                        <a href="ministry-members.php?id=<?php echo $ministry_id; ?>" class="ml-2 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                            Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Members list -->
        <div class="bg-white shadow overflow-hidden sm:rounded-md">
            <?php if (empty($ministry_members)): ?>
                <div class="text-center py-12">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">No members found</h3>
                    <p class="mt-1 text-sm text-gray-500">Get started by adding members to this ministry.</p>
                    <div class="mt-6">
                        <button onclick="openAddMemberModal()" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                            <i class="fas fa-plus mr-2"></i>
                            Add Member
                        </button>
                    </div>
                </div>
            <?php else: ?>
                <ul class="divide-y divide-gray-200">
                    <?php foreach ($ministry_members as $member): ?>
                        <li>
                            <div class="px-4 py-4 flex items-center justify-between">
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-12 w-12">
                                            <?php if ($member['photo']): ?>
                                                <img class="h-12 w-12 rounded-full object-cover" src="../uploads/<?php echo htmlspecialchars($member['photo']); ?>" alt="">
                                            <?php else: ?>
                                                <div class="h-12 w-12 rounded-full bg-indigo-500 flex items-center justify-center">
                                                    <span class="text-sm font-bold text-white"><?php echo strtoupper(substr($member['first_name'], 0, 1)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="ml-4 flex-1">
                                            <div class="flex items-center justify-between">
                                                <p class="text-sm font-medium text-indigo-600 truncate">
                                                    <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                                                </p>
                                                <div class="ml-2 flex-shrink-0 flex">
                                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $member['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                                        <?php echo $member['is_active'] ? 'Active' : 'Inactive'; ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="mt-2 flex items-center text-sm text-gray-500">
                                                <p class="truncate">
                                                    <?php if ($member['role']): ?>
                                                        <strong>Role:</strong> <?php echo htmlspecialchars($member['role']); ?> •
                                                    <?php endif; ?>
                                                    <?php echo htmlspecialchars($member['email']); ?>
                                                    <?php if ($member['phone']): ?>
                                                        • <?php echo htmlspecialchars($member['phone']); ?>
                                                    <?php endif; ?>
                                                </p>
                                            </div>
                                            <div class="mt-1 text-xs text-gray-400">
                                                Joined: <?php echo formatDate($member['joined_date']); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ml-4 flex-shrink-0 flex space-x-2">
                                    <button onclick="editMember(<?php echo htmlspecialchars(json_encode($member)); ?>)" class="text-indigo-600 hover:text-indigo-900 text-sm font-medium">
                                        <i class="fas fa-edit mr-1"></i>
                                        Edit
                                    </button>
                                    <form method="POST" class="inline" onsubmit="return confirm('Are you sure you want to remove this member from the ministry?')">
                                        <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                        <input type="hidden" name="action" value="remove_member">
                                        <input type="hidden" name="ministry_member_id" value="<?php echo $member['id']; ?>">
                                        <button type="submit" class="text-red-600 hover:text-red-900 text-sm font-medium">
                                            <i class="fas fa-trash mr-1"></i>
                                            Remove
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <!-- Pagination -->
                <?php if ($paginationData['total_pages'] > 1): ?>
                    <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                        <?php echo generatePagination($paginationData, 'ministry-members.php?id=' . $ministry_id); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Add Member Modal -->
    <div id="addMemberModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Add Member to Ministry</h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="action" value="add_member">
                    
                    <div class="space-y-4">
                        <div>
                            <label for="member_id" class="block text-sm font-medium text-gray-700">Select Member *</label>
                            <select id="member_id" name="member_id" required 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="">Choose a member</option>
                                <?php foreach ($availableMembers as $availableMember): ?>
                                    <option value="<?php echo $availableMember['id']; ?>">
                                        <?php echo htmlspecialchars($availableMember['first_name'] . ' ' . $availableMember['last_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="role" class="block text-sm font-medium text-gray-700">Role</label>
                            <input type="text" id="role" name="role" 
                                   placeholder="e.g., Volunteer, Leader, Coordinator"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                    </div>
                    
                    <div class="mt-6 flex justify-end space-x-3">
                        <button type="button" onclick="closeAddMemberModal()" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                            Cancel
                        </button>
                        <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                            Add Member
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Member Modal -->
    <div id="editMemberModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Edit Member</h3>
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="action" value="update_member">
                    <input type="hidden" name="ministry_member_id" id="editMembershipId">
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Member</label>
                            <p id="editMemberName" class="mt-1 text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-md"></p>
                        </div>
                        
                        <div>
                            <label for="editRole" class="block text-sm font-medium text-gray-700">Role</label>
                            <input type="text" id="editRole" name="role" 
                                   placeholder="e.g., Volunteer, Leader, Coordinator"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div class="flex items-center">
                            <input type="checkbox" id="editIsActive" name="is_active" value="1"
                                   class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                            <label for="editIsActive" class="ml-2 block text-sm text-gray-900">
                                Active Member
                            </label>
                        </div>
                    </div>
                    
                    <div class="mt-6 flex justify-end space-x-3">
                        <button type="button" onclick="closeEditMemberModal()" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                            Cancel
                        </button>
                        <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                            Update Member
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function openAddMemberModal() {
            document.getElementById('addMemberModal').classList.remove('hidden');
        }

        function closeAddMemberModal() {
            document.getElementById('addMemberModal').classList.add('hidden');
        }

        function editMember(member) {
            document.getElementById('editMemberModal').classList.remove('hidden');
            document.getElementById('editMembershipId').value = member.id;
            document.getElementById('editMemberName').textContent = member.first_name + ' ' + member.last_name;
            document.getElementById('editRole').value = member.role || '';
            document.getElementById('editIsActive').checked = member.is_active == 1;
        }

        function closeEditMemberModal() {
            document.getElementById('editMemberModal').classList.add('hidden');
        }

        // Close modals when clicking outside
        document.getElementById('addMemberModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeAddMemberModal();
            }
        });

        document.getElementById('editMemberModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeEditMemberModal();
            }
        });
    </script>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>