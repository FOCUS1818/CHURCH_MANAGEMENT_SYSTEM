<?php
/**
 * Church Management System
 * Event Delete Handler
 */

require_once '../config/config.php';
require_once '../classes/Database.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Event ID is required.';
    header('Location: events.php');
    exit;
}

$event_id = (int)$_GET['id'];

// Verify CSRF token if present
if (isset($_GET['csrf_token'])) {
    if (!verifyCSRFToken($_GET['csrf_token'])) {
        $_SESSION['error'] = 'Invalid security token.';
        header('Location: events.php');
        exit;
    }
}

// Delete the event
try {
    // First delete related attendance records
    $stmt = $db->prepare("DELETE FROM attendance WHERE event_id = ?");
    $stmt->execute([$event_id]);
    
    // Delete the event
    $stmt = $db->prepare("DELETE FROM events WHERE id = ?");
    
    if ($stmt->execute([$event_id])) {
        $_SESSION['success'] = 'Event deleted successfully!';
        logActivity('delete', 'events', $event_id);
    } else {
        $_SESSION['error'] = 'Failed to delete event.';
    }
} catch (PDOException $e) {
    $_SESSION['error'] = 'Error deleting event: ' . $e->getMessage();
}

header('Location: events.php');
exit;
