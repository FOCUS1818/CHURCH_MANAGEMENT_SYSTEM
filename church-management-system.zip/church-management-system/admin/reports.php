<?php
require_once '../config/config.php';
require_once '../classes/Member.php';
require_once '../classes/Event.php';

use App\Database;
use App\Member;
use App\Event;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$member = new Member($db);
$event = new Event($db);

// Get date range for reports
$dateFrom = $_GET['date_from'] ?? date('Y-m-01'); // First day of current month
$dateTo = $_GET['date_to'] ?? date('Y-m-t'); // Last day of current month

// Get member statistics
$memberStats = $member->getStatistics();

// Get event statistics
$eventStats = $event->getStatistics();

// Get recent activity
$recentActivity = $db->query("
    SELECT al.*, u.first_name, u.last_name 
    FROM activity_logs al 
    LEFT JOIN users u ON al.user_id = u.id 
    ORDER BY al.created_at DESC 
    LIMIT 10
")->fetchAll(\PDO::FETCH_ASSOC);

// Get membership growth over time
$membershipGrowth = $db->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
    FROM members 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH) 
    GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
    ORDER BY month
")->fetchAll(\PDO::FETCH_ASSOC);

// Get event attendance trends
$stmt = $db->prepare("
    SELECT e.event_type, COUNT(a.id) as attendance_count
    FROM events e
    LEFT JOIN attendance a ON e.id = a.event_id AND a.attended = 1
    WHERE e.start_datetime >= ? AND e.start_datetime <= ?
    GROUP BY e.event_type
");
$stmt->execute([$dateFrom, $dateTo]);
$eventAttendance = $stmt->fetchAll(\PDO::FETCH_ASSOC);

// Get top ministries by member count
$topMinistries = $db->query("
    SELECT m.name, COUNT(mm.member_id) as member_count 
    FROM ministries m 
    LEFT JOIN ministry_members mm ON m.id = mm.ministry_id AND mm.is_active = 1 
    WHERE m.is_active = 1 
    GROUP BY m.id, m.name 
    ORDER BY member_count DESC 
    LIMIT 5
")->fetchAll(\PDO::FETCH_ASSOC);
?>
<?php
$pageTitle = "Reports";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Reports']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        Reports & Analytics
                    </h2>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <form method="GET" class="flex space-x-2">
                        <input type="date" name="date_from" value="<?php echo $dateFrom; ?>"
                               class="border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <input type="date" name="date_to" value="<?php echo $dateTo; ?>"
                               class="border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                            Update
                        </button>
                    </form>
                    <button onclick="window.open('export-reports.php?date_from=<?php echo $dateFrom; ?>&date_to=<?php echo $dateTo; ?>', '_blank', 'width=800,height=600')" class="ml-2 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                        <i class="fas fa-download mr-2"></i>
                        Export PDF
                    </button>
                </div>
            </div>
        </div>

        <!-- Stats Overview -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="p-5">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                            </svg>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500 truncate">Total Members</dt>
                                <dd class="text-lg font-medium text-gray-900"><?php echo $memberStats['total']; ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="p-5">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500 truncate">Total Events</dt>
                                <dd class="text-lg font-medium text-gray-900"><?php echo $eventStats['total']; ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="p-5">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                            </svg>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500 truncate">Active Members</dt>
                                <dd class="text-lg font-medium text-gray-900"><?php echo $memberStats['active']; ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white overflow-hidden shadow rounded-lg">
                <div class="p-5">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <svg class="h-6 w-6 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <div class="ml-5 w-0 flex-1">
                            <dl>
                                <dt class="text-sm font-medium text-gray-500 truncate">New This Month</dt>
                                <dd class="text-lg font-medium text-gray-900"><?php echo $memberStats['new_this_month']; ?></dd>
                            </dl>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Membership Growth Chart -->
            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Membership Growth (Last 12 Months)</h3>
                <canvas id="membershipChart" width="400" height="200"></canvas>
            </div>

            <!-- Event Attendance Chart -->
            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Event Attendance by Type</h3>
                <canvas id="attendanceChart" width="400" height="200"></canvas>
            </div>

            <!-- Top Ministries -->
            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Top Ministries by Member Count</h3>
                <div class="space-y-3">
                    <?php foreach ($topMinistries as $ministry): ?>
                        <div class="flex items-center justify-between">
                            <span class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($ministry['name']); ?></span>
                            <span class="text-sm text-gray-500"><?php echo $ministry['member_count']; ?> members</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-medium text-gray-900 mb-4">Recent Activity</h3>
                <div class="space-y-3">
                    <?php foreach ($recentActivity as $activity): ?>
                        <div class="flex items-start">
                            <div class="flex-shrink-0">
                                <div class="h-2 w-2 bg-indigo-400 rounded-full mt-2"></div>
                            </div>
                            <div class="ml-3">
                                <p class="text-sm text-gray-900">
                                    <span class="font-medium"><?php echo htmlspecialchars($activity['first_name'] . ' ' . $activity['last_name']); ?></span>
                                    <?php echo htmlspecialchars($activity['action']); ?>
                                    <?php if ($activity['table_name']): ?>
                                        in <?php echo htmlspecialchars($activity['table_name']); ?>
                                    <?php endif; ?>
                                </p>
                                <p class="text-xs text-gray-500"><?php echo formatDateTime($activity['created_at']); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Membership Growth Chart
        const membershipCtx = document.getElementById('membershipChart').getContext('2d');
        const membershipData = <?php echo json_encode($membershipGrowth); ?>;
        
        new Chart(membershipCtx, {
            type: 'line',
            data: {
                labels: membershipData.map(item => item.month),
                datasets: [{
                    label: 'New Members',
                    data: membershipData.map(item => item.count),
                    borderColor: 'rgb(99, 102, 241)',
                    backgroundColor: 'rgba(99, 102, 241, 0.1)',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Event Attendance Chart
        const attendanceCtx = document.getElementById('attendanceChart').getContext('2d');
        const attendanceData = <?php echo json_encode($eventAttendance); ?>;
        
        new Chart(attendanceCtx, {
            type: 'doughnut',
            data: {
                labels: attendanceData.map(item => item.event_type),
                datasets: [{
                    data: attendanceData.map(item => item.attendance_count),
                    backgroundColor: [
                        'rgb(99, 102, 241)',
                        'rgb(16, 185, 129)',
                        'rgb(245, 158, 11)',
                        'rgb(239, 68, 68)',
                        'rgb(139, 92, 246)'
                    ]
                }]
            },
            options: {
                responsive: true
            }
        });
    </script>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
