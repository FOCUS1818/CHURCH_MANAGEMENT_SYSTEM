<?php
/**
 * Church Management System
 * Small Groups Management
 */

require_once '../config/config.php';
require_once '../classes/Database.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
global $db;

$error = '';
$success = '';

// Handle form submission
if ($_POST && isset($_POST['add_group'])) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request.';
    } else {
        $group_name = sanitizeInput($_POST['group_name'] ?? '');
        $meeting_day = sanitizeInput($_POST['meeting_day'] ?? '');
        $meeting_time = sanitizeInput($_POST['meeting_time'] ?? '');
        $location = sanitizeInput($_POST['location'] ?? '');
        $description = sanitizeInput($_POST['description'] ?? '');
        
        if (empty($group_name)) {
            $error = 'Group name is required.';
        } else {
            $stmt = $db->prepare("INSERT INTO small_groups (group_name, meeting_day, meeting_time, location, description) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$group_name, $meeting_day, $meeting_time, $location, $description])) {
                $success = 'Small group added successfully!';
                logActivity('create', 'small_groups', $db->lastInsertId());
            } else {
                $error = 'Failed to add small group.';
            }
        }
    }
}

// Handle delete
if (isset($_POST['delete_id']) && verifyCSRFToken($_POST['csrf_token'] ?? '')) {
    $stmt = $db->prepare("DELETE FROM small_groups WHERE id = ?");
    $stmt->execute([$_POST['delete_id']]);
    logActivity('delete', 'small_groups', $_POST['delete_id']);
    $success = 'Small group deleted successfully!';
}

// Get all small groups
$stmt = $db->query("SELECT * FROM small_groups ORDER BY group_name");
$groups = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php
$pageTitle = "Small Groups";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Small Groups']
];

ob_start();
?>
    <div class="animate-fade-in">
        <div class="px-4 py-6 sm:px-0">
            <div class="flex justify-between items-center mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900">Small Groups</h1>
                    <p class="text-gray-600 mt-1">Manage your church small groups</p>
                </div>
                <button onclick="document.getElementById('groupModal').classList.remove('hidden')" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                    <i class="fas fa-plus mr-2"></i>Add Small Group
                </button>
            </div>

            <?php if ($success): ?>
                <div class="bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md mb-6">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md mb-6">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php if (count($groups) > 0): ?>
                    <?php foreach ($groups as $group): ?>
                        <div class="bg-white rounded-lg shadow p-6">
                            <div class="flex justify-between items-start mb-4">
                                <h3 class="text-lg font-semibold text-gray-900"><?php echo htmlspecialchars($group['group_name']); ?></h3>
                                <span class="px-2 py-1 text-xs rounded-full <?php echo $group['is_active'] ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-600'; ?>">
                                    <?php echo $group['is_active'] ? 'Active' : 'Inactive'; ?>
                                </span>
                                <?php if ($group['meeting_day']): ?>
                                    <p><i class="fas fa-calendar-day mr-2"></i><?php echo htmlspecialchars($group['meeting_day']); ?> at <?php echo htmlspecialchars($group['meeting_time'] ?? ''); ?></p>
                                <?php endif; ?>
                                <?php if ($group['location']): ?>
                                    <p><i class="fas fa-map-marker-alt mr-2"></i><?php echo htmlspecialchars($group['location']); ?></p>
                                <?php endif; ?>
                            </div>
                            <p class="text-gray-500 text-sm mb-4"><?php echo htmlspecialchars($group['description'] ?? ''); ?></p>
                            <div class="pt-4 border-t flex justify-end">
                                <form method="POST" onsubmit="return confirm('Delete this group?');">
                                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                                    <input type="hidden" name="delete_id" value="<?php echo $group['id']; ?>">
                                    <button type="submit" class="text-red-600 hover:text-red-900">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-span-full text-center py-12 text-gray-500">
                        <i class="fas fa-users-rectangle text-4xl mb-4"></i>
                        <p>No small groups found. Click "Add Small Group" to create one.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add Group Modal -->
    <div id="groupModal" class="hidden fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full flex items-center justify-center">
        <div class="bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-4">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Add Small Group</h3>
                <button onclick="document.getElementById('groupModal').classList.add('hidden')" class="text-gray-500 hover:text-gray-700">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                <input type="hidden" name="add_group" value="1">
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Group Name *</label>
                    <input type="text" name="group_name" required class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                </div>
                
                <div class="grid grid-cols-2 gap-4 mb-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Meeting Day</label>
                        <select name="meeting_day" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                            <option value="">Select</option>
                            <option value="Sunday">Sunday</option>
                            <option value="Monday">Monday</option>
                            <option value="Tuesday">Tuesday</option>
                            <option value="Wednesday">Wednesday</option>
                            <option value="Thursday">Thursday</option>
                            <option value="Friday">Friday</option>
                            <option value="Saturday">Saturday</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">Meeting Time</label>
                        <input type="time" name="meeting_time" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Location</label>
                    <input type="text" name="location" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500">
                </div>
                
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                    <textarea name="description" rows="3" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500"></textarea>
                </div>
                
                <div class="flex justify-end space-x-3">
                    <button type="button" onclick="document.getElementById('groupModal').classList.add('hidden')" class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400">Cancel</button>
                    <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">Add Group</button>
                </div>
            </form>
        </div>
    </div>

<?php
$pageContent = ob_get_clean();
include '../includes/admin-layout.php';
?>
