<?php
require_once '../config/config.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

$sermonId = $_GET['id'] ?? 0;
$error = '';
$success = '';

if (!$sermonId) {
    header('Location: sermons.php');
    exit;
}

// Get sermon data
$stmt = $db->prepare("SELECT * FROM sermons WHERE id = ?");
$stmt->execute([$sermonId]);
$sermon = $stmt->fetch(\PDO::FETCH_ASSOC);

if (!$sermon) {
    header('Location: sermons.php');
    exit;
}

if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $title = sanitizeInput($_POST['title'] ?? '');
        $speaker = sanitizeInput($_POST['speaker'] ?? '');
        $sermonDate = $_POST['sermon_date'] ?? '';
        $videoUrl = sanitizeInput($_POST['video_url'] ?? '');
        $audioUrl = sanitizeInput($_POST['audio_url'] ?? '');
        $description = sanitizeInput($_POST['description'] ?? '');
        $scriptureReference = sanitizeInput($_POST['scripture_reference'] ?? '');
        $topic = sanitizeInput($_POST['topic'] ?? '');
        
        if (empty($title) || empty($speaker) || empty($sermonDate)) {
            $error = 'Please fill in all required fields.';
        } elseif (date('Y', strtotime($sermonDate)) < date('Y')) {
            $error = 'The sermon date cannot be from a past year.';
        } else {
            try {
                // Handle file upload for notes PDF
                $notesPdf = $sermon['notes_pdf']; // Keep existing file
                if (isset($_FILES['notes_pdf']) && $_FILES['notes_pdf']['error'] === UPLOAD_ERR_OK) {
                    $uploadResult = uploadFile($_FILES['notes_pdf'], 'uploads/sermons/', ['pdf']);
                    if ($uploadResult['success']) {
                        // Delete old file if exists
                        if ($sermon['notes_pdf'] && file_exists('uploads/sermons/' . $sermon['notes_pdf'])) {
                            unlink('uploads/sermons/' . $sermon['notes_pdf']);
                        }
                        $notesPdf = $uploadResult['filename'];
                    } else {
                        $error = $uploadResult['message'];
                    }
                }
                
                if (empty($error)) {
                    $stmt = $db->prepare("UPDATE sermons SET title = ?, speaker = ?, sermon_date = ?, video_url = ?, audio_url = ?, notes_pdf = ?, description = ?, scripture_reference = ?, topic = ? WHERE id = ?");
                    $result = $stmt->execute([$title, $speaker, $sermonDate, $videoUrl, $audioUrl, $notesPdf, $description, $scriptureReference, $topic, $sermonId]);
                    
                    if ($result) {
                        $success = 'Sermon updated successfully!';
                        logActivity('sermon_update', 'sermons', $sermonId);
                        
                        // Update local sermon data
                        $sermon['title'] = $title;
                        $sermon['speaker'] = $speaker;
                        $sermon['sermon_date'] = $sermonDate;
                        $sermon['video_url'] = $videoUrl;
                        $sermon['audio_url'] = $audioUrl;
                        $sermon['notes_pdf'] = $notesPdf;
                        $sermon['description'] = $description;
                        $sermon['scripture_reference'] = $scriptureReference;
                        $sermon['topic'] = $topic;
                    } else {
                        $error = 'Failed to update sermon. Please try again.';
                    }
                }
            } catch (Exception $e) {
                $error = 'An error occurred: ' . $e->getMessage();
            }
        }
    }
}
?>
<?php
$pageTitle = "Edit Sermon";
include '../includes/header.php';
include '../includes/navigation.php';
?>

    <div class="max-w-7xl mx-auto py-8 sm:px-6 lg:px-8">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0 mb-8">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <div class="flex items-center space-x-4 mb-4">
                        <a href="sermons.php" class="text-gray-400 hover:text-gray-600 transition-colors duration-200">
                            <i class="fas fa-arrow-left text-xl"></i>
                        </a>
                        <div>
                            <h2 class="text-3xl font-bold text-gray-900">
                                Edit Sermon
                            </h2>
                            <p class="text-gray-600 mt-1"><?php echo htmlspecialchars($sermon['title']); ?></p>
                        </div>
                    </div>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4 space-x-3">
                    <a href="sermons.php" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-lg shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Sermons
                    </a>
                </div>
            </div>
        </div>

        <div class="max-w-4xl mx-auto">
            <?php if ($error): ?>
                <div class="mb-6 bg-red-50 border border-red-200 text-red-600 px-6 py-4 rounded-xl flex items-center">
                    <i class="fas fa-exclamation-triangle mr-3"></i>
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="mb-6 bg-green-50 border border-green-200 text-green-600 px-6 py-4 rounded-xl flex items-center">
                    <i class="fas fa-check-circle mr-3"></i>
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="space-y-8">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <!-- Sermon Information -->
                <div class="bg-white shadow-lg rounded-2xl overflow-hidden">
                    <div class="px-6 py-5 border-b border-gray-200 bg-gradient-to-r from-indigo-50 to-purple-50">
                        <div class="flex items-center">
                            <div class="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-microphone text-indigo-600"></i>
                            </div>
                            <h3 class="text-xl font-bold text-gray-900">Sermon Information</h3>
                        </div>
                    </div>
                    
                    <div class="p-6 space-y-6">
                        <div>
                            <label for="title" class="block text-sm font-semibold text-gray-700 mb-2">Sermon Title *</label>
                            <input type="text" id="title" name="title" required 
                                   value="<?php echo htmlspecialchars($sermon['title']); ?>"
                                   class="block w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200 text-lg">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="speaker" class="block text-sm font-semibold text-gray-700 mb-2">Speaker *</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i class="fas fa-user text-gray-400"></i>
                                    </div>
                                    <input type="text" id="speaker" name="speaker" required 
                                           value="<?php echo htmlspecialchars($sermon['speaker']); ?>"
                                           class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200">
                                </div>
                            </div>
                            
                            <div>
                                <label for="sermon_date" class="block text-sm font-semibold text-gray-700 mb-2">Sermon Date *</label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i class="fas fa-calendar text-gray-400"></i>
                                    </div>
                                    <input type="date" id="sermon_date" name="sermon_date" required 
                                           value="<?php echo htmlspecialchars($sermon['sermon_date']); ?>"
                                           class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200">
                                </div>
                            </div>
                        </div>
                        
                        <div>
                            <label for="topic" class="block text-sm font-semibold text-gray-700 mb-2">Topic</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-tag text-gray-400"></i>
                                </div>
                                <input type="text" id="topic" name="topic" 
                                       value="<?php echo htmlspecialchars($sermon['topic'] ?? ''); ?>"
                                       placeholder="e.g., Faith, Hope, Love"
                                       class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200">
                            </div>
                        </div>
                        
                        <div>
                            <label for="scripture_reference" class="block text-sm font-semibold text-gray-700 mb-2">Scripture Reference</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-bible text-gray-400"></i>
                                </div>
                                <input type="text" id="scripture_reference" name="scripture_reference" 
                                       value="<?php echo htmlspecialchars($sermon['scripture_reference'] ?? ''); ?>"
                                       placeholder="e.g., John 3:16"
                                       class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200">
                            </div>
                        </div>
                        
                        <div>
                            <label for="description" class="block text-sm font-semibold text-gray-700 mb-2">Description</label>
                            <textarea id="description" name="description" rows="4" 
                                      placeholder="Enter a brief description of the sermon..."
                                      class="block w-full px-4 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200 resize-none"><?php echo htmlspecialchars($sermon['description'] ?? ''); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- Media & Resources -->
                <div class="bg-white shadow-lg rounded-2xl overflow-hidden">
                    <div class="px-6 py-5 border-b border-gray-200 bg-gradient-to-r from-purple-50 to-pink-50">
                        <div class="flex items-center">
                            <div class="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mr-3">
                                <i class="fas fa-video text-purple-600"></i>
                            </div>
                            <h3 class="text-xl font-bold text-gray-900">Media & Resources</h3>
                        </div>
                    </div>
                    
                    <div class="p-6 space-y-6">
                        <div>
                            <label for="video_url" class="block text-sm font-semibold text-gray-700 mb-2">Video URL</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-play text-gray-400"></i>
                                </div>
                                <input type="url" id="video_url" name="video_url" 
                                       value="<?php echo htmlspecialchars($sermon['video_url'] ?? ''); ?>"
                                       placeholder="https://youtube.com/watch?v=..."
                                       class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200">
                            </div>
                        </div>
                        
                        <div>
                            <label for="audio_url" class="block text-sm font-semibold text-gray-700 mb-2">Audio URL</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-headphones text-gray-400"></i>
                                </div>
                                <input type="url" id="audio_url" name="audio_url" 
                                       value="<?php echo htmlspecialchars($sermon['audio_url'] ?? ''); ?>"
                                       placeholder="https://example.com/audio.mp3"
                                       class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200">
                            </div>
                        </div>
                        
                        <div>
                            <label for="notes_pdf" class="block text-sm font-semibold text-gray-700 mb-2">Notes PDF</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-file-pdf text-gray-400"></i>
                                </div>
                                <input type="file" id="notes_pdf" name="notes_pdf" accept=".pdf"
                                       class="block w-full pl-10 pr-3 py-3 text-sm text-gray-500 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                            </div>
                            <?php if ($sermon['notes_pdf']): ?>
                                <div class="mt-3 p-3 bg-gray-50 rounded-lg">
                                    <p class="text-sm text-gray-600 mb-2">Current file:</p>
                                    <a href="uploads/sermons/<?php echo htmlspecialchars($sermon['notes_pdf']); ?>" target="_blank" 
                                       class="inline-flex items-center text-indigo-600 hover:text-indigo-500 font-medium">
                                        <i class="fas fa-file-pdf mr-2"></i>
                                        <?php echo htmlspecialchars($sermon['notes_pdf']); ?>
                                        <i class="fas fa-external-link-alt ml-2 text-xs"></i>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="flex justify-end space-x-4 pt-6">
                    <a href="sermons.php" class="inline-flex items-center px-6 py-3 border border-gray-300 rounded-xl shadow-sm text-sm font-semibold text-gray-700 bg-white hover:bg-gray-50 transition-all duration-200">
                        <i class="fas fa-times mr-2"></i>
                        Cancel
                    </a>
                    <button type="submit" class="group inline-flex items-center px-6 py-3 border border-transparent rounded-xl shadow-sm text-sm font-semibold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all duration-200">
                        <i class="fas fa-save mr-2 group-hover:scale-110 transition-transform duration-200"></i>
                        Update Sermon
                    </button>
                </div>
            </form>
        </div>
    </div>

<?php include '../includes/footer.php'; ?>
