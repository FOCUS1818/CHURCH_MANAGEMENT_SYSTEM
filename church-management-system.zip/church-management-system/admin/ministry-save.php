<?php
require_once '../config/config.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ministries.php?error=Invalid request method');
    exit;
}

// Validate CSRF token
if (!isset($_POST['csrf_token']) || !verifyCSRFToken($_POST['csrf_token'])) {
    header('Location: ministries.php?error=Invalid CSRF token');
    exit;
}

$id = isset($_POST['id']) ? (int)$_POST['id'] : null;
$name = trim($_POST['name'] ?? '');
$description = trim($_POST['description'] ?? '');
$leader_id = !empty($_POST['leader_id']) ? (int)$_POST['leader_id'] : null;
$contact_email = trim($_POST['contact_email'] ?? '');
$meeting_schedule = trim($_POST['meeting_schedule'] ?? '');
$is_active = isset($_POST['is_active']) ? 1 : 0;
$leader_photo_existing = $_POST['leader_photo_existing'] ?? '';

// Validate required fields
if (empty($name)) {
    header('Location: ministries.php?error=Ministry name is required');
    exit;
}

// Handle file upload
$leader_photo = $leader_photo_existing;
$custom_link = trim($_POST['custom_link'] ?? '');

if (isset($_FILES['leader_photo']) && $_FILES['leader_photo']['error'] === UPLOAD_ERR_OK) {
    $upload_dir = '../uploads/';
    
    // Create uploads directory if it doesn't exist
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $file_tmp = $_FILES['leader_photo']['tmp_name'];
    $file_name = $_FILES['leader_photo']['name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    // Generate unique filename
    $new_file_name = 'leader_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $file_ext;
    $upload_path = $upload_dir . $new_file_name;
    
    // Validate file type
    $allowed_exts = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (in_array($file_ext, $allowed_exts)) {
        if (move_uploaded_file($file_tmp, $upload_path)) {
            $leader_photo = 'uploads/' . $new_file_name;
            
            // Delete old photo if it exists and is different
            if (!empty($leader_photo_existing) && $leader_photo_existing !== $leader_photo && file_exists('../' . $leader_photo_existing)) {
                unlink('../' . $leader_photo_existing);
            }
        }
    }
}

try {
    if ($id) {
        // Update existing ministry
        $stmt = $db->prepare("UPDATE ministries SET 
            name = :name, 
            description = :description, 
            leader_id = :leader_id, 
            leader_photo = :leader_photo,
            custom_link = :custom_link,
            contact_email = :contact_email, 
            meeting_schedule = :meeting_schedule, 
            is_active = :is_active 
            WHERE id = :id");
        
        $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    } else {
        // Insert new ministry
        $stmt = $db->prepare("INSERT INTO ministries 
            (name, description, leader_id, leader_photo, custom_link, contact_email, meeting_schedule, is_active) 
            VALUES 
            (:name, :description, :leader_id, :leader_photo, :custom_link, :contact_email, :meeting_schedule, :is_active)");
    }
    
    $stmt->bindParam(':name', $name, PDO::PARAM_STR);
    $stmt->bindParam(':description', $description, PDO::PARAM_STR);
    $stmt->bindParam(':leader_id', $leader_id, PDO::PARAM_INT);
    $stmt->bindParam(':leader_photo', $leader_photo, PDO::PARAM_STR);
    $stmt->bindParam(':custom_link', $custom_link, PDO::PARAM_STR);
    $stmt->bindParam(':contact_email', $contact_email, PDO::PARAM_STR);
    $stmt->bindParam(':meeting_schedule', $meeting_schedule, PDO::PARAM_STR);
    $stmt->bindParam(':is_active', $is_active, PDO::PARAM_INT);
    
    $stmt->execute();
    
    header('Location: ministries.php?success=Ministry saved successfully');
    exit;
    
} catch (PDOException $e) {
    error_log("Error saving ministry: " . $e->getMessage());
    header('Location: ministries.php?error=Error saving ministry');
    exit;
}
