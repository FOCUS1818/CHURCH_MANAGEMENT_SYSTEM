<?php
require_once '../config/config.php';
require_once '../classes/User.php';
require_once '../classes/Member.php';

use App\Database;
use App\Member;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

// Get statistics
$member = new Member($db);
$stats = $member->getStatistics();

// Get recent members
$recentMembers = $member->getAll(1, 5);

// Get upcoming birthdays
$upcomingBirthdays = $member->getUpcomingBirthdays(7);

// Prepare data for ACMS export
$acmsData = [
    'church_name' => APP_NAME,
    'export_date' => date('Y-m-d H:i:s'),
    'statistics' => [
        'total_members' => $stats['total'],
        'active_members' => $stats['active'],
        'new_this_month' => $stats['new_this_month']
    ],
    'recent_members' => array_map(function($m) {
        return [
            'name' => $m['first_name'] . ' ' . $m['last_name'],
            'email' => $m['email'],
            'phone' => $m['phone'] ?? null,
            'join_date' => $m['created_at']
        ];
    }, $recentMembers)
];
$acmsDataJson = json_encode($acmsData);
?>
<script>
// ACMS System Integration
const ACMS_URL = 'https://play.google.com/store/apps/details?id=com.besoft.sdaacms';

function sendToGCAMSystem() {
    const btn = event.target;
    const acmsData = btn.getAttribute('data-acms-data');
    
    if (!acmsData) {
        alert('No data available for export');
        return;
    }
    
    const confirmed = confirm('This will send your church data to the General Conference ACMS system. Continue?');
    
    if (!confirmed) return;
    
    // Show loading state
    const originalText = btn.innerHTML;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Sending...';
    btn.disabled = true;
    
    try {
        // Send data to ACMS using form submission
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = ACMS_URL + 'api/import';
        form.target = '_blank';
        
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'church_data';
        input.value = acmsData;
        
        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
        document.body.removeChild(form);
        
        alert('Data has been prepared for transfer to ACMS. A new window may have opened for the transfer.');
        
    } catch (error) {
        console.error('Error sending to ACMS:', error);
        alert('Failed to send data to ACMS. Please try again or contact support.');
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}
</script>
<?php
$pageTitle = "Dashboard";
$breadcrumbs = [
    ['name' => 'Dashboard']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0 mb-8">
            <div class="flex items-center justify-between">
                <div>
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
                    <p class="text-gray-600">Welcome back, <?php echo htmlspecialchars($_SESSION['first_name']); ?>! Here's what's happening at your church.</p>
                </div>
                <div class="flex space-x-3">
                    <div class="relative group">
                        <button class="bg-white border border-gray-300 rounded-lg px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors duration-200">
                            <i class="fas fa-download mr-2"></i>
                            Export Data
                            <i class="fas fa-chevron-down ml-2"></i>
                        </button>
                        <div class="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                            <button onclick="window.open('export-dashboard.php', '_blank', 'width=800,height=600')" class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-t-lg">
                                <i class="fas fa-save mr-2"></i>Save/Print PDF
                            </button>
                            <button onclick="sendToGCAMSystem()" class="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-b-lg" data-acms-data='<?php echo htmlspecialchars($acmsDataJson, ENT_QUOTES, 'UTF-8'); ?>'>
                                <i class="fas fa-paper-plane mr-2"></i>Send to ACMS
                            </button>
                        </div>
                    </div>
                    <button class="bg-indigo-600 text-white rounded-lg px-4 py-2 text-sm font-medium hover:bg-indigo-700 transition-colors duration-200">
                        <i class="fas fa-plus mr-2"></i>
                        Quick Add
                    </button>
                </div>
            </div>
        </div>

        <!-- Stats cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="group bg-white overflow-hidden shadow-lg rounded-2xl hover:shadow-2xl transition-all duration-300 hover-lift">
                <div class="p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 mb-1">Total Members</p>
                            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['total']; ?></p>
                            <p class="text-xs text-green-600 mt-1">
                                <i class="fas fa-arrow-up mr-1"></i>
                                +12% from last month
                            </p>
                        </div>
                        <div class="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                            <i class="fas fa-users text-white text-2xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="group bg-white overflow-hidden shadow-lg rounded-2xl hover:shadow-2xl transition-all duration-300 hover-lift">
                <div class="p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 mb-1">Active Members</p>
                            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['active']; ?></p>
                            <p class="text-xs text-green-600 mt-1">
                                <i class="fas fa-check-circle mr-1"></i>
                                <?php echo $stats['total'] > 0 ? round(($stats['active'] / $stats['total']) * 100, 1) : 0; ?>% of total
                            </p>
                        </div>
                        <div class="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                            <i class="fas fa-user-check text-white text-2xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="group bg-white overflow-hidden shadow-lg rounded-2xl hover:shadow-2xl transition-all duration-300 hover-lift">
                <div class="p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 mb-1">New This Month</p>
                            <p class="text-3xl font-bold text-gray-900"><?php echo $stats['new_this_month']; ?></p>
                            <p class="text-xs text-blue-600 mt-1">
                                <i class="fas fa-calendar mr-1"></i>
                                <?php echo date('F Y'); ?>
                            </p>
                        </div>
                        <div class="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                            <i class="fas fa-user-plus text-white text-2xl"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="group bg-white overflow-hidden shadow-lg rounded-2xl hover:shadow-2xl transition-all duration-300 hover-lift">
                <div class="p-6">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-medium text-gray-500 mb-1">Upcoming Birthdays</p>
                            <p class="text-3xl font-bold text-gray-900"><?php echo count($upcomingBirthdays); ?></p>
                            <p class="text-xs text-yellow-600 mt-1">
                                <i class="fas fa-birthday-cake mr-1"></i>
                                Next 7 days
                            </p>
                        </div>
                        <div class="w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                            <i class="fas fa-birthday-cake text-white text-2xl"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent members and upcoming birthdays -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Recent Members -->
            <div class="bg-white shadow-lg rounded-2xl overflow-hidden">
                <div class="px-6 py-5 border-b border-gray-200 bg-gradient-to-r from-indigo-50 to-purple-50">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-bold text-gray-900">Recent Members</h3>
                        <div class="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-users text-indigo-600"></i>
                        </div>
                    </div>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <?php foreach ($recentMembers as $member): ?>
                        <div class="flex items-center space-x-4 p-3 rounded-xl hover:bg-gray-50 transition-colors duration-200">
                            <div class="flex-shrink-0">
                                <?php if ($member['photo']): ?>
                                    <img class="h-12 w-12 rounded-full object-cover" src="../uploads/<?php echo htmlspecialchars($member['photo']); ?>" alt="">
                                <?php else: ?>
                                    <div class="h-12 w-12 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center">
                                        <span class="text-sm font-bold text-white"><?php echo strtoupper(substr($member['first_name'], 0, 1)); ?></span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-semibold text-gray-900 truncate">
                                    <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                                </p>
                                <p class="text-sm text-gray-500 truncate">
                                    <?php echo htmlspecialchars($member['email']); ?>
                                </p>
                            </div>
                            <div class="flex-shrink-0 text-right">
                                <p class="text-xs text-gray-500">
                                    <?php echo formatDate($member['created_at']); ?>
                                </p>
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                    New
                                </span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="mt-6 pt-4 border-t border-gray-200">
                        <a href="members.php" class="group inline-flex items-center text-sm font-medium text-indigo-600 hover:text-indigo-500 transition-colors duration-200">
                            View all members
                            <i class="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform duration-300"></i>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Upcoming Birthdays -->
            <div class="bg-white shadow-lg rounded-2xl overflow-hidden">
                <div class="px-6 py-5 border-b border-gray-200 bg-gradient-to-r from-yellow-50 to-orange-50">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-bold text-gray-900">Upcoming Birthdays</h3>
                        <div class="w-8 h-8 bg-yellow-100 rounded-lg flex items-center justify-center">
                            <i class="fas fa-birthday-cake text-yellow-600"></i>
                        </div>
                    </div>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <?php foreach ($upcomingBirthdays as $birthday): ?>
                        <div class="flex items-center space-x-4 p-3 rounded-xl hover:bg-gray-50 transition-colors duration-200">
                            <div class="flex-shrink-0">
                                <div class="h-12 w-12 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 flex items-center justify-center">
                                    <i class="fas fa-birthday-cake text-white"></i>
                                </div>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="text-sm font-semibold text-gray-900 truncate">
                                    <?php echo htmlspecialchars($birthday['first_name'] . ' ' . $birthday['last_name']); ?>
                                </p>
                                <p class="text-sm text-gray-500 truncate">
                                    <?php echo formatDate($birthday['date_of_birth'], 'M j'); ?>
                                </p>
                            </div>
                            <div class="flex-shrink-0 text-right">
                                <span class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                    <?php echo $birthday['days_until_birthday']; ?> days
                                </span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (empty($upcomingBirthdays)): ?>
                    <div class="text-center py-8">
                        <div class="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                            <i class="fas fa-birthday-cake text-gray-400 text-2xl"></i>
                        </div>
                        <p class="text-gray-500">No upcoming birthdays in the next 7 days</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
