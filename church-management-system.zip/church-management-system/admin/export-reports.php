<?php
require_once '../config/config.php';
require_once '../classes/Member.php';
require_once '../classes/Event.php';

use App\Database;
use App\Member;
use App\Event;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$member = new Member($db);
$event = new Event($db);

// Get date range for reports
$dateFrom = $_GET['date_from'] ?? date('Y-m-01');
$dateTo = $_GET['date_to'] ?? date('Y-m-t');

// Get statistics
$memberStats = $member->getStatistics();
$eventStats = $event->getStatistics();

// Get membership growth over time
$membershipGrowth = $db->query("
    SELECT DATE_FORMAT(created_at, '%Y-%m') as month, COUNT(*) as count 
    FROM members 
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 12 MONTH) 
    GROUP BY DATE_FORMAT(created_at, '%Y-%m') 
    ORDER BY month
")->fetchAll(\PDO::FETCH_ASSOC);

// Get event attendance trends
$stmt = $db->prepare("
    SELECT e.event_type, COUNT(a.id) as attendance_count
    FROM events e
    LEFT JOIN attendance a ON e.id = a.event_id AND a.attended = 1
    WHERE e.start_datetime >= ? AND e.start_datetime <= ?
    GROUP BY e.event_type
");
$stmt->execute([$dateFrom, $dateTo]);
$eventAttendance = $stmt->fetchAll(\PDO::FETCH_ASSOC);

// Get top ministries by member count
$topMinistries = $db->query("
    SELECT m.name, COUNT(mm.member_id) as member_count 
    FROM ministries m 
    LEFT JOIN ministry_members mm ON m.id = mm.ministry_id AND mm.is_active = 1 
    WHERE m.is_active = 1 
    GROUP BY m.id, m.name 
    ORDER BY member_count DESC 
    LIMIT 5
")->fetchAll(\PDO::FETCH_ASSOC);

// Generate HTML content for PDF
$html = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Church Reports - ' . date('F Y') . '</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #4F46E5;
        }
        .header h1 {
            color: #4F46E5;
            margin: 0;
        }
        .header p {
            color: #666;
            margin: 5px 0 0 0;
        }
        .date-range {
            background: #f3f4f6;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 30px;
        }
        .stat-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            text-align: center;
        }
        .stat-card .label {
            font-size: 12px;
            color: #666;
            margin-bottom: 5px;
        }
        .stat-card .value {
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #4F46E5;
            color: white;
            font-size: 14px;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .section {
            margin-bottom: 30px;
            page-break-inside: avoid;
        }
        .section h2 {
            color: #4F46E5;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
            font-size: 18px;
        }
        .chart-placeholder {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            background: #f9f9f9;
            margin-bottom: 20px;
        }
        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #666;
            font-size: 12px;
        }
        @media print {
            body { padding: 0; }
            .no-print { display: none; }
            .section { page-break-inside: avoid; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Church Reports & Analytics</h1>
        <p>Generated on ' . date('F j, Y g:i A') . '</p>
    </div>

    <div class="date-range">
        <strong>Report Period:</strong> ' . date('F j, Y', strtotime($dateFrom)) . ' to ' . date('F j, Y', strtotime($dateTo)) . '
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="label">Total Members</div>
            <div class="value">' . $memberStats['total'] . '</div>
        </div>
        <div class="stat-card">
            <div class="label">Total Events</div>
            <div class="value">' . $eventStats['total'] . '</div>
        </div>
        <div class="stat-card">
            <div class="label">Active Members</div>
            <div class="value">' . $memberStats['active'] . '</div>
        </div>
        <div class="stat-card">
            <div class="label">New This Month</div>
            <div class="value">' . $memberStats['new_this_month'] . '</div>
        </div>
    </div>

    <div class="section">
        <h2>Membership Growth (Last 12 Months)</h2>
        <table>
            <thead>
                <tr>
                    <th>Month</th>
                    <th>New Members</th>
                </tr>
            </thead>
            <tbody>';
            
foreach ($membershipGrowth as $row) {
    $html .= '
                <tr>
                    <td>' . date('F Y', strtotime($row['month'] . '-01')) . '</td>
                    <td>' . $row['count'] . '</td>
                </tr>';
}

$html .= '
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>Event Attendance by Type</h2>
        <table>
            <thead>
                <tr>
                    <th>Event Type</th>
                    <th>Total Attendance</th>
                </tr>
            </thead>
            <tbody>';
            
foreach ($eventAttendance as $row) {
    $html .= '
                <tr>
                    <td>' . htmlspecialchars($row['event_type']) . '</td>
                    <td>' . $row['attendance_count'] . '</td>
                </tr>';
}

$html .= '
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>Top Ministries by Member Count</h2>
        <table>
            <thead>
                <tr>
                    <th>Ministry</th>
                    <th>Member Count</th>
                </tr>
            </thead>
            <tbody>';
            
foreach ($topMinistries as $row) {
    $html .= '
                <tr>
                    <td>' . htmlspecialchars($row['name']) . '</td>
                    <td>' . $row['member_count'] . '</td>
                </tr>';
}

$html .= '
            </tbody>
        </table>
    </div>

    <div class="footer">
        <p>Church Management System - Report generated automatically</p>
    </div>

    <div class="no-print" style="text-align: center; margin-top: 20px;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #4F46E5; color: white; border: none; border-radius: 5px; cursor: pointer;">Print / Save as PDF</button>
        <button onclick="window.close()" style="padding: 10px 20px; background: #666; color: white; border: none; border-radius: 5px; cursor: pointer; margin-left: 10px;">Close</button>
    </div>
</body>
</html>
';

echo $html;
