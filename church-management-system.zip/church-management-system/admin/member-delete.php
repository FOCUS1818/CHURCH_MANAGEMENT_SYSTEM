<?php
/**
 * Church Management System
 * Member Delete Handler
 */

require_once '../config/config.php';
require_once '../classes/Member.php';

use App\Database;
use App\Member;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$member = new Member($db);

// Check if ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    $_SESSION['error'] = 'Member ID is required.';
    header('Location: members.php');
    exit;
}

$member_id = (int)$_GET['id'];

// Verify CSRF token if present
if (isset($_GET['csrf_token'])) {
    if (!verifyCSRFToken($_GET['csrf_token'])) {
        $_SESSION['error'] = 'Invalid security token.';
        header('Location: members.php');
        exit;
    }
}

// Delete the member
try {
    // First get the member to check if they exist and get their photo for deletion
    $member->getById($member_id);
    
    if (!$member->id) {
        $_SESSION['error'] = 'Member not found.';
        header('Location: members.php');
        exit;
    }
    
    // Delete the member photo if exists
    if (!empty($member->photo)) {
        $photo_path = '../uploads/' . $member->photo;
        if (file_exists($photo_path)) {
            unlink($photo_path);
        }
    }
    
    // Set the ID and delete
    $member->id = $member_id;
    
    if ($member->delete()) {
        $_SESSION['success'] = 'Member deleted successfully!';
        logActivity('delete', 'members', $member_id);
    } else {
        $_SESSION['error'] = 'Failed to delete member.';
    }
} catch (PDOException $e) {
    $_SESSION['error'] = 'Error deleting member: ' . $e->getMessage();
}

// Redirect back to members list
header('Location: members.php');
exit;
?>
