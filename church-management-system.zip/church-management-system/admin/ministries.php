c<?php
require_once '../config/config.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

// Build query for ministries
$query = "SELECT m.*, CONCAT(mem.first_name, ' ', mem.last_name) as leader_name, 
          COUNT(mm.member_id) as member_count 
          FROM ministries m 
          LEFT JOIN members mem ON m.leader_id = mem.id 
          LEFT JOIN ministry_members mm ON m.id = mm.ministry_id AND mm.is_active = 1 
          WHERE 1=1";

$params = [];

if (!empty($search)) {
    $query .= " AND (m.name LIKE :search OR m.description LIKE :search)";
    $params[':search'] = "%$search%";
}

if ($status !== '') {
    $query .= " AND m.is_active = :status";
    $params[':status'] = $status;
}

$query .= " GROUP BY m.id ORDER BY m.name";

// Get total count
$countQuery = str_replace("SELECT m.*, CONCAT(mem.first_name, ' ', mem.last_name) as leader_name, COUNT(mm.member_id) as member_count", "SELECT COUNT(DISTINCT m.id) as total", $query);
$stmt = $db->prepare($countQuery);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$result = $stmt->fetch(\PDO::FETCH_ASSOC);
$totalCount = ($result && isset($result['total'])) ? (int)$result['total'] : 0;

// Get paginated results
$offset = ($page - 1) * 10;
$query .= " LIMIT 10 OFFSET $offset";

$stmt = $db->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$ministries = $stmt->fetchAll(\PDO::FETCH_ASSOC);

$paginationData = getPaginationData($page, $totalCount, 10);

// Get all members for leader selection
$members = $db->query("SELECT id, first_name, last_name FROM members WHERE membership_status = 'active' ORDER BY first_name, last_name")->fetchAll(\PDO::FETCH_ASSOC);
?>
<?php
$pageTitle = "Ministries";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Ministries']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        Ministries Management
                    </h2>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <button onclick="openMinistryModal()" class="ml-3 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                        Add New Ministry
                    </button>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="bg-white shadow rounded-lg mb-6">
            <div class="px-4 py-5 sm:p-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Filter Ministries</h3>
                <form method="GET" class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label for="search" class="block text-sm font-medium text-gray-700">Search</label>
                        <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>"
                               class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                    <div>
                        <label for="status" class="block text-sm font-medium text-gray-700">Status</label>
                        <select id="status" name="status" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <option value="">All Statuses</option>
                            <option value="1" <?php echo $status === '1' ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo $status === '0' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="flex items-end">
                        <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                            Filter
                        </button>
                        <a href="ministries.php" class="ml-2 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                            Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Ministries list -->
        <div class="bg-white shadow overflow-hidden sm:rounded-md">
            <?php if (empty($ministries)): ?>
                <div class="text-center py-12">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">No ministries found</h3>
                    <p class="mt-1 text-sm text-gray-500">Get started by adding a new ministry.</p>
                    <div class="mt-6">
                        <button onclick="openMinistryModal()" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                            Add New Ministry
                        </button>
                    </div>
                </div>
            <?php else: ?>
                <ul class="divide-y divide-gray-200">
                    <?php foreach ($ministries as $ministry): ?>
                        <li>
                            <div class="px-4 py-4 flex items-center justify-between">
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center justify-between">
                                        <p class="text-sm font-medium text-indigo-600 truncate">
                                            <?php echo htmlspecialchars($ministry['name']); ?>
                                        </p>
                                        <div class="ml-2 flex-shrink-0 flex">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $ministry['is_active'] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'; ?>">
                                                <?php echo $ministry['is_active'] ? 'Active' : 'Inactive'; ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="mt-2 flex items-center text-sm text-gray-500">
                                        <p class="truncate">
                                            <?php if ($ministry['leader_name']): ?>
                                                Leader: <strong><?php echo htmlspecialchars($ministry['leader_name']); ?></strong>
                                            <?php else: ?>
                                                No leader assigned
                                            <?php endif; ?>
                                            • <?php echo $ministry['member_count']; ?> members
                                        </p>
                                    </div>
                                    <?php if ($ministry['description']): ?>
                                        <div class="mt-2">
                                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars(substr($ministry['description'], 0, 100)) . (strlen($ministry['description']) > 100 ? '...' : ''); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ($ministry['meeting_schedule']): ?>
                                        <div class="mt-2">
                                            <p class="text-sm text-gray-500">
                                                <strong>Schedule:</strong> <?php echo htmlspecialchars($ministry['meeting_schedule']); ?>
                                            </p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="ml-4 flex-shrink-0 flex space-x-2">
                                    <button onclick="editMinistry(<?php echo htmlspecialchars(json_encode($ministry)); ?>)" class="text-indigo-600 hover:text-indigo-900 text-sm font-medium">
                                        Edit
                                    </button>
                                    <a href="ministry-members.php?id=<?php echo $ministry['id']; ?>" class="text-blue-600 hover:text-blue-900 text-sm font-medium">
                                        Members
                                    </a>
                                    <a href="ministry-delete.php?id=<?php echo $ministry['id']; ?>" 
                                       onclick="return confirm('Are you sure you want to delete this ministry?')"
                                       class="text-red-600 hover:text-red-900 text-sm font-medium">
                                        Delete
                                    </a>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <!-- Pagination -->
                <?php if ($paginationData['total_pages'] > 1): ?>
                    <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                        <?php echo generatePagination($paginationData, 'ministries.php'); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- Ministry Modal -->
    <div id="ministryModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden">
        <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div class="mt-3">
                <h3 class="text-lg font-medium text-gray-900 mb-4" id="modalTitle">Add New Ministry</h3>
                <form id="ministryForm" method="POST" action="ministry-save.php" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                    <input type="hidden" name="id" id="ministryId">
                    
                    <div class="space-y-4">
                        <div>
                            <label for="name" class="block text-sm font-medium text-gray-700">Ministry Name *</label>
                            <input type="text" id="name" name="name" required 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                            <textarea id="description" name="description" rows="3" 
                                      class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"></textarea>
                        </div>
                        
                        <div>
                            <label for="leader_id" class="block text-sm font-medium text-gray-700">Leader</label>
                            <select id="leader_id" name="leader_id" 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="">Select a leader</option>
                                <?php foreach ($members as $member): ?>
                                    <option value="<?php echo $member['id']; ?>">
                                        <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="leader_photo" class="block text-sm font-medium text-gray-700">Leader Photo</label>
                            <input type="file" id="leader_photo" name="leader_photo" accept="image/*"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <p class="mt-1 text-xs text-gray-500">Upload a photo for the ministry leader (optional)</p>
                            <input type="hidden" id="leader_photo_existing" name="leader_photo_existing">
                        </div>
                        
                        <div>
                            <label for="custom_link" class="block text-sm font-medium text-gray-700">Custom Link</label>
                            <input type="url" id="custom_link" name="custom_link" 
                                   placeholder="https://www.gcyouthministries.org/"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="contact_email" class="block text-sm font-medium text-gray-700">Contact Email</label>
                            <input type="email" id="contact_email" name="contact_email" 
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="meeting_schedule" class="block text-sm font-medium text-gray-700">Meeting Schedule</label>
                            <input type="text" id="meeting_schedule" name="meeting_schedule" 
                                   placeholder="e.g., Every Sunday at 2:00 PM"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div class="flex items-center">
                            <input type="checkbox" id="is_active" name="is_active" value="1" checked
                                   class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                            <label for="is_active" class="ml-2 block text-sm text-gray-900">
                                Active Ministry
                            </label>
                        </div>
                    </div>
                    
                    <div class="mt-6 flex justify-end space-x-3">
                        <button type="button" onclick="closeMinistryModal()" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                            Cancel
                        </button>
                        <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                            Save Ministry
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        function openMinistryModal() {
            document.getElementById('ministryModal').classList.remove('hidden');
            document.getElementById('modalTitle').textContent = 'Add New Ministry';
            document.getElementById('ministryForm').reset();
            document.getElementById('ministryId').value = '';
        }

        function closeMinistryModal() {
            document.getElementById('ministryModal').classList.add('hidden');
        }

        function editMinistry(ministry) {
            document.getElementById('ministryModal').classList.remove('hidden');
            document.getElementById('modalTitle').textContent = 'Edit Ministry';
            document.getElementById('ministryId').value = ministry.id;
            document.getElementById('name').value = ministry.name;
            document.getElementById('description').value = ministry.description || '';
            document.getElementById('leader_id').value = ministry.leader_id || '';
            document.getElementById('leader_photo_existing').value = ministry.leader_photo || '';
            document.getElementById('custom_link').value = ministry.custom_link || '';
            document.getElementById('contact_email').value = ministry.contact_email || '';
            document.getElementById('meeting_schedule').value = ministry.meeting_schedule || '';
            document.getElementById('is_active').checked = ministry.is_active == 1;
        }

        // Close modal when clicking outside
        document.getElementById('ministryModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeMinistryModal();
            }
        });
    </script>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
