<?php
require_once '../config/config.php';

// Log the logout activity
if (isLoggedIn()) {
    logActivity('logout');
}

// Destroy session
session_destroy();

// Redirect to login page
header('Location: login.php');
exit();
?>
