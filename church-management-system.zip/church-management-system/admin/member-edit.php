<?php
require_once '../config/config.php';
require_once '../classes/Member.php';

use App\Database;
use App\Member;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$member = new Member($db);

$memberId = $_GET['id'] ?? 0;
$error = '';
$success = '';

if (!$memberId || !$member->getById($memberId)) {
    header('Location: members.php');
    exit;
}

// Get households for dropdown
$stmt = $db->prepare("SELECT id, household_name FROM households ORDER BY household_name");
$stmt->execute();
$households = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get small groups for dropdown
$stmt = $db->prepare("SELECT id, group_name FROM small_groups WHERE is_active = 1 ORDER BY group_name");
$stmt->execute();
$small_groups = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $member->first_name = sanitizeInput($_POST['first_name'] ?? '');
        $member->last_name = sanitizeInput($_POST['last_name'] ?? '');
        $member->middle_name = sanitizeInput($_POST['middle_name'] ?? '');
        $member->gender = $_POST['gender'] ?? '';
        $member->date_of_birth = $_POST['date_of_birth'] ?? null;
        $member->marital_status = $_POST['marital_status'] ?? 'single';
        $member->phone = sanitizeInput($_POST['phone'] ?? '');
        $member->email = sanitizeInput($_POST['email'] ?? '');
        $member->address = sanitizeInput($_POST['address'] ?? '');
        $member->household_id = $_POST['household_id'] ?? null;
        $member->small_group_id = $_POST['small_group_id'] ?? null;
        $small_group_ids = $_POST['small_group_ids'] ?? [];
        $member->family_role = $_POST['family_role'] ?? 'other';
        $member->membership_status = $_POST['membership_status'] ?? 'visitor';
        $member->membership_class_completed = isset($_POST['membership_class_completed']) ? 1 : 0;
        $member->baptism_date = $_POST['baptism_date'] ?? null;
        $member->spiritual_gifts = sanitizeInput($_POST['spiritual_gifts'] ?? '');
        $member->notes = sanitizeInput($_POST['notes'] ?? '');
        
        if (empty($member->first_name) || empty($member->last_name) || empty($member->gender)) {
            $error = 'Please fill in all required fields.';
        }
        // Validate first name - letters only
        elseif (!validateName($member->first_name)) {
            $error = 'First name should only contain letters (a-z, A-Z). Numbers are not allowed.';
        }
        // Validate last name - letters only
        elseif (!validateName($member->last_name)) {
            $error = 'Last name should only contain letters (a-z, A-Z). Numbers are not allowed.';
        }
        // Validate middle name if provided - letters only
        elseif (!empty($member->middle_name) && !validateName($member->middle_name)) {
            $error = 'Middle name should only contain letters (a-z, A-Z). Numbers are not allowed.';
        }
        // Validate phone - numbers only
        elseif (!empty($member->phone) && !validatePhone($member->phone)) {
            $error = 'Phone number should only contain numbers. Letters are not allowed.';
        }
        // Validate notes - max 50 words
        elseif (!validateWordLimit($member->notes, 50)) {
            $error = 'Notes should not exceed 50 words. Please shorten your notes.';
        }
        // Validate date of birth is not in the future
        elseif (!empty($member->date_of_birth) && strtotime($member->date_of_birth) > strtotime('today')) {
            $error = 'Date of birth cannot be in the future.';
        }
        // Validate baptism date is not in the future and not before DOB
        elseif (!empty($member->baptism_date)) {
            if (strtotime($member->baptism_date) > strtotime('today')) {
                $error = 'Baptism date cannot be in the future.';
            } elseif (!empty($member->date_of_birth) && strtotime($member->baptism_date) < strtotime($member->date_of_birth)) {
                $error = 'Baptism date cannot be before date of birth.';
            }
        } else {
            // Handle photo upload
            if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
                $uploadResult = uploadFile($_FILES['photo'], '../uploads/', ['jpg', 'jpeg', 'png', 'gif']);
                if ($uploadResult['success']) {
                    // Delete old photo if exists
                    if ($member->photo && file_exists('../uploads/' . $member->photo)) {
                        unlink('../uploads/' . $member->photo);
                    }
                    $member->photo = $uploadResult['filename'];
                } else {
                    $error = $uploadResult['message'];
                }
            }
            
            if (empty($error)) {
                if ($member->update()) {
                    // Save small groups if any selected
                    if (!empty($small_group_ids)) {
                        $member->saveSmallGroups($member->id, $small_group_ids);
                    } else {
                        $member->deleteSmallGroups($member->id);
                    }
                    $success = 'Member updated successfully!';
                    logActivity('member_update', 'members', $member->id);
                } else {
                    $error = 'Failed to update member. Please try again.';
                }
            }
        }
    }
}

// Get households for dropdown
$households = $db->query("SELECT id, household_name FROM households ORDER BY household_name")->fetchAll(\PDO::FETCH_ASSOC);
?>
<?php
$pageTitle = "Edit Member";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Members', 'url' => 'members.php'],
    ['name' => 'Edit Member']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        Edit Member: <?php echo htmlspecialchars($member->first_name . ' ' . $member->last_name); ?>
                    </h2>
                    <p class="text-gray-600 mt-1">Update member information and details</p>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <a href="members.php" class="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Members
                    </a>
                </div>
            </div>
        </div>

        <div class="max-w-4xl mx-auto">
            <?php if ($error): ?>
                <div class="mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="mb-4 bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="space-y-6" id="memberForm">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Personal Information</h3>
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="first_name" class="block text-sm font-medium text-gray-700">First Name *</label>
                                <input type="text" id="first_name" name="first_name" required 
                                       value="<?php echo htmlspecialchars($member->first_name); ?>"
                                       class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            </div>
                            <div>
                                <label for="last_name" class="block text-sm font-medium text-gray-700">Last Name *</label>
                                <input type="text" id="last_name" name="last_name" required 
                                       value="<?php echo htmlspecialchars($member->last_name); ?>"
                                       class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            </div>
                        </div>
                        
                        <div>
                            <label for="middle_name" class="block text-sm font-medium text-gray-700">Middle Name</label>
                            <input type="text" id="middle_name" name="middle_name" 
                                   value="<?php echo htmlspecialchars($member->middle_name ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label for="gender" class="block text-sm font-medium text-gray-700">Gender *</label>
                                <select id="gender" name="gender" required 
                                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                    <option value="">Select Gender</option>
                                    <option value="male" <?php echo $member->gender === 'male' ? 'selected' : ''; ?>>Male</option>
                                    <option value="female" <?php echo $member->gender === 'female' ? 'selected' : ''; ?>>Female</option>
                                    <option value="other" <?php echo $member->gender === 'other' ? 'selected' : ''; ?>>Other</option>
                                </select>
                            </div>
                            
                            <div>
                                <label for="date_of_birth" class="block text-sm font-medium text-gray-700">Date of Birth</label>
                                <input type="date" id="date_of_birth" name="date_of_birth" 
                                       value="<?php echo htmlspecialchars($member->date_of_birth ?? ''); ?>"
                                       class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            </div>
                        </div>
                        
                        <div>
                            <label for="marital_status" class="block text-sm font-medium text-gray-700">Marital Status</label>
                            <select id="marital_status" name="marital_status" 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="single" <?php echo $member->marital_status === 'single' ? 'selected' : ''; ?>>Single</option>
                                <option value="married" <?php echo $member->marital_status === 'married' ? 'selected' : ''; ?>>Married</option>
                                <option value="divorced" <?php echo $member->marital_status === 'divorced' ? 'selected' : ''; ?>>Divorced</option>
                                <option value="widowed" <?php echo $member->marital_status === 'widowed' ? 'selected' : ''; ?>>Widowed</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="photo" class="block text-sm font-medium text-gray-700">Photo</label>
                            <input type="file" id="photo" name="photo" accept="image/*"
                                   class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                            <?php if ($member->photo): ?>
                                <p class="mt-2 text-sm text-gray-500">Current photo: <a href="../uploads/<?php echo htmlspecialchars($member->photo); ?>" target="_blank" class="text-indigo-600 hover:text-indigo-500"><?php echo htmlspecialchars($member->photo); ?></a></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Contact Information</h3>
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                            <input type="email" id="email" name="email" 
                                   value="<?php echo htmlspecialchars($member->email ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="phone" class="block text-sm font-medium text-gray-700">Phone</label>
                            <input type="tel" id="phone" name="phone" pattern="[0-9]*" inputmode="numeric" placeholder="10 digit phone number (e.g., 1234567890)"
                                   value="<?php echo htmlspecialchars($member->phone ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                   oninput="formatPhoneNumber(this)">
                            <p class="text-xs text-gray-500 mt-1">Enter 10 digit phone number</p>
                        </div>
                        
                        <div>
                            <label for="address" class="block text-sm font-medium text-gray-700">Address</label>
                            <textarea id="address" name="address" rows="3" 
                                      class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo htmlspecialchars($member->address ?? ''); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Family & Membership</h3>
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="household_id" class="block text-sm font-medium text-gray-700">Household</label>
                            <select id="household_id" name="household_id" 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="">Select Household (Optional)</option>
                                <?php foreach ($households as $household): ?>
                                    <option value="<?php echo $household['id']; ?>" <?php echo $member->household_id == $household['id'] ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($household['household_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div>
                            <label for="small_group_ids" class="block text-sm font-medium text-gray-700">Small Groups</label>
                            <select id="small_group_ids" name="small_group_ids[]" multiple 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                    size="4">
                                <?php 
                                // Get current member's small groups
                                $currentSmallGroups = [];
                                if ($member->id) {
                                    $stmt = $db->prepare("SELECT small_group_id FROM member_small_groups WHERE member_id = ?");
                                    $stmt->execute([$member->id]);
                                    $currentSmallGroups = $stmt->fetchAll(PDO::FETCH_COLUMN);
                                }
                                ?>
                                <?php foreach ($small_groups as $group): ?>
                                    <option value="<?php echo $group['id']; ?>" <?php echo in_array($group['id'], $currentSmallGroups) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($group['group_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="text-xs text-gray-500 mt-1">Hold Ctrl/Cmd to select multiple groups</p>
                        </div>
                        
                        <div>
                            <label for="family_role" class="block text-sm font-medium text-gray-700">Family Role</label>
                            <select id="family_role" name="family_role" 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="father" <?php echo $member->family_role === 'father' ? 'selected' : ''; ?>>Father</option>
                                <option value="mother" <?php echo $member->family_role === 'mother' ? 'selected' : ''; ?>>Mother</option>
                                <option value="child" <?php echo $member->family_role === 'child' ? 'selected' : ''; ?>>Child</option>
                                <option value="other" <?php echo $member->family_role === 'other' ? 'selected' : ''; ?>>Other</option>
                            </select>
                        </div>
                        
                        <div>
                            <label for="membership_status" class="block text-sm font-medium text-gray-700">Membership Status</label>
                            <select id="membership_status" name="membership_status" 
                                    class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <option value="visitor" <?php echo $member->membership_status === 'visitor' ? 'selected' : ''; ?>>Visitor</option>
                                <option value="active" <?php echo $member->membership_status === 'active' ? 'selected' : ''; ?>>Active</option>
                                <option value="inactive" <?php echo $member->membership_status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                                <option value="deceased" <?php echo $member->membership_status === 'deceased' ? 'selected' : ''; ?>>Deceased</option>
                            </select>
                        </div>
                        
                        <div class="flex items-center">
                            <input type="checkbox" id="membership_class_completed" name="membership_class_completed" value="1" 
                                   <?php echo $member->membership_class_completed ? 'checked' : ''; ?>
                                   class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                            <label for="membership_class_completed" class="ml-2 block text-sm text-gray-900">
                                Membership class completed
                            </label>
                        </div>
                        
                        <div>
                            <label for="baptism_date" class="block text-sm font-medium text-gray-700">Baptism Date</label>
                            <input type="date" id="baptism_date" name="baptism_date" 
                                   value="<?php echo htmlspecialchars($member->baptism_date ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Additional Information</h3>
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="spiritual_gifts" class="block text-sm font-medium text-gray-700">Spiritual Gifts</label>
                            <textarea id="spiritual_gifts" name="spiritual_gifts" rows="3" 
                                      class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo htmlspecialchars($member->spiritual_gifts ?? ''); ?></textarea>
                        </div>
                        
                        <div>
                            <label for="notes" class="block text-sm font-medium text-gray-700">Notes <span class="text-gray-500">(max 50 words)</span></label>
                            <textarea id="notes" name="notes" rows="4" 
                                      class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                                      oninput="updateWordCount(this, 'notesCount', 50); enforceWordLimit(this, 50)"><?php echo htmlspecialchars($member->notes ?? ''); ?></textarea>
                            <p class="text-sm text-gray-500 mt-1">Words: <span id="notesCount"><?php echo !empty($member->notes) ? getWordCount($member->notes) : 0; ?></span>/50</p>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end space-x-3">
                    <a href="members.php" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                        Cancel
                    </a>
                    <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                        Update Member
                    </button>
                </div>
            </form>
            
            <script>
            // Word count function
            function updateWordCount(textarea, displayId, limit) {
                const text = textarea.value.trim();
                const words = text === '' ? 0 : text.split(/\s+/).filter(word => word.length > 0).length;
                const display = document.getElementById(displayId);
                display.textContent = words;
                
                if (words > limit) {
                    display.classList.add('text-red-600');
                    display.classList.remove('text-gray-500');
                } else {
                    display.classList.remove('text-red-600');
                    display.classList.add('text-gray-500');
                }
            }
            
            // Form validation
            document.getElementById('memberForm').addEventListener('submit', function(e) {
                const firstName = document.getElementById('first_name').value.trim();
                const lastName = document.getElementById('last_name').value.trim();
                const middleName = document.getElementById('middle_name').value.trim();
                const phone = document.getElementById('phone').value;
                const notes = document.getElementById('notes').value;
                const gender = document.getElementById('gender').value;
                const dateOfBirth = document.getElementById('date_of_birth').value;
                const baptismDate = document.getElementById('baptism_date').value;
                const familyRole = document.getElementById('family_role').value;
                
                // Name validation - letters only
                const namePattern = /^[a-zA-Z\s\-\'.\x{00C0}-\x{024F}]+$/;
                
                if (firstName && !namePattern.test(firstName)) {
                    alert('First name should only contain letters (a-z, A-Z). Numbers are not allowed.');
                    e.preventDefault();
                    return false;
                }
                
                if (lastName && !namePattern.test(lastName)) {
                    alert('Last name should only contain letters (a-z, A-Z). Numbers are not allowed.');
                    e.preventDefault();
                    return false;
                }
                
                if (middleName && !namePattern.test(middleName)) {
                    alert('Middle name should only contain letters (a-z, A-Z). Numbers are not allowed.');
                    e.preventDefault();
                    return false;
                }
                
                // Phone validation - numbers only
                if (phone && !/^[0-9\s\-\(\)\+]+$/.test(phone)) {
                    alert('Phone number should only contain numbers. Letters are not allowed.');
                    e.preventDefault();
                    return false;
                }
                
                // Notes word limit
                const wordCount = notes.trim() === '' ? 0 : notes.trim().split(/\s+/).filter(word => word.length > 0).length;
                if (wordCount > 50) {
                    alert('Notes should not exceed 50 words. Please shorten your notes.');
                    e.preventDefault();
                    return false;
                }
                
                // Gender and name validation - BLOCK if mismatch
                const name = firstName.toLowerCase().trim();
                
                // Check if name strongly suggests a different gender
                if (gender === 'male') {
                    const strongMaleNames = ['john', 'james', 'michael', 'david', 'richard', 'charles', 'joseph', 'thomas', 'christopher', 'daniel', 'matthew', 'anthony', 'mark', 'donald', 'steven', 'paul', 'andrew', 'joshua', 'kenneth', 'kevin', 'brian', 'george', 'edward', 'ronald', 'timothy', 'jason', 'jeffrey', 'ryan', 'jacob', 'gary', 'nicholas', 'eric', 'jonathan', 'stephen'];
                    const femaleNames = ['mary', 'patricia', 'jennifer', 'linda', 'elizabeth', 'barbara', 'susan', 'jessica', 'sarah', 'karen', 'lisa', 'nancy', 'betty', 'margaret', 'sandra', 'ashley', 'kimberly', 'emily', 'donna', 'michelle', 'dorothy', 'carol', 'amanda', 'melissa', 'deborah', 'stephanie', 'rebecca', 'sharon', 'laura', 'cynthia', 'kathleen', 'amy', 'shirley', 'angela', 'helen', 'anna', 'brenda', 'pamela', 'emma', 'nicole', 'hermina', 'irene', 'jane', 'lorraine', 'marie', 'janet', 'catherine', 'frances', 'ann', 'joyce', 'diane', 'alice', 'julie', 'heather', 'teresa'];
                    
                    if (femaleNames.includes(name)) {
                        alert('Error: The name "' + firstName + '" is typically a female name. Please select Female as the gender.');
                        e.preventDefault();
                        return false;
                    }
                } else if (gender === 'female') {
                    const strongFemaleNames = ['mary', 'patricia', 'jennifer', 'linda', 'elizabeth', 'barbara', 'susan', 'jessica', 'sarah', 'karen', 'lisa', 'nancy', 'betty', 'margaret', 'sandra', 'ashley', 'kimberly', 'emily', 'donna', 'michelle', 'dorothy', 'carol', 'amanda', 'melissa', 'deborah', 'stephanie', 'rebecca', 'sharon', 'laura', 'cynthia', 'kathleen', 'amy', 'shirley', 'angela', 'helen', 'anna', 'brenda', 'pamela', 'emma', 'nicole'];
                    const maleNames = ['john', 'james', 'michael', 'david', 'richard', 'charles', 'joseph', 'thomas', 'christopher', 'daniel', 'matthew', 'anthony', 'mark', 'donald', 'steven', 'paul', 'andrew', 'joshua', 'kenneth', 'kevin', 'brian', 'george', 'edward', 'ronald', 'timothy', 'jason', 'jeffrey', 'ryan', 'jacob', 'gary', 'nicholas', 'eric', 'jonathan', 'stephen'];
                    
                    if (maleNames.includes(name)) {
                        alert('Error: The name "' + firstName + '" is typically a male name. Please select Male as the gender.');
                        e.preventDefault();
                        return false;
                    }
                }
                
                // Family role validation - must match gender
                if (familyRole === 'father' && gender !== 'male') {
                    alert('Error: Family role "Father" can only be selected with Male gender.');
                    e.preventDefault();
                    return false;
                }
                if (familyRole === 'mother' && gender !== 'female') {
                    alert('Error: Family role "Mother" can only be selected with Female gender.');
                    e.preventDefault();
                    return false;
                }
                
                // Baptism date validation
                if (baptismDate && dateOfBirth) {
                    const dob = new Date(dateOfBirth);
                    const baptism = new Date(baptismDate);
                    if (baptism < dob) {
                        alert('Baptism date cannot be before date of birth.');
                        e.preventDefault();
                        return false;
                    }
                }
                
                if (baptismDate && !dateOfBirth) {
                    const today = new Date();
                    const baptism = new Date(baptismDate);
                    if (baptism > today) {
                        alert('Baptism date cannot be in the future. Please enter the date of birth first.');
                        e.preventDefault();
                        return false;
                    }
                }
                
                return true;
            });
            
            // Add input restrictions for name fields
            document.getElementById('first_name').addEventListener('input', function(e) {
                this.value = this.value.replace(/[0-9]/g, '');
            });
            
            document.getElementById('last_name').addEventListener('input', function(e) {
                this.value = this.value.replace(/[0-9]/g, '');
            });
            
            document.getElementById('middle_name').addEventListener('input', function(e) {
                this.value = this.value.replace(/[0-9]/g, '');
            });
            
            // Add input restrictions for phone field
            document.getElementById('phone').addEventListener('input', function(e) {
                this.value = this.value.replace(/[a-zA-Z]/g, '');
            });
            
            // Add phone formatting
            function formatPhoneNumber(input) {
                let value = input.value.replace(/\D/g, '');
                if (value.length > 10) {
                    value = value.substring(0, 10);
                }
                input.value = value;
            }
            
            // Add enforce word limit function
            function enforceWordLimit(textarea, limit) {
                const text = textarea.value.trim();
                const words = text === '' ? [] : text.split(/\s+/);
                
                if (words.length > limit) {
                    const allowedText = words.slice(0, limit).join(' ');
                    textarea.value = allowedText;
                    const display = document.getElementById('notesCount');
                    if (display) {
                        display.textContent = limit;
                    }
                    return false;
                }
                return true;
            }
            
            // Add gender validation arrays
            const commonMaleNames = ['john', 'james', 'michael', 'david', 'richard', 'charles', 'joseph', 'thomas', 'christopher', 'daniel', 'matthew', 'anthony', 'mark', 'donald', 'steven', 'paul', 'andrew', 'joshua', 'kenneth', 'kevin', 'brian', 'george', 'edward', 'ronald', 'timothy', 'jason', 'jeffrey', 'ryan', 'jacob'];
            const commonFemaleNames = ['mary', 'patricia', 'jennifer', 'linda', 'elizabeth', 'barbara', 'susan', 'jessica', 'sarah', 'karen', 'lisa', 'nancy', 'betty', 'margaret', 'sandra', 'ashley', 'kimberly', 'emily', 'donna', 'michelle', 'dorothy', 'carol', 'amanda', 'melissa', 'deborah'];
            
            // Initialize baptism date min on page load
            window.addEventListener('DOMContentLoaded', function() {
                const dob = document.getElementById('date_of_birth').value;
                const baptismDateInput = document.getElementById('baptism_date');
                if (dob) {
                    baptismDateInput.min = dob;
                }
            });
            
            // Date of birth change - update baptism date min
            document.getElementById('date_of_birth').addEventListener('change', function() {
                const baptismDateInput = document.getElementById('baptism_date');
                if (this.value) {
                    baptismDateInput.min = this.value;
                } else {
                    baptismDateInput.removeAttribute('min');
                }
            });
            </script>
        </div>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
