<?php
require_once '../config/config.php';
require_once '../classes/Member.php';

use App\Database;
use App\Member;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();
$member = new Member($db);

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

$members = $member->getAll($page, 10, $search, $status);
$totalCount = $member->getTotalCount($search, $status);
$paginationData = getPaginationData($page, $totalCount, 10);
?>
<?php
$pageTitle = "Members";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Members']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0 mb-8">
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                <div class="mb-4 sm:mb-0">
                    <h1 class="text-3xl font-bold text-gray-900 mb-2">Members</h1>
                    <p class="text-gray-600">Manage your church members and their information</p>
                </div>
                <div class="flex space-x-3">
                    <button class="bg-white border border-gray-300 rounded-lg px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors duration-200">
                        <i class="fas fa-download mr-2"></i>
                        Export
                    </button>
                    <a href="member-add.php" class="inline-flex items-center bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-lg font-semibold hover:from-indigo-700 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl">
                        <i class="fas fa-plus mr-2"></i>
                        Add Member
                    </a>
                </div>
            </div>
        </div>

        <!-- Search and filters -->
        <div class="bg-white shadow-lg rounded-2xl mb-8 overflow-hidden">
            <div class="px-6 py-5 border-b border-gray-200 bg-gradient-to-r from-gray-50 to-blue-50">
                <div class="flex items-center">
                    <div class="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center mr-3">
                        <i class="fas fa-search text-indigo-600"></i>
                    </div>
                    <h3 class="text-lg font-semibold text-gray-900">Search & Filter</h3>
                </div>
            </div>
            <div class="p-6">
                <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div class="md:col-span-2">
                        <label for="search" class="block text-sm font-medium text-gray-700 mb-2">Search Members</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-search text-gray-400"></i>
                            </div>
                            <input type="text" id="search" name="search" placeholder="Search by name or email..." 
                                   value="<?php echo htmlspecialchars($search); ?>"
                                   class="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200">
                        </div>
                    </div>
                    <div>
                        <label for="status" class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                        <select id="status" name="status" class="block w-full px-3 py-3 border border-gray-300 rounded-xl shadow-sm focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all duration-200">
                            <option value="">All Status</option>
                            <option value="active" <?php echo $status === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $status === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                            <option value="visitor" <?php echo $status === 'visitor' ? 'selected' : ''; ?>>Visitor</option>
                            <option value="deceased" <?php echo $status === 'deceased' ? 'selected' : ''; ?>>Deceased</option>
                        </select>
                    </div>
                    <div class="flex items-end">
                        <button type="submit" class="w-full bg-indigo-600 text-white px-4 py-3 rounded-xl font-semibold hover:bg-indigo-700 transition-colors duration-200 shadow-lg hover:shadow-xl">
                            <i class="fas fa-search mr-2"></i>
                            Search
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Members table -->
        <div class="bg-white shadow-lg rounded-2xl overflow-hidden">
            <div class="px-6 py-5 border-b border-gray-200 bg-gradient-to-r from-indigo-50 to-purple-50">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="w-8 h-8 bg-indigo-100 rounded-lg flex items-center justify-center mr-3">
                            <i class="fas fa-users text-indigo-600"></i>
                        </div>
                        <h3 class="text-lg font-semibold text-gray-900">Members List</h3>
                    </div>
                    <div class="text-sm text-gray-500">
                        Showing <?php echo count($members); ?> of <?php echo $totalCount; ?> members
                    </div>
                </div>
            </div>
            
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Member</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Contact</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Household</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php foreach ($members as $member): ?>
                        <tr class="hover:bg-gray-50 transition-colors duration-200">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-12 w-12">
                                        <?php if ($member['photo']): ?>
                                            <img class="h-12 w-12 rounded-full object-cover" src="../uploads/<?php echo htmlspecialchars($member['photo']); ?>" alt="">
                                        <?php else: ?>
                                            <div class="h-12 w-12 rounded-full bg-gradient-to-r from-indigo-500 to-purple-600 flex items-center justify-center">
                                                <span class="text-sm font-bold text-white"><?php echo strtoupper(substr($member['first_name'], 0, 1)); ?></span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="ml-4">
                                        <div class="text-sm font-semibold text-gray-900">
                                            <?php echo htmlspecialchars($member['first_name'] . ' ' . $member['last_name']); ?>
                                        </div>
                                        <div class="text-sm text-gray-500">
                                            <i class="fas fa-<?php echo $member['gender'] === 'Male' ? 'mars' : 'venus'; ?> mr-1"></i>
                                            <?php echo htmlspecialchars($member['gender']); ?>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="text-sm text-gray-900">
                                    <div class="flex items-center mb-1">
                                        <i class="fas fa-envelope text-gray-400 mr-2"></i>
                                        <?php echo htmlspecialchars($member['email']); ?>
                                    </div>
                                    <div class="flex items-center">
                                        <i class="fas fa-phone text-gray-400 mr-2"></i>
                                        <?php echo htmlspecialchars($member['phone']); ?>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold 
                                    <?php 
                                    switch($member['membership_status']) {
                                        case 'active': echo 'bg-green-100 text-green-800'; break;
                                        case 'inactive': echo 'bg-yellow-100 text-yellow-800'; break;
                                        case 'visitor': echo 'bg-blue-100 text-blue-800'; break;
                                        case 'deceased': echo 'bg-gray-100 text-gray-800'; break;
                                        default: echo 'bg-gray-100 text-gray-800';
                                    }
                                    ?>">
                                    <div class="w-2 h-2 rounded-full mr-2 
                                        <?php 
                                        switch($member['membership_status']) {
                                            case 'active': echo 'bg-green-400'; break;
                                            case 'inactive': echo 'bg-yellow-400'; break;
                                            case 'visitor': echo 'bg-blue-400'; break;
                                            case 'deceased': echo 'bg-gray-400'; break;
                                            default: echo 'bg-gray-400';
                                        }
                                        ?>"></div>
                                    <?php echo ucfirst($member['membership_status']); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                <div class="flex items-center">
                                    <i class="fas fa-home text-gray-400 mr-2"></i>
                                    <?php echo htmlspecialchars($member['household_name'] ?? 'N/A'); ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <div class="flex space-x-2">
                                    <a href="member-edit.php?id=<?php echo $member['id']; ?>" 
                                       class="inline-flex items-center px-3 py-1 rounded-lg text-xs font-semibold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 transition-colors duration-200">
                                        <i class="fas fa-edit mr-1"></i>
                                        Edit
                                    </a>
                                    <a href="member-view.php?id=<?php echo $member['id']; ?>" 
                                       class="inline-flex items-center px-3 py-1 rounded-lg text-xs font-semibold text-green-600 bg-green-50 hover:bg-green-100 transition-colors duration-200">
                                        <i class="fas fa-eye mr-1"></i>
                                        View
                                    </a>
                                    <a href="member-delete.php?id=<?php echo $member['id']; ?>" 
                                       class="inline-flex items-center px-3 py-1 rounded-lg text-xs font-semibold text-red-600 bg-red-50 hover:bg-red-100 transition-colors duration-200"
                                       onclick="return confirm('Are you sure you want to delete this member? This action cannot be undone.')">
                                        <i class="fas fa-trash mr-1"></i>
                                        Delete
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Pagination -->
        <?php if ($paginationData['total_pages'] > 1): ?>
            <div class="mt-8">
                <div class="bg-white rounded-2xl shadow-lg p-6">
                    <?php echo generatePagination($paginationData, 'members.php'); ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
