<?php
require_once '../config/config.php';
require_once '../classes/Event.php';

use App\Database;
use App\Event;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$search = $_GET['search'] ?? '';
$speaker = $_GET['speaker'] ?? '';
$topic = $_GET['topic'] ?? '';
$dateFrom = $_GET['date_from'] ?? '';
$dateTo = $_GET['date_to'] ?? '';

// Build query for sermons
$query = "SELECT * FROM sermons WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (title LIKE :search OR speaker LIKE :search OR description LIKE :search)";
    $params[':search'] = "%$search%";
}

if (!empty($speaker)) {
    $query .= " AND speaker LIKE :speaker";
    $params[':speaker'] = "%$speaker%";
}

if (!empty($topic)) {
    $query .= " AND topic LIKE :topic";
    $params[':topic'] = "%$topic%";
}

if (!empty($dateFrom)) {
    $query .= " AND sermon_date >= :date_from";
    $params[':date_from'] = $dateFrom;
}

if (!empty($dateTo)) {
    $query .= " AND sermon_date <= :date_to";
    $params[':date_to'] = $dateTo;
}

$query .= " ORDER BY sermon_date DESC";

// Get total count
$countQuery = str_replace("SELECT *", "SELECT COUNT(*) as total", $query);
$stmt = $db->prepare($countQuery);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$totalCount = $stmt->fetch(\PDO::FETCH_ASSOC)['total'];

// Get paginated results
$offset = ($page - 1) * 10;
$query .= " LIMIT 10 OFFSET $offset";

$stmt = $db->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$sermons = $stmt->fetchAll(\PDO::FETCH_ASSOC);

$paginationData = getPaginationData($page, $totalCount, 10);

// Get unique speakers and topics for filters
$speakers = $db->query("SELECT DISTINCT speaker FROM sermons ORDER BY speaker")->fetchAll(\PDO::FETCH_COLUMN);
$topics = $db->query("SELECT DISTINCT topic FROM sermons WHERE topic IS NOT NULL AND topic != '' ORDER BY topic")->fetchAll(\PDO::FETCH_COLUMN);
?>
<?php
$pageTitle = "Sermons";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Sermons']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        Sermons Management
                    </h2>
                    <p class="text-gray-600 mt-1">Manage church sermons and messages</p>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <a href="sermon-add.php" class="ml-3 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 transition-colors duration-200">
                        <i class="fas fa-plus mr-2"></i>
                        Add New Sermon
                    </a>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="bg-white shadow rounded-lg mb-6">
            <div class="px-4 py-5 sm:p-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Filter Sermons</h3>
                <form method="GET" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
                    <div>
                        <label for="search" class="block text-sm font-medium text-gray-700">Search</label>
                        <input type="text" id="search" name="search" value="<?php echo htmlspecialchars($search); ?>"
                               class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                    <div>
                        <label for="speaker" class="block text-sm font-medium text-gray-700">Speaker</label>
                        <select id="speaker" name="speaker" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <option value="">All Speakers</option>
                            <?php foreach ($speakers as $s): ?>
                                <option value="<?php echo htmlspecialchars($s); ?>" <?php echo $speaker === $s ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($s); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="topic" class="block text-sm font-medium text-gray-700">Topic</label>
                        <select id="topic" name="topic" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            <option value="">All Topics</option>
                            <?php foreach ($topics as $t): ?>
                                <option value="<?php echo htmlspecialchars($t); ?>" <?php echo $topic === $t ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($t); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="date_from" class="block text-sm font-medium text-gray-700">From Date</label>
                        <input type="date" id="date_from" name="date_from" value="<?php echo htmlspecialchars($dateFrom); ?>"
                               class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                    <div>
                        <label for="date_to" class="block text-sm font-medium text-gray-700">To Date</label>
                        <input type="date" id="date_to" name="date_to" value="<?php echo htmlspecialchars($dateTo); ?>"
                               class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                    </div>
                    <div class="lg:col-span-5 flex space-x-4">
                        <button type="submit" class="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700">
                            Filter
                        </button>
                        <a href="sermons.php" class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                            Clear
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Sermons list -->
        <div class="bg-white shadow overflow-hidden sm:rounded-md">
            <?php if (empty($sermons)): ?>
                <div class="text-center py-12">
                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                    </svg>
                    <h3 class="mt-2 text-sm font-medium text-gray-900">No sermons found</h3>
                    <p class="mt-1 text-sm text-gray-500">Get started by adding a new sermon.</p>
                    <div class="mt-6">
                        <a href="sermon-add.php" class="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                            Add New Sermon
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <ul class="divide-y divide-gray-200">
                    <?php foreach ($sermons as $sermon): ?>
                        <li>
                            <div class="px-4 py-4 flex items-center justify-between">
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center justify-between">
                                        <p class="text-sm font-medium text-indigo-600 truncate">
                                            <?php echo htmlspecialchars($sermon['title']); ?>
                                        </p>
                                        <div class="ml-2 flex-shrink-0 flex">
                                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                                <?php echo formatDate($sermon['sermon_date']); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="mt-2 flex items-center text-sm text-gray-500">
                                        <p class="truncate">
                                            by <strong><?php echo htmlspecialchars($sermon['speaker']); ?></strong>
                                            <?php if ($sermon['topic']): ?>
                                                • <?php echo htmlspecialchars($sermon['topic']); ?>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <?php if ($sermon['description']): ?>
                                        <div class="mt-2">
                                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars(substr($sermon['description'], 0, 100)) . (strlen($sermon['description']) > 100 ? '...' : ''); ?></p>
                                        </div>
                                    <?php endif; ?>
                                    <div class="mt-2 flex space-x-4 text-sm text-gray-500">
                                        <?php if ($sermon['video_url']): ?>
                                            <span class="inline-flex items-center">
                                                <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                    <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"></path>
                                                </svg>
                                                Video
                                            </span>
                                        <?php endif; ?>
                                        <?php if ($sermon['audio_url']): ?>
                                            <span class="inline-flex items-center">
                                                <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM15.657 6.343a1 1 0 011.414 0A9.972 9.972 0 0119 12a9.972 9.972 0 01-1.929 5.657 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 12a7.971 7.971 0 00-1.343-4.243 1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                                </svg>
                                                Audio
                                            </span>
                                        <?php endif; ?>
                                        <?php if ($sermon['notes_pdf']): ?>
                                            <span class="inline-flex items-center">
                                                <svg class="w-4 h-4 mr-1" fill="currentColor" viewBox="0 0 20 20">
                                                    <path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clip-rule="evenodd"></path>
                                                </svg>
                                                Notes
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="ml-4 flex-shrink-0 flex space-x-2">
                                    <a href="sermon-edit.php?id=<?php echo $sermon['id']; ?>" class="text-indigo-600 hover:text-indigo-900 text-sm font-medium">
                                        Edit
                                    </a>
                                    <a href="sermon-delete.php?id=<?php echo $sermon['id']; ?>&csrf_token=<?php echo urlencode(generateCSRFToken()); ?>" 
                                       onclick="return confirm('Are you sure you want to delete this sermon?')"
                                       class="text-red-600 hover:text-red-900 text-sm font-medium">
                                        Delete
                                    </a>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <!-- Pagination -->
                <?php if ($paginationData['total_pages'] > 1): ?>
                    <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                        <?php echo generatePagination($paginationData, 'sermons.php'); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
