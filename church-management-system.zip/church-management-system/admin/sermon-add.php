<?php
require_once '../config/config.php';

use App\Database;

requireAdminLogin();

$database = new Database();
$db = $database->getConnection();

function tableHasColumn($db, $tableName, $columnName) {
    $stmt = $db->prepare("SHOW COLUMNS FROM {$tableName} LIKE ?");
    $stmt->execute([$columnName]);
    return $stmt->rowCount() > 0;
}

$error = '';
$success = '';

if ($_POST) {
    if (!verifyCSRFToken($_POST['csrf_token'] ?? '')) {
        $error = 'Invalid request. Please try again.';
    } else {
        $title = sanitizeInput($_POST['title'] ?? '');
        $speaker = sanitizeInput($_POST['speaker'] ?? '');
        $sermonDate = $_POST['sermon_date'] ?? '';
        $videoUrl = sanitizeInput($_POST['video_url'] ?? '');
        $audioUrl = sanitizeInput($_POST['audio_url'] ?? '');
        $liveStreamUrl = sanitizeInput($_POST['live_stream_url'] ?? '');
        $isLive = isset($_POST['is_live']) ? 1 : 0;
        $description = sanitizeInput($_POST['description'] ?? '');
        $scriptureReference = sanitizeInput($_POST['scripture_reference'] ?? '');
        $topic = sanitizeInput($_POST['topic'] ?? '');
        
        if (empty($title) || empty($speaker) || empty($sermonDate)) {
            $error = 'Please fill in all required fields.';
        } elseif (date('Y', strtotime($sermonDate)) < date('Y')) {
            $error = 'The sermon date cannot be from a past year.';
        } else {
            try {
                // Handle file upload for notes PDF
                $notesPdf = '';
                if (isset($_FILES['notes_pdf']) && $_FILES['notes_pdf']['error'] === UPLOAD_ERR_OK) {
                    $uploadResult = uploadFile($_FILES['notes_pdf'], 'uploads/sermons/', ['pdf']);
                    if ($uploadResult['success']) {
                        $notesPdf = $uploadResult['filename'];
                    } else {
                        $error = $uploadResult['message'];
                    }
                }
                
                if (empty($error)) {
                    $columns = ['title', 'speaker', 'sermon_date', 'video_url', 'audio_url', 'notes_pdf', 'description', 'scripture_reference', 'topic'];
                    $values = [$title, $speaker, $sermonDate, $videoUrl, $audioUrl, $notesPdf, $description, $scriptureReference, $topic];

                    if (tableHasColumn($db, 'sermons', 'live_stream_url')) {
                        $columns[] = 'live_stream_url';
                        $values[] = $liveStreamUrl;
                    }

                    if (tableHasColumn($db, 'sermons', 'is_live')) {
                        $columns[] = 'is_live';
                        $values[] = $isLive;
                    }

                    $placeholders = implode(', ', array_fill(0, count($columns), '?'));
                    $columnList = implode(', ', $columns);

                    $stmt = $db->prepare("INSERT INTO sermons ({$columnList}) VALUES ({$placeholders})");
                    $result = $stmt->execute($values);
                    
                    if ($result) {
                        $sermonId = $db->lastInsertId();
                        $success = 'Sermon added successfully!';
                        logActivity('sermon_add', 'sermons', $sermonId);
                        
                        // Send email notification to all members
                        $emailTitle = 'New Sermon: ' . $title;
                        $descriptionHtml = $description ? '<p>' . htmlspecialchars($description) . '</p>' : '';
                        $scriptureHtml = $scriptureReference ? '<p><strong>Scripture:</strong> ' . htmlspecialchars($scriptureReference) . '</p>' : '';
                        $emailContent = buildNotificationEmail(
                            $emailTitle,
                            "<p>Dear {member_first_name},</p>
                            <p>A new sermon has been added: <strong>" . $title . "</strong></p>
                            <p><strong>Speaker:</strong> " . $speaker . "</p>
                            <p><strong>Date:</strong> " . date('F j, Y', strtotime($sermonDate)) . "</p>
                            " . $descriptionHtml . "
                            " . $scriptureHtml . "
                            <p>You can view the sermon by clicking the button below.</p>",
                            'View Sermons',
                            BASE_URL . 'sermons.php'
                        );
                        
                        $notificationResult = notifyAllMembers($emailTitle, $emailContent, 'sermon');
                        
                        if ($notificationResult['success']) {
                            $success .= " Email notifications sent to {$notificationResult['sent']} members.";
                        }
                        
                        // Clear form data
                        $_POST = [];
                    } else {
                        $error = 'Failed to add sermon. Please try again.';
                    }
                }
            } catch (Exception $e) {
                $error = 'An error occurred: ' . $e->getMessage();
            }
        }
    }
}
?>
<?php
$pageTitle = "Add Sermon";
$breadcrumbs = [
    ['name' => 'Dashboard', 'url' => 'dashboard.php'],
    ['name' => 'Sermons', 'url' => 'sermons.php'],
    ['name' => 'Add Sermon']
];

// Start output buffering to capture page content
ob_start();
?>

    <div class="animate-fade-in">
        <!-- Page header -->
        <div class="px-4 py-6 sm:px-0">
            <div class="md:flex md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h2 class="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
                        Add New Sermon
                    </h2>
                    <p class="text-gray-600 mt-1">Create a new sermon entry with media and resources</p>
                </div>
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <a href="sermons.php" class="ml-3 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors duration-200">
                        <i class="fas fa-arrow-left mr-2"></i>
                        Back to Sermons
                    </a>
                </div>
            </div>
        </div>

        <div class="max-w-3xl mx-auto">
            <?php if ($error): ?>
                <div class="mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="mb-4 bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="space-y-6">
                <input type="hidden" name="csrf_token" value="<?php echo generateCSRFToken(); ?>">
                
                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Sermon Information</h3>
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="title" class="block text-sm font-medium text-gray-700">Title *</label>
                            <input type="text" id="title" name="title" required 
                                   value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="speaker" class="block text-sm font-medium text-gray-700">Speaker *</label>
                                <input type="text" id="speaker" name="speaker" required 
                                       value="<?php echo htmlspecialchars($_POST['speaker'] ?? ''); ?>"
                                       class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            </div>
                            
                            <div>
                                <label for="sermon_date" class="block text-sm font-medium text-gray-700">Sermon Date *</label>
                                <input type="date" id="sermon_date" name="sermon_date" required 
                                       value="<?php echo htmlspecialchars($_POST['sermon_date'] ?? ''); ?>"
                                       class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                            </div>
                        </div>
                        
                        <div>
                            <label for="topic" class="block text-sm font-medium text-gray-700">Topic</label>
                            <input type="text" id="topic" name="topic" 
                                   value="<?php echo htmlspecialchars($_POST['topic'] ?? ''); ?>"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="scripture_reference" class="block text-sm font-medium text-gray-700">Scripture Reference</label>
                            <input type="text" id="scripture_reference" name="scripture_reference" 
                                   value="<?php echo htmlspecialchars($_POST['scripture_reference'] ?? ''); ?>"
                                   placeholder="e.g., John 3:16"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                            <textarea id="description" name="description" rows="4" 
                                      class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"><?php echo htmlspecialchars($_POST['description'] ?? ''); ?></textarea>
                        </div>
                    </div>
                </div>

                <div class="bg-white shadow px-4 py-5 sm:rounded-lg sm:p-6">
                    <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Media & Resources</h3>
                    
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label for="video_url" class="block text-sm font-medium text-gray-700">Video URL</label>
                            <input type="url" id="video_url" name="video_url" 
                                   value="<?php echo htmlspecialchars($_POST['video_url'] ?? ''); ?>"
                                   placeholder="https://youtube.com/watch?v=..."
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>
                        
                        <div>
                            <label for="audio_url" class="block text-sm font-medium text-gray-700">Audio URL</label>
                            <input type="url" id="audio_url" name="audio_url"
                                   value="<?php echo htmlspecialchars($_POST['audio_url'] ?? ''); ?>"
                                   placeholder="https://example.com/audio.mp3"
                                   class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                        </div>

                        <div class="space-y-4">
                            <div class="flex items-center">
                                <input type="checkbox" id="is_live" name="is_live" value="1"
                                       <?php echo isset($_POST['is_live']) ? 'checked' : ''; ?>
                                       class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                <label for="is_live" class="ml-2 block text-sm text-gray-900">
                                    This sermon will be streamed live
                                </label>
                            </div>

                            <div id="live_stream_container" class="<?php echo isset($_POST['is_live']) ? '' : 'hidden'; ?>">
                                <label for="live_stream_url" class="block text-sm font-medium text-gray-700">Live Stream URL</label>
                                <input type="url" id="live_stream_url" name="live_stream_url"
                                       value="<?php echo htmlspecialchars($_POST['live_stream_url'] ?? ''); ?>"
                                       placeholder="https://youtube.com/watch?v=..."
                                       class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm">
                                <p class="mt-2 text-sm text-gray-500">Enter the URL of the live stream (YouTube, Vimeo, etc.)</p>
                            </div>
                        </div>

                        <div>
                            <label for="notes_pdf" class="block text-sm font-medium text-gray-700">Notes PDF</label>
                            <input type="file" id="notes_pdf" name="notes_pdf" accept=".pdf"
                                   class="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                            <p class="mt-2 text-sm text-gray-500">Upload a PDF file with sermon notes (optional)</p>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end space-x-3">
                    <a href="sermons.php" class="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                        Cancel
                    </a>
                    <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                        Add Sermon
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Show/hide live stream URL based on checkbox
        document.getElementById('is_live').addEventListener('change', function() {
            const container = document.getElementById('live_stream_container');
            if (this.checked) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        });
    </script>

<?php
// Capture the page content
$pageContent = ob_get_clean();

// Include the admin layout
include '../includes/admin-layout.php';
?>
