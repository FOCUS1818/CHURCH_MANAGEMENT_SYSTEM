<?php
/**
 * Password Hashing Utility
 * Church Management System
 */

require_once 'config/config.php';

// Check if password was submitted
$password = '';
$hashedPassword = '';
$error = '';

if ($_POST) {
    $password = $_POST['password'] ?? '';
    
    if (empty($password)) {
        $error = 'Please enter a password to hash.';
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Hash Generator - Church Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div class="max-w-md w-full space-y-8">
            <div>
                <h2 class="mt-6 text-center text-3xl font-extrabold text-gray-900">
                    Password Hash Generator
                </h2>
                <p class="mt-2 text-center text-sm text-gray-600">
                    Generate secure password hashes for the Church Management System
                </p>
            </div>
            
            <form class="mt-8 space-y-6" method="POST">
                <div class="rounded-md shadow-sm -space-y-px">
                    <div>
                        <label for="password" class="sr-only">Password</label>
                        <input id="password" name="password" type="password" required 
                               class="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm" 
                               placeholder="Enter password to hash" 
                               value="<?php echo htmlspecialchars($password); ?>">
                    </div>
                </div>

                <?php if ($error): ?>
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <div>
                    <button type="submit" 
                            class="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        Generate Hash
                    </button>
                </div>
            </form>

            <?php if ($hashedPassword): ?>
                <div class="mt-8">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Generated Hash:</h3>
                    <div class="bg-gray-100 p-4 rounded-md">
                        <code class="text-sm text-gray-800 break-all"><?php echo htmlspecialchars($hashedPassword); ?></code>
                    </div>
                    
                    <div class="mt-4">
                        <button onclick="copyToClipboard('<?php echo htmlspecialchars($hashedPassword); ?>')" 
                                class="bg-gray-600 text-white px-4 py-2 rounded-md hover:bg-gray-700 text-sm">
                            Copy to Clipboard
                        </button>
                    </div>
                    
                    <div class="mt-4 text-sm text-gray-600">
                        <p><strong>Password Length:</strong> <?php echo strlen($password); ?> characters</p>
                        <p><strong>Hash Length:</strong> <?php echo strlen($hashedPassword); ?> characters</p>
                        <p><strong>Algorithm:</strong> <?php echo password_get_info($hashedPassword)['algoName']; ?></p>
                    </div>
                </div>
            <?php endif; ?>

            <div class="mt-8 text-center">
                <a href="index.php" class="text-indigo-600 hover:text-indigo-500">
                    ← Back to Home
                </a>
            </div>
        </div>
    </div>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(function() {
                alert('Hash copied to clipboard!');
            }, function(err) {
                console.error('Could not copy text: ', err);
                // Fallback for older browsers
                const textArea = document.createElement('textarea');
                textArea.value = text;
                document.body.appendChild(textArea);
                textArea.select();
                document.execCommand('copy');
                document.body.removeChild(textArea);
                alert('Hash copied to clipboard!');
            });
        }
    </script>
</body>
</html>
