<?php
require_once 'config/config.php';

use App\Database;

$database = new Database();
$db = $database->getConnection();

// Get filter parameters
$speaker = $_GET['speaker'] ?? '';
$topic = $_GET['topic'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';

// Build query
$query = "SELECT * FROM sermons WHERE 1=1";
$params = [];

if (!empty($speaker)) {
    $query .= " AND speaker LIKE :speaker";
    $params[':speaker'] = "%$speaker%";
}

if (!empty($topic)) {
    $query .= " AND topic LIKE :topic";
    $params[':topic'] = "%$topic%";
}

if (!empty($date_from)) {
    $query .= " AND sermon_date >= :date_from";
    $params[':date_from'] = $date_from;
}

if (!empty($date_to)) {
    $query .= " AND sermon_date <= :date_to";
    $params[':date_to'] = $date_to;
}

$query .= " ORDER BY sermon_date DESC";

$stmt = $db->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$sermons = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get unique speakers and topics for filter dropdowns
$speakers = $db->query("SELECT DISTINCT speaker FROM sermons ORDER BY speaker")->fetchAll(PDO::FETCH_COLUMN);
$topics = $db->query("SELECT DISTINCT topic FROM sermons WHERE topic IS NOT NULL AND topic != '' ORDER BY topic")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sermons - Olebu SDA Church</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-white shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="index.php" class="text-2xl font-bold text-indigo-600">Olebu SDA Church</a>
                </div>
                <div class="hidden md:flex items-center space-x-8">
                    <a href="index.php" class="text-gray-700 hover:text-indigo-600">Home</a>
                    <a href="index.php#about" class="text-gray-700 hover:text-indigo-600">About</a>
                    <a href="sermons.php" class="text-indigo-600 font-medium">Sermons</a>
                    <a href="events.php" class="text-gray-700 hover:text-indigo-600">Events</a>
                    <a href="ministries.php" class="text-gray-700 hover:text-indigo-600">Ministries</a>
                    <a href="members.php" class="text-gray-700 hover:text-indigo-600">Members</a>
                    <a href="contact.php" class="text-gray-700 hover:text-indigo-600">Contact</a>
                    <a href="admin/login.php" class="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">Admin</a>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
    <!-- Hero Section -->
    <div class="bg-gradient-to-r from-purple-600 to-pink-600 text-white py-16">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl md:text-5xl font-bold mb-4">Sermons</h1>
            <p class="text-xl text-purple-100">Listen to our weekly messages and grow in faith</p>
        </div>
    </div>
        </div>

        <!-- Filter Section -->
        <div class="bg-white shadow-lg rounded-lg p-6 mb-8">
            <h2 class="text-lg font-semibold text-gray-900 mb-4">Filter Sermons</h2>
            <form method="GET" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                    <label for="speaker" class="block text-sm font-medium text-gray-700 mb-2">Speaker</label>
                    <select id="speaker" name="speaker" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                        <option value="">All Speakers</option>
                        <?php foreach ($speakers as $s): ?>
                            <option value="<?php echo htmlspecialchars($s); ?>" <?php echo $speaker === $s ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($s); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label for="topic" class="block text-sm font-medium text-gray-700 mb-2">Topic</label>
                    <select id="topic" name="topic" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                        <option value="">All Topics</option>
                        <?php foreach ($topics as $t): ?>
                            <option value="<?php echo htmlspecialchars($t); ?>" <?php echo $topic === $t ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($t); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label for="date_from" class="block text-sm font-medium text-gray-700 mb-2">From Date</label>
                    <input type="date" id="date_from" name="date_from" 
                           value="<?php echo htmlspecialchars($date_from); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                </div>
                
                <div>
                    <label for="date_to" class="block text-sm font-medium text-gray-700 mb-2">To Date</label>
                    <input type="date" id="date_to" name="date_to" 
                           value="<?php echo htmlspecialchars($date_to); ?>"
                           class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500">
                </div>
                
                <div class="md:col-span-2 lg:col-span-4 flex space-x-4">
                    <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700">
                        Filter
                    </button>
                    <a href="sermons.php" class="bg-gray-600 text-white px-6 py-2 rounded-md hover:bg-gray-700">
                        Clear
                    </a>
                </div>
            </form>
        </div>

        <!-- Sermons Grid -->
        <?php if (empty($sermons)): ?>
            <div class="text-center py-12">
                <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                </svg>
                <h3 class="mt-2 text-sm font-medium text-gray-900">No sermons found</h3>
                <p class="mt-1 text-sm text-gray-500">Try adjusting your filters or check back later for new sermons.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php foreach ($sermons as $sermon): ?>
                    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
                        <div class="p-6">
                            <div class="flex items-center justify-between mb-4">
                                <span class="px-2 py-1 text-xs font-semibold bg-indigo-100 text-indigo-800 rounded-full">
                                    <?php echo formatDate($sermon['sermon_date']); ?>
                                </span>
                                <?php if ($sermon['topic']): ?>
                                    <span class="px-2 py-1 text-xs font-semibold bg-gray-100 text-gray-800 rounded-full">
                                        <?php echo htmlspecialchars($sermon['topic']); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo htmlspecialchars($sermon['title']); ?></h3>
                            <p class="text-gray-600 mb-4">by <strong><?php echo htmlspecialchars($sermon['speaker']); ?></strong></p>
                            
                            <?php if ($sermon['scripture_reference']): ?>
                                <p class="text-sm text-indigo-600 mb-4">
                                    <strong>Scripture:</strong> <?php echo htmlspecialchars($sermon['scripture_reference']); ?>
                                </p>
                            <?php endif; ?>
                            
                            <?php if ($sermon['description']): ?>
                                <p class="text-gray-600 mb-4"><?php echo htmlspecialchars($sermon['description']); ?></p>
                            <?php endif; ?>
                            
                            <div class="flex flex-wrap gap-2">
                                <?php if ($sermon['video_url']): ?>
                                    <a href="<?php echo htmlspecialchars($sermon['video_url']); ?>" 
                                       target="_blank"
                                       class="inline-flex items-center px-3 py-2 bg-red-600 text-white text-sm font-medium rounded-md hover:bg-red-700">
                                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                            <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"></path>
                                        </svg>
                                        Watch
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($sermon['audio_url']): ?>
                                    <a href="<?php echo htmlspecialchars($sermon['audio_url']); ?>" 
                                       target="_blank"
                                       class="inline-flex items-center px-3 py-2 bg-blue-600 text-white text-sm font-medium rounded-md hover:bg-blue-700">
                                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM15.657 6.343a1 1 0 011.414 0A9.972 9.972 0 0119 12a9.972 9.972 0 01-1.929 5.657 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 12a7.971 7.971 0 00-1.343-4.243 1 1 0 010-1.414z" clip-rule="evenodd"></path>
                                        </svg>
                                        Listen
                                    </a>
                                <?php endif; ?>
                                
                                <?php if ($sermon['notes_pdf']): ?>
                                    <a href="uploads/<?php echo htmlspecialchars($sermon['notes_pdf']); ?>" 
                                       target="_blank"
                                       class="inline-flex items-center px-3 py-2 bg-gray-600 text-white text-sm font-medium rounded-md hover:bg-gray-700">
                                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                                            <path fill-rule="evenodd" d="M4 4a2 2 0 012-2h4.586A2 2 0 0112 2.586L15.414 6A2 2 0 0116 7.414V16a2 2 0 01-2 2H6a2 2 0 01-2-2V4zm2 6a1 1 0 011-1h6a1 1 0 110 2H7a1 1 0 01-1-1zm1 3a1 1 0 100 2h6a1 1 0 100-2H7z" clip-rule="evenodd"></path>
                                        </svg>
                                        Notes
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

<?php include 'includes/footer.php'; ?>
