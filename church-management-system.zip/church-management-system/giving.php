<?php
/**
 * OLEBU Church Management System
 * Giving Page - In Person Donations
 */

require_once 'config/config.php';

$pageTitle = "Give - Support Our Ministry";
include 'includes/header.php';
include 'includes/navigation.php';
?>

<!-- Hero Section -->
<section class="relative bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white py-20">
    <div class="absolute inset-0 bg-black opacity-40"></div>
    <div class="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div class="animate-fade-in">
            <h1 class="text-4xl md:text-6xl font-bold mb-6">Give Generously</h1>
            <p class="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
                Your generous giving helps us spread the Gospel and serve our community
            </p>
            <div class="glass-effect rounded-2xl p-6 max-w-2xl mx-auto">
                <blockquote class="text-lg italic">
                    "Each of you should give what you have decided in your heart to give, not reluctantly or under compulsion, for God loves a cheerful giver."
                </blockquote>
                <cite class="text-sm text-gray-300 mt-2 block">- 2 Corinthians 9:7</cite>
            </div>
        </div>
    </div>
</section>

<!-- Give In Person Section -->
<section class="py-20 bg-gray-50">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <!-- Ways to Give In Person -->
        <div class="mb-16">
            <div class="text-center mb-12">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900">Give In Person</h2>
                <p class="mt-4 text-xl text-gray-600">Join us during our services to give your offering</p>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Sunday Service -->
                <div class="bg-white rounded-2xl shadow-lg p-8">
                    <div class="flex items-center mb-6">
                        <div class="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-church text-green-600 text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-gray-900">Sunday Service</h3>
                            <p class="text-gray-500">Main Worship Service</p>
                        </div>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center text-gray-600">
                            <i class="fas fa-clock w-6 text-green-600"></i>
                            <span>8:00 AM - 12:00 PM</span>
                        </div>
                        <div class="flex items-center text-gray-600">
                            <i class="fas fa-map-marker-alt w-6 text-green-600"></i>
                            <span>Main Sanctuary</span>
                        </div>
                    </div>
                </div>
                
                <!-- Midweek Service -->
                <div class="bg-white rounded-2xl shadow-lg p-8">
                    <div class="flex items-center mb-6">
                        <div class="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mr-4">
                            <i class="fas fa-users text-blue-600 text-2xl"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-bold text-gray-900">Midweek Service</h3>
                            <p class="text-gray-500">Bible Study & Prayer</p>
                        </div>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center text-gray-600">
                            <i class="fas fa-clock w-6 text-blue-600"></i>
                            <span>Wednesday: 6:00 PM - 8:00 PM</span>
                        </div>
                        <div class="flex items-center text-gray-600">
                            <i class="fas fa-map-marker-alt w-6 text-blue-600"></i>
                            <span>Fellowship Hall</span>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Church Office -->
            <div class="mt-8 bg-white rounded-2xl shadow-lg p-8">
                <div class="flex items-center mb-6">
                    <div class="w-16 h-16 bg-indigo-100 rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-building text-indigo-600 text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold text-gray-900">Church Office</h3>
                        <p class="text-gray-500">Visit us during office hours</p>
                    </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="bg-gray-50 p-4 rounded-xl">
                        <div class="flex items-center text-gray-700">
                            <i class="fas fa-map-marker-alt w-6 text-indigo-600"></i>
                            <span>Main Street, City Center</span>
                        </div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-xl">
                        <div class="flex items-center text-gray-700">
                            <i class="fas fa-clock w-6 text-indigo-600"></i>
                            <span>Mon - Fri: 8am - 5pm</span>
                        </div>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-xl">
                        <div class="flex items-center text-gray-700">
                            <i class="fas fa-phone w-6 text-indigo-600"></i>
                            <span>+233 123 456 789</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Giving Categories -->
        <div>
            <div class="text-center mb-12">
                <h2 class="text-3xl md:text-4xl font-bold text-gray-900">Giving Categories</h2>
                <p class="mt-4 text-xl text-gray-600">Choose where you want your gift to go (Amounts in Ghana Cedis ₵)</p>
            </div>
            
            <div class="bg-white rounded-2xl shadow-lg p-8">
                <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                    <a href="giving-category.php?type=tithe" class="block text-center p-4 border-2 border-green-200 rounded-xl hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-coins text-3xl text-green-600 mb-2"></i>
                        <h3 class="font-semibold text-gray-900">Tithe</h3>
                    </a>
                    <a href="giving-category.php?type=offering" class="block text-center p-4 border-2 border-green-200 rounded-xl hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-gift text-3xl text-green-600 mb-2"></i>
                        <h3 class="font-semibold text-gray-900">Offering</h3>
                    </a>
                    <a href="giving-category.php?type=building" class="block text-center p-4 border-2 border-green-200 rounded-xl hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-building text-3xl text-green-600 mb-2"></i>
                        <h3 class="font-semibold text-gray-900">Building</h3>
                    </a>
                    <a href="giving-category.php?type=missions" class="block text-center p-4 border-2 border-green-200 rounded-xl hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-globe text-3xl text-green-600 mb-2"></i>
                        <h3 class="font-semibold text-gray-900">Missions</h3>
                    </a>
                    <a href="giving-category.php?type=special" class="block text-center p-4 border-2 border-green-200 rounded-xl hover:bg-green-50 transition cursor-pointer">
                        <i class="fas fa-star text-3xl text-green-600 mb-2"></i>
                        <h3 class="font-semibold text-gray-900">Special</h3>
                    </a>
                    <a href="giving-category.php?type=other" class="block text-center p-4 border-2 border-yellow-400 rounded-xl hover:bg-yellow-50 transition cursor-pointer bg-yellow-50">
                        <i class="fas fa-ellipsis-h text-3xl text-yellow-600 mb-2"></i>
                        <h3 class="font-semibold text-yellow-700">Other</h3>
                    </a>
                </div>
                
                <!-- Contact Option -->
                <div class="mt-12 pt-8 border-t">
                    <div class="text-center">
                        <h3 class="text-xl font-bold text-gray-900 mb-4">Other Ways to Give</h3>
                        <p class="text-gray-600 mb-6">Contact us to discuss other giving options or to designate your gift to a specific purpose.</p>
                        <a href="contact.php?subject=Donation%20Inquiry" class="inline-block bg-green-600 text-white px-8 py-3 rounded-xl font-semibold hover:bg-green-700 transition">
                            <i class="fas fa-envelope mr-2"></i>Contact Us About Giving
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
